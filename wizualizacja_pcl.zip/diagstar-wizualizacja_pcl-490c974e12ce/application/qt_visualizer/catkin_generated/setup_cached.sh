#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/pawel/QtVisual/qt_visualizer/devel:$CMAKE_PREFIX_PATH"
export PATH="/opt/ros/kinetic/bin:/home/pawel/Qt/5.9.3/gcc_64/bin:/usr/bin:/home/pawel/bin:/home/pawel/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin:/usr/lib/jvm/java-9-oracle/bin:/usr/lib/jvm/java-9-oracle/db/bin"
export PWD="/home/pawel/QtVisual/qt_visualizer"
export ROSLISP_PACKAGE_DIRECTORIES="/home/pawel/QtVisual/qt_visualizer/devel/share/common-lisp"
export ROS_PACKAGE_PATH="/home/pawel/QtVisual:$ROS_PACKAGE_PATH"