#ifndef SUBSCRIBER_H
#define SUBSCRIBER_H
#include <pclviewer.h>
#include <QApplication>
#include <QMainWindow>
#include <QtCore>



class Subscriber:public QThread
{
public:
    Subscriber();
     void run();
     void cloud_cb (const sensor_msgs::PointCloud2ConstPtr& cloud_msg);
    ros::NodeHandle nh;
};

#endif // SUBSCRIBER_H
