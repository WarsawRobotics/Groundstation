#include "mywidget.h"

mywidget::mywidget()
{

}
