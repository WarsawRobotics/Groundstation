#ifndef MYWIDGET_H
#define MYWIDGET_H


class mywidget
{
public:
    mywidget();
};

#endif // MYWIDGET_H