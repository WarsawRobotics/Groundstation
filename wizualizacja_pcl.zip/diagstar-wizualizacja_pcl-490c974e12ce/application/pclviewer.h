#ifndef PCLVIEWER_H
#define PCLVIEWER_H

#include <iostream>
#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>

// Qt
#include <QMainWindow>
#include <QtCore>

// Point Cloud Library
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/visualization/cloud_viewer.h>
#include <pcl/io/io.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/visualization/point_cloud_handlers.h>

// Visualization Toolkit (VTK)
#include <vtkRenderWindow.h>

namespace Ui
{
  class PCLViewer;
}

class PCLViewer : public QMainWindow
{
  Q_OBJECT

public:
    void loop();
    void cloud_cb (const sensor_msgs::PointCloud2ConstPtr& cloud_msg);
    ros::NodeHandle nh;
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_test;

  explicit PCLViewer (QWidget *parent = 0);

  ~PCLViewer ();

protected:
  boost::shared_ptr<pcl::visualization::PCLVisualizer> viewer;

public:
  Ui::PCLViewer *ui;
};


#endif // PCLVIEWER_H
