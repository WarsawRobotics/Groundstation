#include "pclviewer.h"
#include <QApplication>
#include <QMainWindow>
#include <QtCore>

//Stworzenie osobnego wątku do subskrybowania danych z ROS'a
class QCloud : public QThread
{
public:
    PCLViewer viewer;

    void run()
    {
        viewer.loop();
    }

    void show()
    {
        viewer.show();
    }
};

int main (int argc, char *argv[])
{
  ros::init(argc, argv, "sub_pcl");
  QApplication app (argc, argv);
  QCloud cloud;
  cloud.show();
  cloud.start();

  return app.exec();
}

