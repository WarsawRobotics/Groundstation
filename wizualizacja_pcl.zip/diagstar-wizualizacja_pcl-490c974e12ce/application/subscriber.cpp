#include "subscriber.h"



Subscriber::Subscriber(){}
void Subscriber::run()
{
   ros::Subscriber sub = nh.subscribe<sensor_msgs::PointCloud2>("/camera/depth/color/points", 1,  &Subscriber::cloud_cb,this);
   ros::spinOnce();
}
void Subscriber::cloud_cb (const sensor_msgs::PointCloud2ConstPtr& cloud_msg)
{
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::fromROSMsg(*cloud_msg, *cloud);
    ROS_INFO("TEST");
}
