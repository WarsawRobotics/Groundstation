#include "pclviewer.h"
#include "ui_pclviewer.h"
#include <QtCore>

//Konstruktor
PCLViewer::PCLViewer(QWidget *parent) : QMainWindow(parent), ui(new Ui::PCLViewer)
{
    //Stworzenie chmury punktowej
    cloud_test = pcl::PointCloud<pcl::PointXYZ>::Ptr(new pcl::PointCloud<pcl::PointXYZ>);
    //Inicjalizacja aplikacji okienkowej
    ui->setupUi (this);
    this->setWindowTitle ("PCL viewer");
    viewer.reset (new pcl::visualization::PCLVisualizer ("viewer", false));
    ui->qvtkWidget->SetRenderWindow (viewer->getRenderWindow ());
    viewer->setupInteractor(ui->qvtkWidget->GetInteractor (), ui->qvtkWidget->GetRenderWindow ());
    ui->qvtkWidget->update ();
    viewer->resetCamera();
    ui->qvtkWidget->update();
    //Dodanie początkowej chmury punktów
    viewer->addPointCloud(cloud_test, "cloud");
}

//Pętla odpowiedzialna za subskrybowanie danych z chmury punktowej
void PCLViewer::loop()
{
   ros::Subscriber sub = nh.subscribe<sensor_msgs::PointCloud2>("/camera/depth/color/points", 1,  &PCLViewer::cloud_cb, this);
   ros::spin();
}
//Pętla w której otrzymywane dane z chmury punktowej były odświeżane
void PCLViewer::cloud_cb (const sensor_msgs::PointCloud2ConstPtr& cloud_msg)
{
    //Dane z chmury punktowej trzeba było konwertować do poprzedniej biblioteki PointCloud
    pcl::fromROSMsg(*cloud_msg, *cloud_test);
    viewer->updatePointCloud(cloud_test, "cloud");
    ui->qvtkWidget->update();
}

//Destruktor
PCLViewer::~PCLViewer ()
{
  //delete cloud_test;
  delete ui;
}



