#include <iostream>
#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/visualization/cloud_viewer.h>
#include <pcl/io/io.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/visualization/point_cloud_handlers.h>



//ros::Publisher pub;
  pcl::visualization::CloudViewer viewer ("Simple Cloud Viewer");

//void viewerOneOff (pcl::visualization::PCLVisualizer& viewer)
//{
//    pcl::PointXYZ o,p;
//    o.x = 1.0;
//    o.y = 0;
//    o.z = 0;
//    p.x = 2;
//    p.y = 1;
//    p.z = 0;
//    viewer.addSphere(o,0.01,"s1");
//    viewer.addSphere(p,0.01,"s2");

//}
//void callback(const sensor_msgs::PointCloud2ConstPtr &msg)
// {
//   viewer.runOnVisualizationThreadOnce (viewerOneOff);
//   ROS_INFO("test");
// }


void cloud_cb (const sensor_msgs::PointCloud2ConstPtr& cloud_msg)
{
  //  ROS_INFO("test");
  // Container for original & filtered data
//    pcl::PCLPointCloud2* cloud = new pcl::PCLPointCloud2;
//    pcl::PCLPointCloud2ConstPtr cloudPtr(cloud);
//    pcl::PCLPointCloud2 cloud_filtered;
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_pcl(new pcl::PointCloud<pcl::PointXYZ>);




    // Convert to PCL data type
//     pcl_conversions::toPCL(*cloud_msg, *cloud);
     pcl::fromROSMsg(*cloud_msg, *cloud_pcl);

//   viewer.showCloud (*cloud);

//     std::cerr << "PointCloud before filtering: " << cloud->width * cloud->height
//            << " data points (" << pcl::getFieldsList (*cloud) << ").";


     viewer.showCloud (cloud_pcl);


     // Perform the actual filtering
//     pcl::VoxelGrid<pcl::PCLPointCloud2> sor;
//     sor.setInputCloud (cloudPtr);
//     sor.setLeafSize (0.1, 0.1, 0.1);
//     sor.filter (cloud_filtered);

//    std::cerr << "PointCloud after filtering: " << cloud_filtered.width * cloud_filtered.height
//           << " data points (" << pcl::getFieldsList (cloud_filtered) << ").";

//    pcl::PCDWriter writer;
//    writer.write ("table_scene_lms400_downsampled.pcd", cloud_filtered,
//    Eigen::Vector4f::Zero (), Eigen::Quaternionf::Identity (), false);

//    // Convert to ROS data type
//     sensor_msgs::PointCloud2 output;
//     pcl_conversions::fromPCL(cloud_filtered, output);

//     // Publish the data
//    pub.publish (output);
}


//int user_data;
int main (int argc, char** argv)

{
   // pcl::PointCloud<pcl::PointXYZRGBA>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZRGBA>);
    ros::init(argc, argv, "sub_pcl");
    ros::NodeHandle nh;
    ros::Subscriber sub = nh.subscribe<sensor_msgs::PointCloud2>("/camera/depth/color/points", 1, cloud_cb);

    //blocks until the cloud is actually rendered
    //viewer.showCloud(cloud);


    //PCLVisualizer


   // while (!viewer.wasStopped ())
   // {

        ros::spin();
    //}
       return 0;
}
