#ifndef DIAGNOSTIC_DATA_MANAGER_HPP
#define DIAGNOSTIC_DATA_MANAGER_HPP

/* Local Libs */
#include "diagnostic_data_base.hpp"

namespace diagstar
{
    template<typename Protocol>
    class DiagnosticDataManager final
    {
        using DignosticDataPtr = std::unique_ptr<DiagnosticData>;
        using DiagnosticDataList = std::vector<DignosticDataPtr>;
        using ProtocolPtr = std::unique_ptr<Protocol>;

    public:
        DiagnosticDataManager(const std::string &receiver_ip)
            : diag_data_number_(0), is_diag_data_intialized_(true), send_protocol_(common::MakeUnique<Protocol>(receiver_ip, 512))
        {
        }
        template <typename DiagDataType, typename... Args>
        void AddDiagnosticData(Args &&... args) noexcept
        {
            diag_data_list.emplace_back(common::MakeUnique<DiagDataType>(std::forward<Args>(args)..., send_protocol_.get()));
            ++diag_data_number_;
        }
        void Init()
        {
            SystemMsg::ThrowInfo(sys_msg_header_ + "Initialized with " + std::to_string(diag_data_number_) + " diagnostic data.");
            send_protocol_->Init(diag_data_list.size());
            for (auto &diag_data : diag_data_list)
            {
                diag_data->Init();
                is_diag_data_intialized_ &= diag_data->IsInitialized();
            }
        }
        void Run()
        {
            if (is_diag_data_intialized_)
            {
                ros::spin();
            }
            else
            {
                SystemMsg::ThrowError(sys_msg_header_ + "Not all diagnostic data are initialized.");
            }
        }
        const size_t &DiagDataNubmer() const noexcept
        {
            return diag_data_number_;
        }

    private:
        DiagnosticDataList diag_data_list;
        ProtocolPtr send_protocol_;
        size_t diag_data_number_;
        bool is_diag_data_intialized_;
 
        const std::string sys_msg_header_ = "[DiagnosticDataManager] ";
    };
} // namespace diagstar

#endif //DIAGNOSTIC_DATA_MANAGER_HPP