#ifndef DIAGNOSTIC_DATA_BASE_HPP
#define DIAGNOSTIC_DATA_BASE_HPP

/* Std Libs */
#include <algorithm>
#include <sstream>

/* Ros Libs */
#include <ros/ros.h>

/* Local Libs */
#include "send_protocol_base.hpp"

namespace diagstar
{
    class DiagnosticData
    {
    protected:
        enum class DiagnosticDataStatus
        {
            UNKNOWN,
            INITIALIZE_SUCCESS,
            INITIALIZE_FAIL,
        };

    public:
        // Topics seperated with comma.
        // E.g. Init("/topic1, /topic2")
        DiagnosticData(std::string &&topics, uint16_t &&port, Protocol *protocol) : protocol_(protocol),
                                                                                    topics_(std::move(topics)),
                                                                                    port_(std::move(port)),
                                                                                    status_(DiagnosticDataStatus::UNKNOWN),
                                                                                    receiver_id_(0)
        {
        }
        virtual ~DiagnosticData() {}
        virtual void Init() = 0;
        virtual const bool IsInitialized() const noexcept
        {
            return status_ == DiagnosticDataStatus::INITIALIZE_SUCCESS;
        }
        DiagnosticData() = delete;

    protected:
        virtual void EncodeData() = 0;

        std::vector<std::string> GetTopics(std::string &&topics)
        {
            topics.erase(std::remove(topics.begin(), topics.end(), ' '), topics.end());
            std::istringstream string_stream(std::move(topics));
            std::vector<std::string> topic_list;
            std::string topic;
            while (std::getline(string_stream, topic, ','))
            {
                topic_list.push_back(topic);
            }
            return topic_list;
        }
        Protocol *protocol_;
        uint16_t port_;
        uint8_t receiver_id_;
        DiagnosticDataStatus status_;
        ros::NodeHandle nh_;
        std::string sys_msg_header_;
        std::string topics_;
    };
} // namespace diagstar

#endif //DIAGNOSTICS_DATA_BASE_HPP