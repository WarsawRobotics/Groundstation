#ifndef GROUND_STATION_DIAGNOSTIC_DATA_HPP
#define GROUND_STATION_DIAGNOSTIC_DATA_HPP

/* Local Libs */
#include "diagnostic_data_base.hpp"

/* Ros Libs */
#include <sensor_msgs/Joy.h>

namespace diagstar
{
    class GroundStationData : public DiagnosticData
    {
    public:
        GroundStationData(std::string &&topics, uint16_t &&port, Protocol *protocol);
        void Init() override;

    private:
        void ListenGroundStationData(const sensor_msgs::JoyConstPtr &gcs_data);
        void EncodeData() override;

        ros::Subscriber data_sub_;
        mavlink_gcs_t gcs_msg_;
        std::string data_topic_;
        size_t gcs_expected_joy_data_numb;
    };
} // namespace diagstar

#endif //GROUND_STATION_DIAGNOSTIC_DATA_HPP