#ifndef TRANSMITER_BASE_HPP
#define TRANSMITER_BASE_HPP

/* Local Libs */
#include "helpers.hpp"

namespace diagstar
{
    enum class TransmiterStatus
    {
        UNKNOWN,
        INITIALIZE_SUCCESS,
        INITIALIZE_FAIL,
        CONNECTED,
        DISCONNECTED,
        RUNNING
    };
} // namespace diagstar

#endif //TRANSMITER_BASE_HPP