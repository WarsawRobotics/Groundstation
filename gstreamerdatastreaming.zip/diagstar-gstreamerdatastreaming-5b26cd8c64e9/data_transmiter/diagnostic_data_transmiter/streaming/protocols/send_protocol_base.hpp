#ifndef SEND_PROTOCOL_BASE_HPP
#define SEND_PROTOCOL_BASE_HPP

/* Std Libs */
#include <vector>

/* Local Libs */
#include "helpers.hpp"
#include "sys_msg.hpp"

/* 3d Party Libs */
#include "mavlink.h"

namespace diagstar
{
    class Protocol
    {
    public:
        Protocol(const std::string &receiver_ip, const size_t &buffer_size) : recv_ip_(receiver_ip)
        {
            data_.resize(buffer_size);
        }
        virtual ~Protocol() {}
        virtual void Init() = 0;
        virtual void Init(const uint8_t &recv_numb) = 0;
        virtual size_t AddReceiver(const uint16_t &port) = 0;
        virtual int SendData(const mavlink_message_t &mav_msg, const size_t &receiver_id) = 0;
        virtual std::string GetConfigurationString(const size_t &receiver_id) const = 0;

        Protocol() = delete;

    protected:
        std::vector<uint8_t> data_;
        std::string recv_ip_;
    };
} // namespace diagstar

#endif //SEND_PROTOCOL_BASE_HPP