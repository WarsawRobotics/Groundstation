#ifndef UDP_PROTOCOL_HPP
#define UDP_PROTOCOL_HPP

/* Std Libs */
#include <arpa/inet.h>
#include <fcntl.h>
#include <mutex>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <vector>

/* Local Libs */
#include "send_protocol_base.hpp"

namespace diagstar
{
    class UdpProtocol : public Protocol
    {
    public:
        template <typename... Args>
        UdpProtocol(Args &&... args) : Protocol(std::forward<Args>(args)...), socket_(0)
        {
        }
        void Init() override
        {
            socket_ = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
            if (socket_ == -1)
            {
                throw std::runtime_error("Can't create socket.");
            }
            if (fcntl(socket_, F_SETFL, O_NONBLOCK | O_ASYNC) < 0)
            {
                close(socket_);
                throw std::runtime_error("Can't configure file descriptor.");
            }
            receiver_addrs_.resize(1);
        }
        void Init(const uint8_t &recv_numb) override
        {
            socket_ = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
            if (socket_ == -1)
            {
                throw std::runtime_error("Can't create socket.");
            }
            if (fcntl(socket_, F_SETFL, O_NONBLOCK | O_ASYNC) < 0)
            {
                close(socket_);
                throw std::runtime_error("Can't configure file descriptor.");
            }
            receiver_addrs_.resize(recv_numb);
        }
        int SendData(const mavlink_message_t &mav_msg, const size_t &receiver_id) override
        {
            uint16_t len = mavlink_msg_to_send_buffer(data_.data(), &mav_msg);
            return sendto(socket_, data_.data(), len, 0, (struct sockaddr *)&(receiver_addrs_[receiver_id]), sizeof(sockaddr_in));
        }
        size_t AddReceiver(const uint16_t &port) override
        {
            static size_t receiver_id = -1;
            ++receiver_id;

            memset(&(receiver_addrs_[receiver_id]), 0, sizeof(receiver_addrs_[receiver_id]));
            receiver_addrs_[receiver_id].sin_family = AF_INET;
            receiver_addrs_[receiver_id].sin_addr.s_addr = inet_addr(recv_ip_.c_str());
            receiver_addrs_[receiver_id].sin_port = htons(port);

            return receiver_id;
        }
        std::string GetConfigurationString(const size_t &receiver_id) const override
        {
            return "IP: " + recv_ip_ + "  Receiver port: " + std::to_string(htons(receiver_addrs_[receiver_id].sin_port)) + "  ";
        }

    private:
        int socket_;
        std::vector<struct sockaddr_in> receiver_addrs_;
    };
} // namespace diagstar

#endif //UDP_PROTOCOL_HPP