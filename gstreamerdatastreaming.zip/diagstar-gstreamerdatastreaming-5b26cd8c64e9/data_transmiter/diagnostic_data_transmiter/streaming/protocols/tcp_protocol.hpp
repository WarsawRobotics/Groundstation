#ifndef TCP_PROTOCOL_HPP
#define TCP_PROTOCOL_HPP

#include "send_protocol_base.hpp"

namespace diagstar
{
    class TcpProtocol : public Protocol
    {
        template <typename... Args>
        TcpProtocol(Args &&... args) : Protocol(std::forward<Args>(args)...)
        {
        }
        void Init(const uint8_t &recv_numb) override
        {
            SystemMsg::ThrowOk("TcpProtocol initialized.");
        }
        int SendData(const mavlink_message_t &mav_msg, const size_t &receiver_id) override
        {
            //SystemMsg::ThrowInfo("New data to send arrived");
            return 0;
        }
        std::string GetConfigurationString() const override
        {
            return "protocol_tcp  ";
        }
    }
}; // namespace diagstar

#endif //TCP_PROTOCOL_HPP