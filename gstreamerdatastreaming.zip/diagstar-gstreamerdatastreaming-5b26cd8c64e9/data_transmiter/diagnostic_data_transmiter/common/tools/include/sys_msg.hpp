#ifndef __SYSTEM_MSG_HPP__
#define __SYSTEM_MSG_HPP__

/* Std Libs */
#include <array>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <sstream>
#include <string>

/* Local Libs */
#include "helpers.hpp"
#include "time.hpp"

namespace diagstar
{
    class SystemMsg
    {
        enum class SysMsgCode : int
        {
            WARN,
            ERR,
            OK,
            INFO
        };
        enum class MsgColor : int
        {
            RED = 31,
            GREEN = 32,
            YELLOW = 33,
        };
        enum class VerboseLevel : int
        {
            NO_VERBOSE,
            ERR_WARN,
            ALL
        };

    public:
        SystemMsg() = delete;
        SystemMsg(const SystemMsg &) = delete;
        SystemMsg(SystemMsg &&) = delete;
        SystemMsg &operator=(const SystemMsg &) = delete;
        SystemMsg &operator=(SystemMsg &&) = delete;
        ~SystemMsg() = delete;

        static void SetVerboseAll()
        {
            mverbose_ = common::CastEnum(VerboseLevel::ALL);
        }
        static void SetVerboseErrWarn()
        {
            mverbose_ = common::CastEnum(VerboseLevel::ERR_WARN);
        }
        static void SetVerboseNone()
        {
            mverbose_ = common::CastEnum(VerboseLevel::NO_VERBOSE);
        }
        static void SetVerboseLevel(const uint32_t &level)
        {
            if (level == common::CastEnum(VerboseLevel::NO_VERBOSE))
            {
                SetVerboseNone();
            }
            else if (level == common::CastEnum(VerboseLevel::ERR_WARN))
            {
                SetVerboseErrWarn();
            }
            else if (level >= common::CastEnum(VerboseLevel::ALL))
            {
                SetVerboseAll();
            }
        }
        template <typename String>
        static void ThrowError(String &&msg, const bool &multithread_safe = false)
        {
            if (multithread_safe)
            {
                std::lock_guard<std::mutex> lock_guard(mprint_mut_);
                ThrowSysMsg(std::forward<String>(msg), common::CastEnum(SysMsgCode::ERR));
            }
            else
            {
                ThrowSysMsg(std::forward<String>(msg), common::CastEnum(SysMsgCode::ERR));
            }
        }
        template <typename String>
        static void ThrowInfo(String &&msg, const bool &multithread_safe = false)
        {
            if (multithread_safe)
            {
                std::lock_guard<std::mutex> lock_guard(mprint_mut_);
                ThrowSysMsg(std::forward<String>(msg), common::CastEnum(SysMsgCode::INFO));
            }
            else
            {
                ThrowSysMsg(std::forward<String>(msg), common::CastEnum(SysMsgCode::INFO));
            }
        }
        template <typename String>
        static void ThrowWarn(String &&msg, const bool &multithread_safe = false)
        {
            if (multithread_safe)
            {
                std::lock_guard<std::mutex> lock_guard(mprint_mut_);
                ThrowSysMsg(std::forward<String>(msg), common::CastEnum(SysMsgCode::WARN));
            }
            else
            {
                ThrowSysMsg(std::forward<String>(msg), common::CastEnum(SysMsgCode::WARN));
            }
        }
        template <typename String>
        static void ThrowOk(String &&msg, const bool &multithread_safe = false)
        {
            if (multithread_safe)
            {
                std::lock_guard<std::mutex> lock_guard(mprint_mut_);
                ThrowSysMsg(std::forward<String>(msg), common::CastEnum(SysMsgCode::OK));
            }
            else
            {
                ThrowSysMsg(std::forward<String>(msg), common::CastEnum(SysMsgCode::OK));
            }
        }

    private:
        /* @brief Throw system message based on system message code.
		Format of thrown message: ["System code"] [Time in seconds]: "Message". Function is threadsafe if pointer to mutex is passed.
		@param sys_msg_code One of the avaiable codes: WARN, ERROR, INFO, OK.
		@param verbose_lvl	Verbosity level: 0 - no message visable, 1 - error and info messages visable, 2 - all messages visable.
		@param msg			String message.
		@param mut			Pointer to print mutex. Only one instance of print mutex is permitted(should not be global nor static, should be member of master class)
		*/
        template <typename String>
        static void ThrowSysMsg(String &&msg, const int &code)
        {
            if (verbose_truth_lut[mverbose_][code])
            {
                std::stringstream stream;
                stream << std::fixed << std::setprecision(9) << Time::Now().toSec();
                std::cout << "\033[0;" + std::to_string(msg_color_lut[code]) + "m"
                          << msg_type_lut[code]
                          << "\033[0m"
                          << " [" + stream.str() + "]: " + msg << std::endl;
            }
        }
        static int mverbose_;
        static std::mutex mprint_mut_;
        static std::array<int, 4> msg_color_lut;
        static std::array<std::string, 4> msg_type_lut;
        static std::array<std::array<bool, 4>, 3> verbose_truth_lut;
    };
} // namespace diagstar
#endif //__SYSTEM_MSG_HPP__