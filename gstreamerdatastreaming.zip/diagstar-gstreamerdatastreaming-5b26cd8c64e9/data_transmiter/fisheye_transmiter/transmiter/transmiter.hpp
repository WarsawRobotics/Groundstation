#ifndef TRANSMITER_HPP
#define TRANSMITER_HPP

/* GStreamer Libs */
#include <gst/app/gstappsrc.h>
#include <gst/gst.h>
#include <gst/video/video.h>

/* Ros Libs */
#include <ros/ros.h>
#include <sensor_msgs/Image.h>

/* Local Libs */
#include "watchdog.hpp"

namespace diagstar
{
    struct TransmiterConfiguration
    {
        TransmiterConfiguration &operator=(const TransmiterConfiguration &rhs)
        {
            this->img_encoding_ = rhs.img_encoding_;
            this->receiver_ip_ = rhs.receiver_ip_;
            this->img_ros_topic_ = rhs.img_ros_topic_;
            this->receiver_port_ = rhs.receiver_port_;
            this->img_height_ = rhs.img_height_;
            this->img_width_ = rhs.img_width_;
            this->img_framerate_ = rhs.img_framerate_;
        }
        std::string img_ros_topic_;
        std::string receiver_ip_;
        std::string img_encoding_;

        int receiver_port_;
        int img_height_;
        int img_width_;
        int img_framerate_;
    };

    class Transmiter
    {
    public:
        Transmiter();
        ~Transmiter();

        void Initialize(const TransmiterConfiguration &cfg);
        void Run();
        void QuitInterrupt(int sig);

    private:
        void CreatePipelineElements();
        void ConfigurePipelineElements();
        void LinkElementsInPipeline();
        void TransmitData(const unsigned char *data);
        void RosDataCallback(const sensor_msgs::ImageConstPtr &image);
        void InitRosSubscibers();
        void PrintConfig() const;

        GstElement *source_, *converter_;
        GstElement *encoder_, *parser_, *payload_;
        GstElement *sink_;
        GstElement *pipeline_;

        TransmiterConfiguration cfg_;
        ros::NodeHandle nh_;
        ros::Subscriber img_sub_;

        int img_size_;
        bool is_initialized_;
        uint32_t watchdog_key_;
        
        const std::string ksys_msg_header_ = "[Transmiter] ";
    };
} // namespace diagstar

#endif // TRANSMITER_HPP