#ifndef ROS_MASTER_HPP
#define ROS_MASTER_HPP

/* Std Libs */
#include <string>

namespace diagstar
{
    class RosMaster
    {
    public:
        RosMaster(int argc, char *argv[], const std::string &ros_package_name);
        const bool &IsInitialized() const noexcept;

    private:
        bool mros_initialized_;
        const unsigned long mkconnection_attempts_numb_ = 3;
        const long mkconnection_attempt_timeout_ = 5; // [s]

        const std::string mksys_msg_header_ = "[RosMaster] ";
    };
} // namespace diagstar
#endif //ROS_MASTER_HPP