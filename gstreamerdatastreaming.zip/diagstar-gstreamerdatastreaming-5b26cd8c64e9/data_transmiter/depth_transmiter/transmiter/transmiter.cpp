/* Std Libs */
#include <thread>

/* Local Libs */
#include "transmiter.hpp"
#include "sys_msg.hpp"

namespace diagstar
{
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    //                        PUBLIC FUNCTIONS                            //
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

    Transmiter::Transmiter() : source_(nullptr), converter_(nullptr),
                            encoder_(nullptr), parser_(nullptr),
                            payload_(nullptr), sink_(nullptr),
                            pipeline_(nullptr), send_delay_counter_(0),
                            img_size_(0), is_initialized_(false),
                            watchdog_key_(0)
    {
    }
    Transmiter::~Transmiter()
    {
        gst_object_unref(pipeline_);
    }
    void Transmiter::Initialize(const TransmiterConfiguration &cfg)
    {
        try
        {
            gst_init(nullptr, nullptr);
            cfg_ = cfg;
            img_size_ = cfg_.img_height_ * cfg_.img_width_ * sizeof(uint16_t);
            WatchDog::GetInstance().RegisterKey(watchdog_key_);

            CreatePipelineElements();
            ConfigurePipelineElements();
            LinkElementsInPipeline();
            InitRosSubscibers();
            PrintConfig();
            is_initialized_ = true;
            SystemMsg::ThrowOk(ksys_msg_header_ + "Pipeline successfully initialized.");
        }
        catch (const std::runtime_error &error)
        {
            SystemMsg::ThrowError(ksys_msg_header_ + error.what());
        }
        catch (const std::exception &error)
        {
            SystemMsg::ThrowError(ksys_msg_header_ + error.what());
        }
        catch (...)
        {
            SystemMsg::ThrowError(ksys_msg_header_ + "Unknown error.");
        }
    }
    void Transmiter::Run()
    {
        if (is_initialized_)
        {
            gst_element_set_state(pipeline_, GST_STATE_PLAYING);
            std::this_thread::sleep_for(std::chrono::seconds(1));
            ros::spin();
        }
        else
        {
            SystemMsg::ThrowWarn(ksys_msg_header_ + "Pipeline is not initialized. Cannot run.");
        }
    }
    void Transmiter::QuitInterrupt(int sig)
    {
        try
        {
            ros::shutdown();
            gst_element_set_state(pipeline_, GST_STATE_NULL);
            SystemMsg::ThrowOk(ksys_msg_header_ + "Process successfully stoped.");
        }
        catch(...)
        {
            SystemMsg::ThrowError(ksys_msg_header_ + "Cannot stop process. Aborting.");
            throw EXIT_FAILURE;
        }
    }
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    //                        PRIVATE FUNCTIONS                           //
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

    void Transmiter::CreatePipelineElements()
    {
        pipeline_ = gst_pipeline_new("pipeline");
        source_ = gst_element_factory_make("appsrc", "ource");
        converter_ = gst_element_factory_make("videoconvert", "convert");
        encoder_ = gst_element_factory_make("pngenc", "encoder");
        parser_ = gst_element_factory_make("pngparse", "parser");
        payload_ = gst_element_factory_make("rtpgstpay", "payload");
        sink_ = gst_element_factory_make("udpsink", "sink");

        //Try to created Gstelement//Variables
        if (!pipeline_ || !source_ || !converter_ || !encoder_ || !parser_ || !payload_ || !sink_)
        {
            gst_object_unref(pipeline_);
            throw std::runtime_error("Cannot create all pipeline elements.");
        }
    }
    void Transmiter::ConfigurePipelineElements()
    {
        GstCaps *video_caps = gst_caps_new_simple("video/x-raw",
                                                "format", G_TYPE_STRING, cfg_.img_encoding_.c_str(),
                                                "width", G_TYPE_INT, cfg_.img_width_,
                                                "height", G_TYPE_INT, cfg_.img_height_,
                                                "framerate", GST_TYPE_FRACTION, cfg_.img_framerate_, 1, nullptr);

        g_object_set(source_, "caps", video_caps, nullptr);
        gst_caps_unref(video_caps);
        g_object_set(encoder_, "compression-level", 5, nullptr);
        g_object_set(sink_, "host", cfg_.receiver_ip_.c_str(), "port", cfg_.receiver_port_, nullptr);
    }
    void Transmiter::LinkElementsInPipeline()
    {
        gst_bin_add_many(GST_BIN(pipeline_), source_, converter_, encoder_, parser_, payload_, sink_, nullptr);
        if (gst_element_link_many(source_, converter_, encoder_, parser_, payload_, sink_, nullptr) != true)
        {
            gst_object_unref(pipeline_);
            throw std::runtime_error("Pipeline elements could not be linked.");
        }
    }
    void Transmiter::TransmitData(const unsigned char *data)
    {
        GstBuffer *buffer = gst_buffer_new_wrapped_full((GstMemoryFlags)0, (gpointer *)data, img_size_, 0, img_size_, nullptr, nullptr);
        gst_app_src_push_buffer((GstAppSrc *)source_, buffer);    
    }
    void Transmiter::RosDataCallback(const sensor_msgs::ImageConstPtr &image)
    {
        send_delay_counter_ += 1;
        if (send_delay_counter_ >= data_send_delay_) // Reduce depth data transmission frequency to 1 Hz. Assuming that default is 30 Hz.
        {
            WatchDog::GetInstance().SignalHeartbeat(watchdog_key_);
            TransmitData(image->data.data());
            send_delay_counter_ = 0;
        }
    }
    void Transmiter::InitRosSubscibers()
    {
        img_sub_ = nh_.subscribe(cfg_.img_ros_topic_, 1, &Transmiter::RosDataCallback, this);
    }
    void Transmiter::PrintConfig() const
    {
        SystemMsg::ThrowInfo(ksys_msg_header_ + "Ros topic: " + cfg_.img_ros_topic_);
        SystemMsg::ThrowInfo(ksys_msg_header_ + "Image size: (" + std::to_string(cfg_.img_width_) + ", " + std::to_string(cfg_.img_height_) + ")");
        SystemMsg::ThrowInfo(ksys_msg_header_ + "Receiver port: " + std::to_string(cfg_.receiver_port_));
        SystemMsg::ThrowInfo(ksys_msg_header_ + "Receiver IP: " + cfg_.receiver_ip_);
        SystemMsg::ThrowInfo(ksys_msg_header_ + "Encoding: " + cfg_.img_encoding_);
    }
} // namespace diagstar