/* Std Libs */
#include <csignal>

/* Local Libs */
#include "master.hpp"
#include "sys_msg.hpp"

namespace diagstar
{
    Master *master_ptr = nullptr;

    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    //                        PUBLIC FUNCTIONS                            //
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

    Master::Master()
        : receivers_initialized_(false), gstreamer_loop_(nullptr), data_diag_man_(512)
    {
        SystemMsg::SetVerboseLevel(kverbose_level_);
    }
    void Master::Run()
    {
        if (receivers_initialized_)
        {
           // StartGStreamerLoop();
            data_diag_man_.ProtocolWorker();
           // gstreamer_thread_.Get().join();
           // data_diag_man_udp.worker_.Get().join();
        }
    }
    void Master::InititalizeReceivers()
    {
        // fisheye_stream_.Init();
        // depth_stream_.Init();

        data_diag_man_.AddDiagData<MaplabDiagnosticData>("/maplab_pose", 5000);
        data_diag_man_.AddDiagData<GroundStationData>("/groundstation/state", 5001);
        data_diag_man_.Init();

        // const bool fisheye_is_ready = fisheye_stream_.IsInitialized();
        // const bool depth_is_ready = depth_stream_.IsInitialized();
        const bool diag_data_man_is_ready = data_diag_man_.IsInitialized();
        // const bool modules_ready = fisheye_is_ready && depth_is_ready && diag_data_man_is_ready;

        // if (!modules_ready)
        // {
        //     if (!fisheye_is_ready)
        //     {
        //         SystemMsg::ThrowError(ksys_msg_header_ + "Fisheye stream intitialization failed.");
        //     }
        //     else if (!depth_is_ready)
        //     {
        //         SystemMsg::ThrowError(ksys_msg_header_ + "Depth stream intitialization failed.");
        //     }
        //     else if (!diag_data_man_is_ready)
        //     {
        //         SystemMsg::ThrowError(ksys_msg_header_ + "Diagnostic data manager intitialization failed.");
        //     }
        // }
     //   else
      //  {
            SystemMsg::ThrowOk(ksys_msg_header_ + "Transmiters intitialized.");
            receivers_initialized_ = true;
            master_ptr = this;
            signal(SIGINT, [](int sig) { master_ptr->QuitInterrupt(sig); });
      //  }
    }
    void Master::QuitInterrupt(int sig)
    {
        try
        {
           // g_main_loop_quit(gstreamer_loop_);
           // fisheye_stream_.QuitInterrupt(sig);
            //depth_stream_.QuitInterrupt(sig);
            data_diag_man_.QuitInterrupt(sig);
            SystemMsg::ThrowOk(ksys_msg_header_ + "Process succefully stopped.");
        }
        catch (int error)
        {
            SystemMsg::ThrowError(ksys_msg_header_ + "Can't stop process. Force exit.");
            throw EXIT_FAILURE;
        }
    }

    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    //                        PRIVATE FUNCTIONS                           //
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

    void Master::StartGStreamerLoop()
    {
        SystemMsg::ThrowInfo(ksys_msg_header_ + "Starting gstreamer loop.");
        gstreamer_loop_ = g_main_loop_new(nullptr, false);
        gstreamer_thread_ = ThreadRAII(std::thread([this]() { g_main_loop_run(gstreamer_loop_); }), ThreadRAII::Action::JOIN);
    }

} // namespace diagstar