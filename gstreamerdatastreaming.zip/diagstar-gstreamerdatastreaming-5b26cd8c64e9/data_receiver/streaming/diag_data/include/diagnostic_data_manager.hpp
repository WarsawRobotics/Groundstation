#ifndef DIAGNOSTIC_DATA_MANAGER_HPP
#define DIAGNOSTIC_DATA_MANAGER_HPP

/* Local Libs */
#include "diagnostic_data_base.hpp"
#include "tcp_protocol.hpp"
#include "threadRAII.hpp"
#include "udp_protocol.hpp"

namespace diagstar
{
    template <typename ProtocolType>
    class DataDiagManager
    {
        using DignosticDataPtr = std::unique_ptr<DiagnosticDataBase>;
        using DiagnosticDataList = std::vector<DignosticDataPtr>;

    public:
        template <typename... Args>
        DataDiagManager(Args &&... args)
            : diag_data_number_(0), is_initialized_(false), protocol_(std::forward<Args>(args)...)
        {
        }
        template <typename DiagDataType, typename... Args>
        void AddDiagData(Args &&... args) noexcept
        {
            diag_data_list.emplace_back(std::make_unique<DiagDataType>(std::forward<Args>(args)...));
            ++diag_data_number_;
        }
        void Init()
        {
            try
            {
                SystemMsg::ThrowInfo(ksys_msg_header_ + "Initialized with " + std::to_string(diag_data_number_) + " diagnostic data.");
                for (auto &diag_data : diag_data_list)
                {
                    diag_data->Init();
                    protocol_.AddReceiver(diag_data->GetPort());
                }
                is_initialized_ = true;
            }
            catch (const std::runtime_error &e)
            {
                SystemMsg::ThrowError(ksys_msg_header_ + e.what());
            }
            catch (...)
            {
                SystemMsg::ThrowError(ksys_msg_header_ + "Unknown error occured. Aborting.");
            }
        }
        void ProtocolWorker()
        {
            if (is_initialized_)
            {
                worker_ = ThreadRAII(std::thread([&] { protocol_.Listen(&DataDiagManager::Notify, *this); }), ThreadRAII::Action::JOIN);
            }
            else
            {
                SystemMsg::ThrowWarn(ksys_msg_header_ + "Initialization not complete.");
            }
        }
        void QuitInterrupt(int sig)
        {
            protocol_.QuitInterrupt(sig);
        }
        bool IsInitialized() const noexcept
        {
            return is_initialized_ == true;
        }

        ThreadRAII worker_;
        DataDiagManager(DataDiagManager &&manager) = default;
        DataDiagManager() = delete;

    private:
        void
        Notify(const mavlink_message_t &data, const uint8_t &receiver_id)
        {
            diag_data_list[receiver_id]->PublishData(data);
        }

        friend ProtocolType;
        ProtocolType protocol_;
        DiagnosticDataList diag_data_list;
        bool is_initialized_;
        size_t diag_data_number_;
        const std::string ksys_msg_header_ = "[DataDiagManager] ";
    };
} // namespace diagstar

#endif //DIAGNOSTIC_DATA_MANAGER_HPP