#ifndef SEND_PROTOCOL_BASE_HPP
#define SEND_PROTOCOL_BASE_HPP

/* Std Libs */
#include <vector>

/* Local Libs */
#include "helpers.hpp"
#include "sys_msg.hpp"

/* 3d Party Libs */
#include "mavlink.h"

namespace diagstar
{
    class Protocol
    {
    public:
        Protocol(const size_t &buffer_size)
        {
            data_.resize(buffer_size);
        }
        virtual ~Protocol() {}
        virtual void Init() = 0;
        Protocol() = delete;

    protected:
        std::vector<uint8_t> data_;
    };

    template <typename Derived, typename ...Args>
    std::unique_ptr<Protocol> CreateProtocol(Args &&... args)
    {
        return std::make_unique<Derived>(std::forward<Args>(args)...);
    }
} // namespace diagstar

#endif //SEND_PROTOCOL_BASE_HPP