#ifndef DEPTH_GSTREAM_HPP
#define DEPTH_GSTREAM_HPP

#include "gstream_base.hpp"

namespace diagstar
{
    class DepthGStream : public GStreamBase<DepthGStream>
    {
    public:
        DepthGStream();

    private:
        void Initialize();

        friend class GStreamBase<DepthGStream>;
    };
};     // namespace diagstar
#endif //DEPTH_GSTREAM_HPP