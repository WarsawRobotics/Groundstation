#ifndef FISHEYE_GSTREAM_HPP
#define FISHEYE_GSTREAM_HPP

#include "gstream_base.hpp"

namespace diagstar
{
    class FisheyeGStream : public GStreamBase<FisheyeGStream>
    {
    public:
        FisheyeGStream();

    private:
        void Initialize();

        friend class GStreamBase<FisheyeGStream>;
    };
} // namespace diagstar

#endif //FISHEYE_GSTREAM_HPP