#! /bin/bash

# Display help message
if [ $1 == "--help" ]
then
    echo "GStreamer Processing Time Tool"
    echo
    echo "usage : $0 DIR [options]"
    echo
    echo "  DIR                            Input trace directory"
    echo "  --help                         This help message"
    echo
    exit
fi

# Verify if there is at least a parameter
if [ $# -lt 1 ]
then
    echo "Error: A directory name must be given"
    echo "Try '$0 --help' for more information."
    exit
fi

if [ ! -d $1 ]
then
    echo "Error: $1 is not a directory"
    echo "Try '$0 --help' for more information."
    exit
fi

processing_tracer_list=("proc_time")
parser_group_list1=("proc_time")

# Create readable file
babeltrace $1 > datastream.log
echo $1

# Remove previosuly created folders
for tracer in "${parser_group_list1[@]}"
do
if [ -d "${tracer}" ]; then rm -Rf ${tracer}; fi
done

# Loop through the tracer list 1
for tracer in "${parser_group_list1[@]}"
do
    echo "Loading ${tracer} events..."
    mkdir ${tracer}
    # Split the events in files
    grep -w ${tracer} datastream.log > ${tracer}"/"${tracer}.log
done

# Skip directory name
shift

# Create plots
echo "Creating plots for ${tracer}..."
./gstremer_parser ${tracer}"/" ${tracer}.log

rm -r ${tracer}"/"${tracer}.log

for filename in ${tracer}"/"*.log; 
do
    gnuplot --persist -e "plot '$filename' with lines"
done

echo "Removing temp files..."
# Remove files
rm -f datastream.log

echo "Done"