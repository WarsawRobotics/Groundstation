#ifndef __TIME_HPP__
#define __TIME_HPP__

#include <chrono>

struct Time
{
    using SysClkTimeStamp  = std::chrono::high_resolution_clock::time_point;
    using SysHighResClk    = std::chrono::high_resolution_clock;


    static double GetSystemTimeStamp()
    {
        auto now_s = std::chrono::time_point_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now());
        auto epoch = now_s.time_since_epoch();
        auto value = std::chrono::duration_cast<std::chrono::nanoseconds>(epoch);
        return static_cast<double>(value.count()) / 1000000000.0;
    }

    static double Millis2Sec(const double &millis)
    {
        return millis*0.001;
    }
    static double Millis2Nanos(const double &millis)
    {
        return millis*1000000.0;
    }
    static double Micros2Nanos(const double &micros)
    {
        return micros*1000.0;
    }
    static double GetSensorsTimeStampsOffset(const double &clk1, const double &clk2)
    {
        return clk1 - clk2;
    }
    template<typename TimeBase>
    static double GetSysTimeStampsOffset(SysClkTimeStamp &tstamp1, SysClkTimeStamp &tstamp2)
    {
        return std::chrono::duration_cast<TimeBase>(tstamp1 - tstamp2).count();
    }

};
#endif // __TIME_HPP__
