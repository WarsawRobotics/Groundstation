# Uwagi
- skrypt **proc_time_plot.sh** musi być w folderze pliku wykonywalnego np *build*
- parsuje tylko **processing time**
