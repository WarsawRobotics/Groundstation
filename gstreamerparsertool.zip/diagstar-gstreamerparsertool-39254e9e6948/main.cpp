#include <iostream>
#include <sstream>
#include <fstream>
#include <map>
#include <algorithm>
#include <vector>
#include "sys_msg.hpp"

using namespace system_msg;

using ProcTime = std::map<std::string, std::vector<std::pair<double, int>>>;

double ParseTimeFormat(const std::string &time_s)
{
    std::string hours, minutes, seconds;
    std::stringstream ss(time_s);

    std::getline(ss, hours, ':');
    std::getline(ss, minutes, ':');
    std::getline(ss, seconds, ':');

    return atof(hours.c_str()) * 3600.0 + atof(minutes.c_str()) * 60.0 + atof(seconds.c_str());
}
void ParseProcTime(ProcTime &proc_time, const std::string &line)
{
    std::string tmp;
    std::string sys_time;

    bool sys_time_flag = false;
    bool proc_time_flag = false;
    for (auto &r : line)
    {
        if ((sys_time_flag) && (r != ']'))
        {
            tmp += r;
        }
        if ((proc_time_flag) && (r != '}'))
        {
            tmp += r;
        }
        //----------- Processing time ------------//
        if (r == '{')
        {
            proc_time_flag = true;
        }
        else if (r == '}')
        {
            proc_time_flag = false;

            if (tmp != " ")
            {
                std::string element_line, element_str;
                std::string time_line, time_str;
                std::stringstream ss(tmp);

                std::getline(ss, element_line, ',');
                std::getline(ss, time_line, ',');

                element_line.erase(std::remove(element_line.begin(), element_line.end(), ' '), element_line.end());
                element_line.erase(std::remove(element_line.begin(), element_line.end(), '\"'), element_line.end());
                time_line.erase(std::remove(time_line.begin(), time_line.end(), ' '), time_line.end());

                std::stringstream ss_element(element_line);
                std::stringstream ss_time(time_line);

                std::getline(ss_element, element_str, '=');
                std::getline(ss_element, element_str, '=');

                std::getline(ss_time, time_str, '=');
                std::getline(ss_time, time_str, '=');

                if (proc_time.find(element_str) == proc_time.end())
                {
                    proc_time.insert(ProcTime::value_type(element_str, {std::make_pair(ParseTimeFormat(sys_time), atoi(time_str.c_str()))}));
                }
                else
                {
                    proc_time[element_str].push_back(std::make_pair(ParseTimeFormat(sys_time), atoi(time_str.c_str())));
                }
            }

            tmp.clear();
        }
        //----------- System time ------------//
        if (r == '[')
        {
            sys_time_flag = true;
        }
        else if (r == ']')
        {
            sys_time_flag = false;
            sys_time = tmp;
            tmp.clear();
        }
    }
}
void PrintElements(const ProcTime &proc_time, const std::string &path)
{
    double base_time = 0.0;
    bool init_flag = false;
    for (const auto &elem : proc_time)
    {
        std::ofstream of(path + elem.first + ".log");
        if (!init_flag)
        {
            base_time = elem.second.front().first;
            init_flag = true;
        }
        for (const auto &time_vec : elem.second)
        {
            //if (time_vec.second < 7000000)
            //{
                of << std::to_string(time_vec.first - base_time) << " " << std::to_string(time_vec.second * 0.000000001) << std::endl;
           // }
        }
        of.close();
    }
}

int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        ThrowSysMsg(SysMsgCode::ERROR, 2, "No log directory provided");
    }
    if (argc < 3)
    {
        ThrowSysMsg(SysMsgCode::ERROR, 2, "No log name provided");
    }
    ProcTime proc_time_s;
    const std::string path = argv[1];
    const std::string name = argv[2];

    std::ifstream in;
    in.open((path + name).c_str());

    if (in.fail())
    {
        ThrowSysMsg(SysMsgCode::ERROR, 2, "No log file in: " + path);
    }

    while (in.good())
    {
        std::string line;
        std::getline(in, line, '\n');
        ParseProcTime(proc_time_s, line);
    }
    PrintElements(proc_time_s, path);

    return 0;
}