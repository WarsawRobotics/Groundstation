/**
 * @file ros_master.cpp
 * @author Jacek Szaltys
 * @brief 
 * @version 0.1
 * @date 2019-09-02
 * 
 * @copyright Copyright (c) 2019
 * 
 */

/* Local libs */
#include "ros_master.hpp"

/* Std Libs */
#include <thread>

namespace diagstar
{
    RosMaster::RosMaster(RosMaster::Options &options) : ros_master_connected_(false)
    {
        ros::init(options.argc, options.argv, options.package_name, options.options);
        for (size_t i = 0; i < options.connection_attempts; ++i)
        {
            if (ros::master::check())
            {
                ROS_INFO_STREAM(ksys_msg_header_ + "Connected to ros master.");
                ros_master_connected_ = true;
                break;
            }
            else
            {
                ROS_WARN_STREAM(ksys_msg_header_ + "Cannot connect ros master. Sleep for " + std::to_string(options.connection_attempt_timeout.count()) + " [s].");
                std::this_thread::sleep_for(options.connection_attempt_timeout);
            }
        }
        if (!ros_master_connected_)
        {
            ROS_ERROR_STREAM(ksys_msg_header_ + "Cannot connect to ros master. Connection attempts exceeded threshold.");
        }
    }
    const bool &RosMaster::IsConnected() const noexcept
    {
        return ros_master_connected_;
    }
} // namespace diagstar