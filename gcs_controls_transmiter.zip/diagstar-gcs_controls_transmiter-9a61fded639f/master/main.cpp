
/* Std Libs */
#include <csignal>

/* Local Libs */
#include "ros_master.hpp"
#include "gcs_controls_transmiter.hpp"

static void quit_request(int sig)
{
    ros::shutdown();
}
int main(int argc, char *argv[])
{
    diagstar::RosMaster::Options ros_master_options =
    {
        "groundstation_controls_transmiter",
        3,
        std::chrono::seconds(5),
        ros::init_options::NoSigintHandler,
        argc,
        argv
    };

    diagstar::RosMaster ros_master(ros_master_options);
    if (ros_master.IsConnected())
    {
        diagstar::GroundStationControlsTransmiter gcs_controls_transmiter(diagstar::UdpProtocol("192.168.168.169", 5006), "groundstation/state", 512);
        gcs_controls_transmiter.Initialize();
        signal(SIGINT, quit_request);
        gcs_controls_transmiter.Run();
    }
    return 0;
}
