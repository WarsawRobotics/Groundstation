#pragma once
// MESSAGE ROVIO_FULL PACKING

#define MAVLINK_MSG_ID_ROVIO_FULL 335

MAVPACKED(
typedef struct __mavlink_rovio_full_t {
 uint64_t time_usec; /*< [us] Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude the number.*/
 float transform_x; /*< [m/s/s] X acceleration*/
 float transform_y; /*< [m/s/s] Y acceleration*/
 float transform_z; /*< [m/s/s] Z acceleration*/
 float extr_x; /*< [rad/s] Angular speed around X axis*/
 float extr_y; /*< [rad/s] Angular speed around Y axis*/
 float extr_z; /*< [rad/s] Angular speed around Z axis*/
 float transform_q[4];
 float extr_q[4];
}) mavlink_rovio_full_t;

#define MAVLINK_MSG_ID_ROVIO_FULL_LEN 64
#define MAVLINK_MSG_ID_ROVIO_FULL_MIN_LEN 64
#define MAVLINK_MSG_ID_335_LEN 64
#define MAVLINK_MSG_ID_335_MIN_LEN 64

#define MAVLINK_MSG_ID_ROVIO_FULL_CRC 253
#define MAVLINK_MSG_ID_335_CRC 253


#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_ROVIO_FULL { \
    335, \
    "ROVIO_FULL", \
    9, \
    {  { "time_usec", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_rovio_full_t, time_usec) }, \
	{ "transform_x", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_rovio_full_t, transform_x) }, \
         { "transform_y", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_rovio_full_t, transform_y) }, \
         { "transform_z", NULL, MAVLINK_TYPE_FLOAT, 0, 16, offsetof(mavlink_rovio_full_t, transform_z) }, \
         { "extr_x", NULL, MAVLINK_TYPE_FLOAT, 0, 20, offsetof(mavlink_rovio_full_t, extr_x) }, \
         { "extr_y", NULL, MAVLINK_TYPE_FLOAT, 0, 24, offsetof(mavlink_rovio_full_t, extr_y) }, \
         { "extr_z", NULL, MAVLINK_TYPE_FLOAT, 0, 28, offsetof(mavlink_rovio_full_t, extr_z) }, \
         { "transform_q", NULL, MAVLINK_TYPE_FLOAT, 4, 32, offsetof(mavlink_rovio_full_t, transform_q) }, \
         { "extr_q", NULL, MAVLINK_TYPE_UINT32_T, 4, 48, offsetof(mavlink_rovio_full_t, extr_q) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_ROVIO_FULL { \
    "CAM_TRIGG_IMU", \
    9, \
    {  { "time_usec", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_rovio_full_t, time_usec) }, \
	{ "transform_x", NULL, MAVLINK_TYPE_FLOAT, 0, 8, offsetof(mavlink_rovio_full_t, transform_x) }, \
         { "transform_y", NULL, MAVLINK_TYPE_FLOAT, 0, 12, offsetof(mavlink_rovio_full_t, transform_y) }, \
         { "transform_z", NULL, MAVLINK_TYPE_FLOAT, 0, 16, offsetof(mavlink_rovio_full_t, transform_z) }, \
         { "extr_x", NULL, MAVLINK_TYPE_FLOAT, 0, 20, offsetof(mavlink_rovio_full_t, extr_x) }, \
         { "extr_y", NULL, MAVLINK_TYPE_FLOAT, 0, 24, offsetof(mavlink_rovio_full_t, extr_y) }, \
         { "extr_z", NULL, MAVLINK_TYPE_FLOAT, 0, 28, offsetof(mavlink_rovio_full_t, extr_z) }, \
         { "transform_q", NULL, MAVLINK_TYPE_FLOAT, 4, 32, offsetof(mavlink_rovio_full_t, transform_q) }, \
         { "extr_q", NULL, MAVLINK_TYPE_UINT32_T, 4, 48, offsetof(mavlink_rovio_full_t, extr_q) }, \
         } \
}
#endif

/**
 * @brief Pack a rovio_full message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param imu_time_usec [us] Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude the number.
 * @param cam_time_usec [us]
 * @param xacc [m/s/s] X acceleration
 * @param yacc [m/s/s] Y acceleration
 * @param zacc [m/s/s] Z acceleration
 * @param xgyro [rad/s] Angular speed around X axis
 * @param ygyro [rad/s] Angular speed around Y axis
 * @param zgyro [rad/s] Angular speed around Z axis
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_rovio_full_pack(
	uint8_t system_id, 
	uint8_t component_id, 
	mavlink_message_t* msg,
	uint64_t time_usec, 
	float transform_x, 
	float transform_y, 
	float transform_z, 
	float extr_x, 
	float extr_y, 
	float extr_z, 
	const float *transform_q, 
	const float *extr_q)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_ROVIO_FULL_LEN];
    _mav_put_uint64_t(buf, 0, time_usec);
    _mav_put_float(buf, 8, transform_x);
    _mav_put_float(buf, 12, transform_y);
    _mav_put_float(buf, 16, transform_z);
    _mav_put_float(buf, 20, extr_x);
    _mav_put_float(buf, 24, extr_y);
    _mav_put_float(buf, 28, extr_z);
    _mav_put_float_array(buf, 32, transform_q, 4);
    _mav_put_float_array(buf, 48, extr_q, 4);

    memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_ROVIO_FULL_LEN);
#else
    mavlink_rovio_full_t packet;
    packet.time_usec = time_usec;
    packet.transform_x = transform_x;
    packet.transform_y = transform_y;
    packet.transform_z = transform_z;
    packet.extr_x = extr_x;
    packet.extr_y = extr_y;
    packet.extr_z = extr_z;
    mav_array_memcpy(packet.transform_q, transform_q, sizeof(float)*4);
    mav_array_memcpy(packet.extr_q, extr_q, sizeof(float)*4);

    memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_ROVIO_FULL_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_ROVIO_FULL;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_ROVIO_FULL_MIN_LEN, MAVLINK_MSG_ID_ROVIO_FULL_LEN, MAVLINK_MSG_ID_ROVIO_FULL_CRC);
}

/**
 * @brief Pack a cam_trigg_imu message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param imu_time_usec [us] Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude the number.
 * @param cam_time_usec [us]
 * @param xacc [m/s/s] X acceleration
 * @param yacc [m/s/s] Y acceleration
 * @param zacc [m/s/s] Z acceleration
 * @param xgyro [rad/s] Angular speed around X axis
 * @param ygyro [rad/s] Angular speed around Y axis
 * @param zgyro [rad/s] Angular speed around Z axis
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_rovio_full_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg,
                              uint64_t time_usec, float transform_x, float transform_y, float transform_z, float extr_x, float extr_y, float extr_z, const float *transform_q, const float *extr_q)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_ROVIO_FULL_LEN];
    _mav_put_uint64_t(buf, 0, time_usec);
    _mav_put_float(buf, 8, transform_x);
    _mav_put_float(buf, 12, transform_y);
    _mav_put_float(buf, 16, transform_z);
    _mav_put_float(buf, 20, extr_x);
    _mav_put_float(buf, 24, extr_y);
    _mav_put_float(buf, 28, extr_z);
    _mav_put_float_array(buf, 32, transform_q, 4);
    _mav_put_float_array(buf, 48, extr_q, 4);

    memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_CAM_TRIGG_IMU_LEN);
#else
    mavlink_rovio_full_t packet;
    packet.time_usec = time_usec;
    packet.transform_x = transform_x;
    packet.transform_y = transform_y;
    packet.transform_z = transform_z;
    packet.extr_x = extr_x;
    packet.extr_y = extr_y;
    packet.extr_z = extr_z;
    mav_array_memcpy(packet.transform_q, transform_q, sizeof(float)*4);
    mav_array_memcpy(packet.extr_q, extr_q, sizeof(float)*4);

    memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_ROVIO_FULL_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_ROVIO_FULL;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_ROVIO_FULL_MIN_LEN, MAVLINK_MSG_ID_ROVIO_FULL_LEN, MAVLINK_MSG_ID_ROVIO_FULL_CRC);
}

/**
 * @brief Encode a rovio_full struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param rovio_full C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_rovio_full_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_rovio_full_t* rovio_full)
{
    return mavlink_msg_rovio_full_pack(
	system_id, 
	component_id, 
	msg, 
	rovio_full->time_usec, 
	rovio_full->transform_x, 
	rovio_full->transform_y,
	rovio_full->transform_z,
	rovio_full->extr_x,
	rovio_full->extr_y,
	rovio_full->extr_z,
	rovio_full->transform_q,
	rovio_full->extr_q);
}

/**
 * @brief Encode a rovio_full struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param rovio_full C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_rovio_full_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_rovio_full_t* rovio_full)
{
    return mavlink_msg_rovio_full_pack_chan(
	system_id, 
	component_id, 
	chan, 
	msg, 
	rovio_full->time_usec, 
	rovio_full->transform_x, 
	rovio_full->transform_y,
	rovio_full->transform_z,
	rovio_full->extr_x,
	rovio_full->extr_y,
	rovio_full->extr_z,
	rovio_full->transform_q,
	rovio_full->extr_q);
}


// MESSAGE ROVIO_FULL UNPACKING


/**
 * @brief Get field time_usec from rovio_full message
 *
 * @return [us] Timestamp (UNIX Epoch time or time since system boot). The receiving end can infer timestamp format (since 1.1.1970 or since system boot) by checking for the magnitude the number.
 */
static inline uint32_t mavlink_msg_rovio_full_get_time_usec(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint64_t(msg,  0);
}

/**
 * @brief Get field xacc from cam_trigg_imu message
 *
 * @return [m/s/s] X acceleration
 */
static inline float mavlink_msg_rovio_full_get_transform_x(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  8);
}

/**
 * @brief Get field yacc from cam_trigg_imu message
 *
 * @return [m/s/s] Y acceleration
 */
static inline float mavlink_msg_rovio_full_get_transform_y(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  12);
}

/**
 * @brief Get field zacc from cam_trigg_imu message
 *
 * @return [m/s/s] Z acceleration
 */
static inline float mavlink_msg_rovio_full_get_transform_z(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  16);
}

/**
 * @brief Get field xgyro from cam_trigg_imu message
 *
 * @return [rad/s] Angular speed around X axis
 */
static inline float mavlink_msg_rovio_full_get_extr_x(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  20);
}

/**
 * @brief Get field ygyro from cam_trigg_imu message
 *
 * @return [rad/s] Angular speed around Y axis
 */
static inline float mavlink_msg_rovio_full_get_extr_y(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  24);
}

/**
 * @brief Get field zgyro from cam_trigg_imu message
 *
 * @return [rad/s] Angular speed around Z axis
 */
static inline float mavlink_msg_rovio_full_get_extr_z(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  28);
}

/**
 * @brief Get field trigg_seq from cam_trigg_imu message
 *
 * @return Number of camera trigger signals
 */
static inline uint16_t mavlink_msg_rovio_full_get_transform_q(const mavlink_message_t* msg, float *transform_q)
{
    return _MAV_RETURN_float_array(msg, transform_q, 4, 32);
}

/**
 * @brief Get field is_triggered from cam_trigg_imu message
 *
 * @return Flag which indicates if camera trigger signal was sended
 */
static inline uint16_t mavlink_msg_rovio_full_get_extr_q(const mavlink_message_t* msg, float *extr_q)
{
    return _MAV_RETURN_float_array(msg, extr_q, 4, 48);
}

/**
 * @brief Decode a rovio_full message into a struct
 *
 * @param msg The message to decode
 * @param cam_trigg_imu C-struct to decode the message contents into
 */
static inline void mavlink_msg_rovio_full_decode(const mavlink_message_t* msg, mavlink_rovio_full_t* rovio_full)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    rovio_full->time_usec = mavlink_msg_rovio_full_get_time_usec(msg); 
    rovio_full->transform_x = mavlink_msg_rovio_full_get_transform_x(msg;
    rovio_full->transform_y = mavlink_msg_rovio_full_get_transform_y(msg;
    rovio_full->transform_z = mavlink_msg_rovio_full_get_transform_z(msg;
    rovio_full->extr_x = mavlink_msg_rovio_full_get_extr_x(msg);
    rovio_full->extr_y = mavlink_msg_rovio_full_get_extr_y(msg);
    rovio_full->extr_z = mavlink_msg_rovio_full_get_extr_z(msg);
    mavlink_msg_rovio_full_get_transform_q(msg, rovio_full->transform_q);
    mavlink_msg_rovio_full_get_extr_q(msg, rovio_full->extr_q);
#else
    uint8_t len = msg->len < MAVLINK_MSG_ID_ROVIO_FULL_LEN? msg->len : MAVLINK_MSG_ID_ROVIO_FULL_LEN;
    memset(rovio_full, 0, MAVLINK_MSG_ID_ROVIO_FULL_LEN);
    memcpy(rovio_full, _MAV_PAYLOAD(msg), len);
}
#endif
