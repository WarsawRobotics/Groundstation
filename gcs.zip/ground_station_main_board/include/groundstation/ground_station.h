#ifndef __GROUND_STATION_H__
#define __GROUND_STATION_H__

#include "3dx700039.h"
#include "hf27s10.h"
#include "hf45s10.h"
#include "switch.h"
#include "hid_link/hid_link_msg_ground_station_calibration.h"
#include <avr/eeprom.h>

/* Channels settings (mode 2)
   ____________________________________________________
  |                                                    |
  |      Throttle (+)               Pitch (+)          |
  |          ^                         ^               |
  |          |                         |               |
  |          |                         |               |
  |          |                         |               |
  |  ------------- > Yaw (+)   --------------> Roll(+) |   
  |          |                         |               | 
  |          |                         |               |
  |          |                         |               |
  |____________________________________________________|
   

 - channel 0         - throttle 
 - channel 1         - roll
 - channel 2         - pitch 
 - channel 3         - yaw
 - channel 4         - killswitch (inactive 1000 us, active 2000 us)
 - channel 5         - flight modes (manual 1000 us, position 1500 us, offboard 2000 us)
 - channel 6         - mission switch
 - channel 7         - manipulator switch
 - channel 12,13,8   - space mouse translation 
 - channel 9,10,11   - space mouse rotation 
*/

#ifdef __cplusplus
extern "C"
{
#endif
    typedef struct
    {
        ppm_out_t ppm_out;
        hf27s10_t joy1;
        hf45s10_t joy2;
        joy_3dx700039_t mouse;
        switch_t kill;
        switch_t mission;
        switch_t flight_modes;
        switch_t manipulator;
    } groundstation_t;

    void ground_station_init(groundstation_t *station);
    void ground_station_send_data(groundstation_t *station);
    void ground_station_read_data(groundstation_t *station);
    void ground_station_write_data_to_ppm(groundstation_t *station);
    void ground_station_write_joy_calibration_data(const groundstation_t *station, hid_link_ground_station_calibr_msg_t *calibr_data);
    void gorund_station_read_joy_calibration_data(const groundstation_t *station, hid_link_ground_station_calibr_msg_t *calibr_data);
    void ground_station_clear_calibration(const groundstation_t *station);
#ifdef __cplusplus
}
#endif
#endif //__GROUND_STATION_H__