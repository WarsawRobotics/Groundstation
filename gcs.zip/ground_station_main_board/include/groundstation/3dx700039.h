#ifndef __3DX700039_H__
#define __3DX700039_H__

#include "common.h"
#include <HardwareSerial.h>

#define JOY_3DX700039_READ_MAX_POS 350.0f
#define JOY_3DX700039_READ_MIN_POS -350.0f
#ifdef __cplusplus
extern "C"
{
#endif

    typedef struct joy_3dx700039_settings
    {
        const uint8_t uart_id;
        const uint8_t tx_channel;
        const uint8_t ty_channel;
        const uint8_t tz_channel;
        const uint8_t rx_channel;
        const uint8_t ry_channel;
        const uint8_t rz_channel;
    }joy_3dx700039_settings_t;

    typedef struct joy_3dx700039
    {
        float tx_ppm_time_us;
        float ty_ppm_time_us;
        float tz_ppm_time_us;
        float rx_ppm_time_us;
        float ry_ppm_time_us;
        float rz_ppm_time_us;
        joy_3dx700039_settings_t settings;
    } joy_3dx700039_t;

    enum
    {
        JOY_3DX700039_UART1,
        JOY_3DX700039_UART2,
        JOY_3DX700039_UART3,
        JOY_3DX700039_UART4,
        JOY_3DX700039_UART5
    };

    void joy_3dx700039_init(joy_3dx700039_t *mouse, const joy_3dx700039_settings_t settings);
    bool joy_3dx700039_read_auto_data(joy_3dx700039_t *mouse);
    void joy_3dx700039_write_ppm(const joy_3dx700039_t *mouse, ppm_out_t *ppm);
#ifdef __cplusplus
}
#endif
#endif //__3DX700039_H__