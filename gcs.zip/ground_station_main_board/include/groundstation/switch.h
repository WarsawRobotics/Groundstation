/**
 * @file switches_to_ppm.h
 * @author Jacek Szaltys
 * @brief 
 * @version 0.1
 * @date 2019-09-02
 * 
 * @copyright Copyright (c) 2019
 * 
 */
#ifndef SWITCH_H
#define SWITCH_H

#include "common.h"

#ifdef __cplusplus
extern "C"
{
#endif

    typedef struct switch_settings
    {
        const uint8_t pin1;
        const uint8_t pin2;
        const uint8_t type;
        const uint8_t channel;
    } switch_settings_t;
    typedef struct
    {
        float ppm_time_us;
        switch_settings_t settings;
        uint8_t error;
    } switch_t;
    enum
    {
        TWO_STATE_SWITCH,
        TRI_STATE_SWITCH
    };
    void switch_read(switch_t *sw);
    void switch_init(switch_t *sw, const switch_settings_t settings);
    void switch_write_to_ppm(const switch_t *sw,  ppm_out_t *ppm);
#ifdef __cplusplus
}
#endif
#endif //SWITCHES_TO_PPM_H