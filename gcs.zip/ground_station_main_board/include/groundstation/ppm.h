#ifndef __PPM_H__
#define __PPM_H__

#include "core_pins.h"
#include "kinetis.h"
#include <stdbool.h>

#ifdef __AVR__
#error "Sorry, PulsePosition does not work on Teensy 2.0 and other AVR-based boards"
#endif

#define PULSEPOSITION_MAXCHANNELS 16

#ifdef __cplusplus
extern "C"
{
#endif
    typedef struct ftm_channel
    {
        uint32_t csc;
        uint32_t cv;
    } ftm_channel_t;

    typedef struct ppm_out
    {
        uint32_t pulse_width[PULSEPOSITION_MAXCHANNELS + 1];
        uint32_t pulse_buffer[PULSEPOSITION_MAXCHANNELS + 1];
        uint32_t pulse_remaining;
        volatile uint8_t *framePinReg;
        volatile uint8_t framePinMask;
        ftm_channel_t *ftm;
        uint8_t state;
        uint8_t current_channel;
        uint8_t total_channels;
        uint8_t total_channels_buffer;
        uint8_t cscSet;
        uint8_t cscClear;
    } ppm_out_t;

    void ppm_out_init(ppm_out_t *ppm, int polarity);
    bool ppm_out_begin(ppm_out_t *ppm, uint8_t tx_pin, uint8_t frame_pin);
    bool ppm_out_write(ppm_out_t *ppm, uint8_t channel, float microseconds);
    void ppm_out_isr(ppm_out_t *ppm);
#endif
#ifdef __cplusplus
}
#endif // __PPM_H__