#ifndef SPORT_H
#define SPORT_H

#include "common.h"

#define SPORT_SENSOR_DATA_PACKET_SIZE 8

#ifdef __cplusplus
extern "C"
{
#endif
    typedef struct
    {
        uint8_t packet[SPORT_SENSOR_DATA_PACKET_SIZE];
        uint8_t read_packet_state;
        uint8_t packet_data_counter;
        uint8_t current_polled_sensor_id;
    } sport_t;

    enum 
    {
        SPORT_UART1,
        SPORT_UART2,
        SPORT_UART3,
        SPORT_UART4,
        SPORT_UART5
    };

    void sport_init(sport_t *sport, const uint8_t uart_number);
    bool sport_read_and_decode(sport_t *sport);

#ifdef __cplusplus
}
#endif
#endif //SPORT_H