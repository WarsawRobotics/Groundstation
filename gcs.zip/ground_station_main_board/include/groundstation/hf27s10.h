#ifndef __HF27S10_H__
#define __HF27S10_H__

#include "common.h"

#define HF27S10_AXIS_SCALE_FACTOR 10000

#ifdef __cplusplus
extern "C"
{
#endif
    typedef struct hf27s10_settings
    {
        const float analog_scale;
        const uint8_t axis_x_pin;
        const uint8_t axis_y_pin;
        const uint8_t axis_x_channel;
        const uint8_t axis_y_channel;
        const uint8_t calibr_data_eeprom_adr;
    } hf27s10_settings_t;

    typedef struct hf27s10
    {
        float axis_x_ppm_time_us;
        float axis_y_ppm_time_us;
        hf27s10_settings_t settings;
    } hf27s10_t;

    void hf27s10_init(hf27s10_t *joy, const hf27s10_settings_t settings);
    void hf27s10_read(hf27s10_t *joy);
    void hf27s10_write_ppm(const hf27s10_t *joy, ppm_out_t *ppm_out);
    void hf27s10_update_calibration_data(const hf27s10_t *joy);
#ifdef __cplusplus
}
#endif
#endif //__HF27S10_H__