#ifndef __HF45S10_H__
#define __HF45S10_H__

#include "common.h"

#define HF45S10_AXIS_SCALE_FACTOR 10000

#ifdef __cplusplus
extern "C"
{
#endif
    typedef struct hf45s10_settings
    {
        const float analog_scale;
        const uint8_t axis_x_pin;
        const uint8_t axis_y_pin;
        const uint8_t axis_z_pin;
        const uint8_t axis_x_channel;
        const uint8_t axis_y_channel;
        const uint8_t axis_z_channel;
        const uint8_t calibr_data_eeprom_adr;
    } hf45s10_settings_t;
    typedef struct hf45s10
    {
        float axis_x_ppm_time_us;
        float axis_y_ppm_time_us;
        float axis_z_ppm_time_us;
        hf45s10_settings_t settings;
    } hf45s10_t;

    void hf45s10_init(hf45s10_t *joy, const hf45s10_settings_t settings);
    void hf45s10_read(hf45s10_t *joy);
    void hf45s10_write_ppm(const hf45s10_t *joy, ppm_out_t *ppm_out);
    void hf45s10_update_calibration_data(const hf45s10_t *joy);
#ifdef __cplusplus
}
#endif
#endif //__HF45S10_H__