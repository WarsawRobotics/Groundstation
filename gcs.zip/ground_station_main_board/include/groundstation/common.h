#ifndef __COMMON_H__
#define __COMMON_H__

#include "hid_link/hid_link.h"
#include "ppm.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>

#define PPM_MAX_TIME 2000.0
#define PPM_HALF_TIME 1500.0
#define PPM_MIN_TIME 1000.0

#define ANALOG_BIT_RESOLUTION 16.0
#define ANALOG_READ_SCALE 0.000050354f

#define LINEAR_SCALE_FACTOR(x0, y0, x1, y1) ((y1 - y0) / (x1 - x0))
#define LINEAR_SCALE_OFFSET(x0, y0, x1, y1) (y0 - ((y1 - y0) / (x1 - x0)) * x0)

#define PPM_SCALE_FACTOR(x_min, x_max) ((PPM_MAX_TIME - (PPM_MIN_TIME)) / (x_max - (x_min)))
#define PPM_SCALE_OFFSET(x_min, x_max) ((PPM_MIN_TIME - PPM_SCALE_FACTOR(x_min, x_max)*x_min))
#define RAW_VALUE_TO_PPM(value, a, b) ((a) * (value) + (b))


#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// static uint8_t* float_to_bytes(float value)
// {
//     uint8_t *bytes = (uint8_t*)malloc(sizeof(float) * sizeof(uint8_t));
//     uint32_t float_as_32_int = *((int *)&value);

//     for (uint8_t i = 0; i < sizeof(float); i++)
//     {
//         bytes[i] = (float_as_32_int >> 8 * i) & 0xFF;
//     }

//     return bytes;
// }
static int16_t bound_int16_t(int16_t value, const int16_t max, const int16_t min)
{
    if (value < min)
    {
        return min;
    }
    else if (value > max)
    {
        return max;
    }
    else
    {
        return value;
    }
}
static float deadzone_float(float value, const float des_value, const float upper_bound, const float lower_bound)
{
    return (value > lower_bound && value <= upper_bound) ? des_value : value;
}
static float bound_float(float value, const float max, const float min)
{
    if (value < min)
    {
        return min;
    }
    else if (value > max)
    {
        return max;
    }
    else
    {
        return value;
    }
}
#endif //__COMMON_H__