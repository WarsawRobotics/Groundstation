#ifndef HID_LINK_MSG_GROUND_STATION
#define HID_LINK_MSG_GROUND_STATION


#include "hid_link.h"

#ifdef __cplusplus
extern "C"
{
#endif
    typedef struct
    {
        uint32_t timestamp;
        uint16_t pitch_ppm_time;
        uint16_t roll_ppm_time;
        uint16_t throttle_ppm_time;
        uint16_t yaw_ppm_time;
        uint16_t tx_ppm_time;
        uint16_t ty_ppm_time;
        uint16_t tz_ppm_time;
        uint16_t rx_ppm_time;
        uint16_t ry_ppm_time;
        uint16_t rz_ppm_time;
        uint16_t kill_sw_ppm_time;
        uint16_t mission_sw_ppm_time;
        uint16_t flight_modes_sw_ppm_time;
        uint16_t manipulator_sw_ppm_time;
        hid_link_msg_t hid_msg;
    } hid_link_ground_station_msg_t;

    static void hid_link_ground_station_msg_encode(uint8_t dev_id, hid_link_ground_station_msg_t *msg)
    {
        msg->hid_msg.dev_id = dev_id;
        msg->hid_msg.msg_id = GROUND_STATION_MSG_ID;
        memset(msg->hid_msg.data, 0, sizeof(uint8_t) * DATA_LEN);

        uint32_to_bytes(msg->timestamp, msg->hid_msg.data);
        uint16_to_bytes(msg->pitch_ppm_time, msg->hid_msg.data + 4);
        uint16_to_bytes(msg->roll_ppm_time, msg->hid_msg.data + 6);
        uint16_to_bytes(msg->throttle_ppm_time, msg->hid_msg.data + 8);
        uint16_to_bytes(msg->yaw_ppm_time, msg->hid_msg.data + 10);
        uint16_to_bytes(msg->tx_ppm_time, msg->hid_msg.data + 12);
        uint16_to_bytes(msg->ty_ppm_time, msg->hid_msg.data + 14);
        uint16_to_bytes(msg->tz_ppm_time, msg->hid_msg.data + 16);
        uint16_to_bytes(msg->rx_ppm_time, msg->hid_msg.data + 18);
        uint16_to_bytes(msg->ry_ppm_time, msg->hid_msg.data + 20);
        uint16_to_bytes(msg->rz_ppm_time, msg->hid_msg.data + 22);
        uint16_to_bytes(msg->kill_sw_ppm_time, msg->hid_msg.data + 24);
        uint16_to_bytes(msg->mission_sw_ppm_time, msg->hid_msg.data + 26);
        uint16_to_bytes(msg->flight_modes_sw_ppm_time, msg->hid_msg.data + 28);
        uint16_to_bytes(msg->manipulator_sw_ppm_time, msg->hid_msg.data + 30);
        hid_link_encode_msg(&(msg->hid_msg));
    }
    static void hid_link_ground_station_msg_decode(hid_link_ground_station_msg_t *msg)
    {
        const uint8_t *data = msg->hid_msg.data;
        bytes_to_uint32(data, &(msg->timestamp));
        bytes_to_uint16(data + 4, &(msg->pitch_ppm_time));
        bytes_to_uint16(data + 6, &(msg->roll_ppm_time));
        bytes_to_uint16(data + 8, &(msg->throttle_ppm_time));
        bytes_to_uint16(data + 10, &(msg->yaw_ppm_time));
        bytes_to_uint16(data + 12, &(msg->tx_ppm_time));
        bytes_to_uint16(data + 14, &(msg->ty_ppm_time));
        bytes_to_uint16(data + 16, &(msg->tz_ppm_time));
        bytes_to_uint16(data + 18, &(msg->rx_ppm_time));
        bytes_to_uint16(data + 20, &(msg->ry_ppm_time));
        bytes_to_uint16(data + 22, &(msg->rz_ppm_time));
        bytes_to_uint16(data + 24, &(msg->kill_sw_ppm_time));
        bytes_to_uint16(data + 26, &(msg->mission_sw_ppm_time));
        bytes_to_uint16(data + 28, &(msg->flight_modes_sw_ppm_time));
        bytes_to_uint16(data + 30, &(msg->manipulator_sw_ppm_time));
    }
#ifdef __cplusplus
}
#endif

#endif //GROUND_STATION_MSG
