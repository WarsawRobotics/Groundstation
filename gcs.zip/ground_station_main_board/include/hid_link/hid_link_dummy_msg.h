#ifndef HID_LINK_MSG_DUMMY
#define HID_LINK_MSG_DUMMY

#include "hid_link.h"

#ifdef __cplusplus
extern "C"
{
#endif
    typedef struct
    {
        uint32_t timestamp;
        uint8_t error_code;
        hid_link_msg_t hid_msg;
    } hid_link_dummy_msg_t;

    static void hid_link_dummy_msg_encode(uint8_t dev_id, uint8_t msg_id, hid_link_dummy_msg_t *msg)
    {
        msg->hid_msg.dev_id = dev_id;
        msg->hid_msg.msg_id = msg_id;
        memset(msg->hid_msg.data, 0, sizeof(uint8_t) * DATA_LEN);
        uint32_to_bytes(msg->timestamp, msg->hid_msg.data + 0);
        msg->hid_msg.data[4] = msg->error_code;
        hid_link_encode_msg(&(msg->hid_msg));
    }
    static void hid_link_dummy_msg_decode(hid_link_dummy_msg_t *msg, hid_link_msg_t *hid_msg)
    {
        bytes_to_uint32(hid_msg->data + 0, &(msg->timestamp));
        msg->error_code = hid_msg->data[4];
    }
#ifdef __cplusplus
}
#endif
#endif // HID_LINK_MSG_DUMMY