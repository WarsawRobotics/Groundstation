#ifndef HID_LINK_MSG_GROUND_STATION_CALIBRATION
#define HID_LINK_MSG_GROUND_STATION_CALIBRATION

#include "hid_link.h"

#ifdef __cplusplus
extern "C"
{
#endif
    typedef struct
    {
        uint16_t throttle_min_max[2];
        uint16_t yaw_min_max[2];
        uint16_t pitch_min_max[2];
        uint16_t roll_min_max[2];
        uint32_t timestamp;
        hid_link_msg_t hid_msg;
    } hid_link_ground_station_calibr_msg_t;

    static void hid_link_ground_station_calibr_msg_encode(uint8_t dev_id, hid_link_ground_station_calibr_msg_t *msg)
    {
        msg->hid_msg.dev_id = dev_id;
        msg->hid_msg.msg_id = GROUND_STATION_CALIBRATION_MSG_ID;
        memset(msg->hid_msg.data, 0, sizeof(uint8_t) * DATA_LEN);

        msg->hid_msg.data[0] = msg->timestamp >> 0x18;
        msg->hid_msg.data[1] = msg->timestamp >> 0x10;
        msg->hid_msg.data[2] = msg->timestamp >> 0x08;
        msg->hid_msg.data[3] = msg->timestamp & 0xFF;

        msg->hid_msg.data[4] = msg->throttle_min_max[0] >> 0x08;
        msg->hid_msg.data[5] = msg->throttle_min_max[0] & 0xFF;
        msg->hid_msg.data[6] = msg->throttle_min_max[1] >> 0x08;
        msg->hid_msg.data[7] = msg->throttle_min_max[1] & 0xFF;

        msg->hid_msg.data[8] = msg->yaw_min_max[0] >> 0x08;
        msg->hid_msg.data[9] = msg->yaw_min_max[0] & 0xFF;
        msg->hid_msg.data[10] = msg->yaw_min_max[1] >> 0x08;
        msg->hid_msg.data[11] = msg->yaw_min_max[1] & 0xFF;

        msg->hid_msg.data[12] = msg->pitch_min_max[0] >> 0x08;
        msg->hid_msg.data[13] = msg->pitch_min_max[0] & 0xFF;
        msg->hid_msg.data[14] = msg->pitch_min_max[1] >> 0x08;
        msg->hid_msg.data[15] = msg->pitch_min_max[1] & 0xFF;

        msg->hid_msg.data[16] = msg->roll_min_max[0] >> 0x08;
        msg->hid_msg.data[17] = msg->roll_min_max[0] & 0xFF;
        msg->hid_msg.data[18] = msg->roll_min_max[1] >> 0x08;
        msg->hid_msg.data[19] = msg->roll_min_max[1] & 0xFF;

        hid_link_encode_msg(&(msg->hid_msg));
    }
    static void hid_link_ground_station_calibr_msg_decode(hid_link_ground_station_calibr_msg_t *msg, hid_link_msg_t *hid_msg)
    {
        uint8_t *data = hid_msg->data;

        msg->timestamp = (data[0] << 0x18) | (data[1] << 0x10) | (data[2] << 0x08) | data[3];

        msg->throttle_min_max[0] = (data[4] << 0x08) | (data[5] & 0xFF);
        msg->throttle_min_max[1] = (data[6] << 0x08) | (data[7] & 0xFF);

        msg->yaw_min_max[0] = (data[8] << 0x08) | (data[9] & 0xFF);
        msg->yaw_min_max[1] = (data[10] << 0x08) | (data[11] & 0xFF);

        msg->pitch_min_max[0] = (data[12] << 0x08) | (data[13] & 0xFF);
        msg->pitch_min_max[1] = (data[14] << 0x08) | (data[15] & 0xFF);

        msg->roll_min_max[0] = (data[16] << 0x08) | (data[17] & 0xFF);
        msg->roll_min_max[1] = (data[18] << 0x08) | (data[19] & 0xFF);
    }

#ifdef __cplusplus
}
#endif
#endif //HID_LINK_MSG_GROUND_STATION_CALIBRATION