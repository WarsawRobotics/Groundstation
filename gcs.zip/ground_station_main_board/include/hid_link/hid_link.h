/**
 * @file hid_simple_protocol.h
 * @author Jacek Szaltys
 * @brief 
 * @version 0.1
 * @date 2019-09-25
 * 
 * @copyright Copyright (c) 2019
 * 
 */
#ifndef HID_LINK
#define HID_LINK

#ifdef USB_RAWHID
#define DATA_LEN 59

#include "hid_link_common.h"

#ifdef __cplusplus
extern "C"
{
#endif
    typedef struct
    {
        uint8_t data[DATA_LEN];
        uint8_t msg[RAWHID_RX_SIZE];
        uint8_t dev_id, msg_id;
    } hid_link_msg_t;

    int hid_link_receive_msg(hid_link_msg_t *hid_msg, int timeout);
    void hid_link_send_msg(hid_link_msg_t *hid_msg, int timeout);
    int hid_link_decode_msg(hid_link_msg_t *hid_msg);
    void hid_link_encode_msg(hid_link_msg_t *hid_msg);
#ifdef __cplusplus
}
#endif

#endif
#endif //HID_LINK