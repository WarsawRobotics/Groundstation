#ifndef HID_LINK_COMMON_H
#define HID_LINK_COMMON_H

#include <usb_rawhid.h>
#include <stdbool.h>
#include <stdint.h>
#include <string.h>

//------- DEVICES IDS -----------
#define UAV_RC_RECEIVER 0x63
#define UAV_VIO_LOW_LEVEL 0x64
#define UAV_VIO_HIGH_LEVEL 0x65
#define GCS_RC_TRANSMITER 0x66
#define GCS_RC_TRANSMITER_HOST 0x67

// ------- MSGS IDS ---------------
#define GROUND_STATION_MSG_ID 0x11
#define GROUND_STATION_CALIBRATION_MSG_ID 0x12
#define GROUND_STATION_CLEAR_CALIBRATION_MSG_ID 0x13
#define GROUND_STATION_CALIBRATION_DATA_REQUEST 0x14
#define HEARTBEAT_MSG_ID 0x15
#define VIO_DATA_MSG_ID 0x16
#define CAMERA_EXPOSURE_MSG_ID 0x17
#define DATA_TRANSMISSION_REQUEST 0x18
#define GROUND_STATION_HEALTH_CHECK_STATUS_REQUEST 0x19
#define GROUND_STATION_HEALTH_CHECK_STATUS_MSG 0x20

// ----------- HELPERS ------------
#define ARRAY_SIZE(x) (sizeof(x) / sizeof((x)[0]))
#ifdef __cplusplus
extern "C"
{
#endif
    typedef enum
    {
        OK = 0x00,
        RC_FAIL_SAFE = 0x01
    } hid_link_error_codes_t;

    static const char *hid_link_get_error_dsc(const uint8_t error_code)
    {
        switch (error_code)
        {
        case OK:
        {
            return "OK.";
            break;
        }
        case RC_FAIL_SAFE:
        {
            return "Rc receiver failsafe activated. Probably connection lost.";
            break;
        }
        default:
        {
            return "Error code not recognized.";
            break;
        }
        }
    }
    static void float_to_bytes(float value, uint8_t *bytes)
    {
        bytes[0] = (*((int *)&value) >> 8 * 0) & 0xFF;
        bytes[1] = (*((int *)&value) >> 8 * 1) & 0xFF;
        bytes[2] = (*((int *)&value) >> 8 * 2) & 0xFF;
        bytes[3] = (*((int *)&value) >> 8 * 3) & 0xFF;
    }
    static void uint32_to_bytes(uint32_t value, uint8_t *bytes)
    {
        bytes[0] = value >> 0x18;
        bytes[1] = value >> 0x10;
        bytes[2] = value >> 0x08;
        bytes[3] = value & 0xFF;
    }
    static void uint16_to_bytes(uint16_t value, uint8_t *bytes)
    {
        bytes[0] = value >> 0x08;
        bytes[1] = value & 0xFF;
    }
    static void uint16s_to_bytes(const uint16_t *values, uint16_t size, uint8_t *bytes)
    {
        for (uint16_t i = 0; i < size; i++)
        {
            bytes[0 + 2 * i] = values[i] >> 0x08;
            bytes[1 + 2 * i] = values[i] & 0xFF;
        }
    }
    static void bytes_to_uint16s(const uint8_t *bytes, uint16_t *values, uint8_t size)
    {
        for (uint16_t i = 0; i < size; i++)
        {
            values[i] = (bytes[0 + 2 * i] << 0x08) | (bytes[1 + 2 * i] & 0xFF);
        }
    }
    static void bytes_to_float(const uint8_t *bytes, float *value)
    {
        *((uint8_t *)(value) + 3) = bytes[3];
        *((uint8_t *)(value) + 2) = bytes[2];
        *((uint8_t *)(value) + 1) = bytes[1];
        *((uint8_t *)(value) + 0) = bytes[0];
    }
    static void bytes_to_uint32(const uint8_t *bytes, uint32_t *value)
    {
        *value = (bytes[0] << 0x18) | (bytes[1] << 0x10) | (bytes[2] << 0x08) | bytes[3];
    }
    static void bytes_to_uint16(const uint8_t *bytes, uint16_t *value)
    {
        *value = (bytes[0] << 0x08) | bytes[1];
    }
    static uint16_t uint16_bound(const uint16_t val, const uint16_t min, const uint16_t max)
    {
        if (val > max)
        {
            return max;
        }
        else if (val < min)
        {
            return min;
        }
        else
        {
            return val;
        }
    }
#ifdef __cplusplus
}
#endif
#endif //HID_LINK_COMMON_H