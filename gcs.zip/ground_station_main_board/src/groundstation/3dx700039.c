#include "groundstation/3dx700039.h"
#include "core_pins.h"

#define CMD_SET_ZERO_POSITION 0xAD
#define CMD_RESPONSE_END_BYTE 0x8D
#define CMD_AUTO_DATA_ON 0xAE
#define CMD_AUTO_DATA_OFF 0xAF
#define CMD_REQUEST_DATA 0xAC
#define DATA_START_BYTE 0x96
#define RAW_TO_REAL_VALUE(high_byte, low_byte) (((high_byte)*128 + (low_byte)) - 8192)
#define MSG_FRAME_BYTES_3DX700039 15

static void (*uart_begin)(uint32_t);
static int (*uart_read)(void);
static void (*uart_write)(uint32_t);
static int (*uart_available)(void);
static uint32_t uart_baud_rate = 0;

static uint8_t msg[MSG_FRAME_BYTES_3DX700039 + 1];
static bool data_start = false;
static int data_counter = 0;

static float ppm_scale_factor = PPM_SCALE_FACTOR(0.0f, 2.f * JOY_3DX700039_READ_MAX_POS);
static float ppm_scale_offset = PPM_SCALE_OFFSET(0.0f, 2.f * JOY_3DX700039_READ_MAX_POS);

static bool joy_3dx700039_parse_msg(joy_3dx700039_t *mouse);

void joy_3dx700039_send_cmd(joy_3dx700039_t *mouse, uint8_t cmd)
{
    const uint16_t response_sum = cmd + CMD_RESPONSE_END_BYTE;
    uint16_t response_computed = 0;

    uart_write(cmd);

    while (uart_available() > 0)
    {
        response_computed += uart_read();
        if (response_computed == response_sum)
        {
            break;
        }
        else if (response_computed > response_sum)
        {
            break;
        }
    }
    delay(1);
}
bool joy_3dx700039_calc_checksum(joy_3dx700039_t *mouse)
{
    const uint16_t checksum = msg[13] * 128 + msg[14];
    uint16_t calc_checksum = 0;
    for (uint8_t i = 0; i < 13; i++)
    {
        calc_checksum += msg[i];
    }
    return checksum == (calc_checksum & 0x3FFF) ? true : false;
}
void joy_3dx700039_init(joy_3dx700039_t *mouse, const joy_3dx700039_settings_t settings)
{
    memset(mouse, 0, sizeof(joy_3dx700039_t));
    memcpy(&mouse->settings, &settings, sizeof(joy_3dx700039_settings_t));

    switch (mouse->settings.uart_id)
    {
    case JOY_3DX700039_UART1:
    {
        uart_write = serial_putchar;
        uart_read = serial_getchar;
        uart_available = serial_available;
        uart_begin = serial_begin;
        uart_baud_rate = BAUD2DIV(38400);
        break;
    }
    case JOY_3DX700039_UART2:
    {
        uart_write = serial2_putchar;
        uart_read = serial2_getchar;
        uart_available = serial2_available;
        uart_begin = serial2_begin;
        break;
    }
    case JOY_3DX700039_UART3:
    {
        uart_write = serial3_putchar;
        uart_read = serial3_getchar;
        uart_available = serial3_available;
        uart_begin = serial3_begin;
        break;
    }
    case JOY_3DX700039_UART4:
    {
        uart_write = serial4_putchar;
        uart_read = serial4_getchar;
        uart_available = serial4_available;
        uart_begin = serial4_begin;
        break;
    }
    case JOY_3DX700039_UART5:
    {
        uart_write = serial5_putchar;
        uart_read = serial5_getchar;
        uart_available = serial5_available;
        uart_begin = serial5_begin;
        uart_baud_rate = BAUD2DIV3(38400);
        break;
    }
    default:
        break;
    }
    uart_begin(uart_baud_rate);
    delay(500);
    joy_3dx700039_send_cmd(mouse, CMD_SET_ZERO_POSITION);
    joy_3dx700039_send_cmd(mouse, CMD_AUTO_DATA_ON);
}
bool joy_3dx700039_read_auto_data(joy_3dx700039_t *mouse)
{
    bool result = false;
    while (uart_available() > 0)
    {
        const uint8_t data_raw = uart_read();

        if (data_start) // Save data only if captured start byte
        {
            msg[data_counter] = data_raw;
            data_counter++;
        }
        if (data_counter >= MSG_FRAME_BYTES_3DX700039)
        {
            result = joy_3dx700039_parse_msg(mouse);
            data_start = false;
            data_counter = 0;
        }
        if (data_raw == DATA_START_BYTE && data_start == false) // Check for message start byte
        {
            msg[data_counter] = data_raw;
            data_counter++;
            data_start = true;
        }
    }
    return result;
}
bool joy_3dx700039_parse_msg(joy_3dx700039_t *mouse)
{
    const bool status = joy_3dx700039_calc_checksum(mouse);
    if (status)
    {
        const int16_t tx = bound_int16_t(RAW_TO_REAL_VALUE(msg[1], msg[2]), JOY_3DX700039_READ_MAX_POS, JOY_3DX700039_READ_MIN_POS);
        const int16_t ty = bound_int16_t(RAW_TO_REAL_VALUE(msg[3], msg[4]), JOY_3DX700039_READ_MAX_POS, JOY_3DX700039_READ_MIN_POS);
        const int16_t tz = bound_int16_t(RAW_TO_REAL_VALUE(msg[5], msg[6]), JOY_3DX700039_READ_MAX_POS, JOY_3DX700039_READ_MIN_POS);

        const int16_t rx = bound_int16_t(RAW_TO_REAL_VALUE(msg[7], msg[8]), JOY_3DX700039_READ_MAX_POS, JOY_3DX700039_READ_MIN_POS);
        const int16_t ry = bound_int16_t(RAW_TO_REAL_VALUE(msg[9], msg[10]), JOY_3DX700039_READ_MAX_POS, JOY_3DX700039_READ_MIN_POS);
        const int16_t rz = bound_int16_t(RAW_TO_REAL_VALUE(msg[11], msg[12]), JOY_3DX700039_READ_MAX_POS, JOY_3DX700039_READ_MIN_POS);

        mouse->tx_ppm_time_us = RAW_VALUE_TO_PPM(tx + JOY_3DX700039_READ_MAX_POS, ppm_scale_factor, ppm_scale_offset);
        mouse->ty_ppm_time_us = RAW_VALUE_TO_PPM(ty + JOY_3DX700039_READ_MAX_POS, ppm_scale_factor, ppm_scale_offset);
        mouse->tz_ppm_time_us = RAW_VALUE_TO_PPM(tz + JOY_3DX700039_READ_MAX_POS, ppm_scale_factor, ppm_scale_offset);

        mouse->rx_ppm_time_us = RAW_VALUE_TO_PPM(rx + JOY_3DX700039_READ_MAX_POS, ppm_scale_factor, ppm_scale_offset);
        mouse->ry_ppm_time_us = RAW_VALUE_TO_PPM(ry + JOY_3DX700039_READ_MAX_POS, ppm_scale_factor, ppm_scale_offset);
        mouse->rz_ppm_time_us = RAW_VALUE_TO_PPM(rz + JOY_3DX700039_READ_MAX_POS, ppm_scale_factor, ppm_scale_offset);
    }
    return status;
}
void joy_3dx700039_write_ppm(const joy_3dx700039_t *mouse, ppm_out_t *ppm)
{
    ppm_out_write(ppm, mouse->settings.tx_channel, mouse->tx_ppm_time_us);
    ppm_out_write(ppm, mouse->settings.ty_channel, mouse->ty_ppm_time_us);
    ppm_out_write(ppm, mouse->settings.tz_channel, mouse->tz_ppm_time_us);

    ppm_out_write(ppm, mouse->settings.rx_channel, mouse->rx_ppm_time_us);
    ppm_out_write(ppm, mouse->settings.ry_channel, mouse->ry_ppm_time_us);
    ppm_out_write(ppm, mouse->settings.rz_channel, mouse->rz_ppm_time_us);
}