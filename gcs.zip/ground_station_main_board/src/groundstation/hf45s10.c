#include "groundstation/hf45s10.h"
#include <avr/eeprom.h>
#include <string.h>

static float x_axis_ppm_scale_factor = 0.0f;
static float y_axis_ppm_scale_factor = 0.0f;
static float z_axis_ppm_scale_factor = 0.0f;

static float x_axis_ppm_scale_offset = 0.0f;
static float y_axis_ppm_scale_offset = 0.0f;
static float z_axis_ppm_scale_offset = 0.0f;

static float x_max_pos = 0.0f;
static float x_min_pos = 0.0f;

static float y_max_pos = 0.0f;
static float y_min_pos = 0.0f;

static float z_max_pos = 0.0f;
static float z_min_pos = 0.0f;

static uint8_t joysticks_calibration_flag = 0;

static void read_eeprom_calibr_data(const hf45s10_t *joy)
{
    x_max_pos = eeprom_read_byte((uint8_t *)(joy->settings.calibr_data_eeprom_adr + 0)) << 0x08 | eeprom_read_byte((uint8_t *)(joy->settings.calibr_data_eeprom_adr + 1));
    x_min_pos = eeprom_read_byte((uint8_t *)(joy->settings.calibr_data_eeprom_adr + 2)) << 0x08 | eeprom_read_byte((uint8_t *)(joy->settings.calibr_data_eeprom_adr + 3));
    y_max_pos = eeprom_read_byte((uint8_t *)(joy->settings.calibr_data_eeprom_adr + 4)) << 0x08 | eeprom_read_byte((uint8_t *)(joy->settings.calibr_data_eeprom_adr + 5));
    y_min_pos = eeprom_read_byte((uint8_t *)(joy->settings.calibr_data_eeprom_adr + 6)) << 0x08 | eeprom_read_byte((uint8_t *)(joy->settings.calibr_data_eeprom_adr + 7));
    z_max_pos = eeprom_read_byte((uint8_t *)(joy->settings.calibr_data_eeprom_adr + 8)) << 0x08 | eeprom_read_byte((uint8_t *)(joy->settings.calibr_data_eeprom_adr + 9));
    z_min_pos = eeprom_read_byte((uint8_t *)(joy->settings.calibr_data_eeprom_adr + 10)) << 0x08 | eeprom_read_byte((uint8_t *)(joy->settings.calibr_data_eeprom_adr + 11));

    x_max_pos /= (float)HF45S10_AXIS_SCALE_FACTOR;
    x_min_pos /= (float)HF45S10_AXIS_SCALE_FACTOR;
    y_max_pos /= (float)HF45S10_AXIS_SCALE_FACTOR;
    y_min_pos /= (float)HF45S10_AXIS_SCALE_FACTOR;
    z_max_pos /= (float)HF45S10_AXIS_SCALE_FACTOR;
    z_min_pos /= (float)HF45S10_AXIS_SCALE_FACTOR;

    x_axis_ppm_scale_factor = PPM_SCALE_FACTOR(x_min_pos, x_max_pos);
    x_axis_ppm_scale_offset = PPM_SCALE_OFFSET(x_min_pos, x_max_pos);
    y_axis_ppm_scale_factor = PPM_SCALE_FACTOR(y_min_pos, y_max_pos);
    y_axis_ppm_scale_offset = PPM_SCALE_OFFSET(y_min_pos, y_max_pos);
    z_axis_ppm_scale_factor = PPM_SCALE_FACTOR(z_min_pos, z_max_pos);
    z_axis_ppm_scale_offset = PPM_SCALE_OFFSET(z_min_pos, z_max_pos);

    joysticks_calibration_flag = eeprom_read_byte((uint8_t *)0x00);
}
void hf45s10_init(hf45s10_t *joy, const hf45s10_settings_t settings)
{
    memset(joy, 0, sizeof(hf45s10_t));
    memcpy(&joy->settings, &settings, sizeof(hf45s10_settings_t));

    joy->axis_x_ppm_time_us = 1500.f;
    joy->axis_y_ppm_time_us = 1500.f;
    joy->axis_z_ppm_time_us = 1500.f;

    pinMode(joy->settings.axis_x_pin, INPUT);
    pinMode(joy->settings.axis_y_pin, INPUT);
    pinMode(joy->settings.axis_z_pin, INPUT);

    read_eeprom_calibr_data(joy);
}
void hf45s10_read(hf45s10_t *joy)
{
    float x, y, z;
    if (joysticks_calibration_flag)
    {
        x = bound_float((float)analogRead(joy->settings.axis_x_pin) * joy->settings.analog_scale, x_max_pos, x_min_pos);
        y = bound_float((float)analogRead(joy->settings.axis_y_pin) * joy->settings.analog_scale, y_max_pos, y_min_pos);
        z = bound_float((float)analogRead(joy->settings.axis_z_pin) * joy->settings.analog_scale, z_max_pos, z_min_pos);
    }
    else
    {
        x = (float)analogRead(joy->settings.axis_x_pin) * joy->settings.analog_scale;
        y = (float)analogRead(joy->settings.axis_y_pin) * joy->settings.analog_scale;
        z = (float)analogRead(joy->settings.axis_z_pin) * joy->settings.analog_scale;
    }
    joy->axis_x_ppm_time_us = deadzone_float(RAW_VALUE_TO_PPM(x, x_axis_ppm_scale_factor, x_axis_ppm_scale_offset), 1500.f, 1540.f, 1460.f);
    joy->axis_y_ppm_time_us = deadzone_float(RAW_VALUE_TO_PPM(y, y_axis_ppm_scale_factor, y_axis_ppm_scale_offset), 1500.f, 1540.f, 1460.f);
  //  joy->axis_z_ppm_time_us = deadzone_float(RAW_VALUE_TO_PPM(z, z_axis_ppm_scale_factor, z_axis_ppm_scale_offset), 1500.f, 1525.f, 1460.f);

    
}
void hf45s10_write_ppm(const hf45s10_t *joy, ppm_out_t *ppm_out)
{
    ppm_out_write(ppm_out, joy->settings.axis_x_channel, joy->axis_x_ppm_time_us);
    ppm_out_write(ppm_out, joy->settings.axis_y_channel, joy->axis_y_ppm_time_us);
  //  ppm_out_write(ppm_out, joy->settings.axis_z_channel, joy->axis_z_ppm_time_us);
}
void hf45s10_update_calibration_data(const hf45s10_t *joy)
{
    read_eeprom_calibr_data(joy);
}