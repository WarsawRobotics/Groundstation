#include "groundstation/ground_station.h"
#include "hid_link/hid_link_dummy_msg.h"
#include <avr/eeprom.h>

groundstation_t ground_station;
void receive_data(void)
{
    hid_link_msg_t recv_data;
    if (hid_link_receive_msg(&recv_data, 1))
    {
        if (hid_link_decode_msg(&recv_data) > 0)
        {
            switch (recv_data.msg_id)
            {
            case GROUND_STATION_CALIBRATION_MSG_ID:
            {
                hid_link_ground_station_calibr_msg_t calibr_msg;
                hid_link_ground_station_calibr_msg_decode(&calibr_msg, &recv_data);
                ground_station_write_joy_calibration_data(&ground_station, &calibr_msg);
                break;
            }
            case GROUND_STATION_CLEAR_CALIBRATION_MSG_ID:
            {
                ground_station_clear_calibration(&ground_station);
                break;
            }
            case GROUND_STATION_CALIBRATION_DATA_REQUEST:
            {
                hid_link_ground_station_calibr_msg_t calibr_msg;
                gorund_station_read_joy_calibration_data(&ground_station, &calibr_msg);
                hid_link_ground_station_calibr_msg_encode(GCS_RC_TRANSMITER, &calibr_msg);
                hid_link_send_msg(&(calibr_msg.hid_msg), 0);
                break;
            }
            default:
                break;
            }
        }
    }
}
static void blink_led(uint8_t pin, uint32_t delay_ms)
{
    digitalWriteFast(pin, HIGH);
    delay(delay_ms);
    digitalWriteFast(pin, LOW);
}
static void send_heartbeat(void)
{
    static const uint32_t send_dt_ms = 1000;
    static uint32_t send_tnow_ms = 0;
    static hid_link_dummy_msg_t hearbeat_msg;
    //hearbeat_msg.error_code = error_code;

    // if (millis() - send_tnow_ms >= send_dt_ms)
    // {
    //     send_tnow_ms = millis();
    //     hearbeat_msg.timestamp = millis();
    //     hid_link_dummy_msg_encode(GCS_RC_TRANSMITER, HEARTBEAT_MSG_ID, &hearbeat_msg);
    //     hid_link_send_msg(&(hearbeat_msg.hid_msg), 1);
    //     blink_led(LED_BUILTIN, 1);
    // }
}
static void send_gcs_data(void)
{
    static const uint32_t hid_send_dt_ms = 10;
    static uint32_t hid_send_tnow_ms = 0;
    if (millis() - hid_send_tnow_ms >= hid_send_dt_ms)
    {
        hid_send_tnow_ms = millis();
        ground_station_send_data(&ground_station);
    }
}
static void read_gcs_data(void)
{
    static const uint32_t read_data_dt_us = 100;
    uint32_t read_data_tnow_us = 0;
    if (micros() - read_data_tnow_us >= read_data_dt_us)
    {
        read_data_tnow_us = micros();
        ground_station_read_data(&ground_station);
        ground_station_write_data_to_ppm(&ground_station);
    }
}

void main_process(void)
{
    while (1)
    {
        read_gcs_data();
        send_gcs_data();
        send_heartbeat();
        receive_data();
    }
}
void initialize(void)
{
    _init_Teensyduino_internal_();
    analogReadResolution(ANALOG_BIT_RESOLUTION);
    eeprom_initialize();
    ground_station_init(&ground_station);
    pinMode(13, OUTPUT);
}
int main(void)
{
    initialize();
    main_process();

    return 0;
}