#include "groundstation/sport.h"
#include <core_pins.h>
#include <HardwareSerial.h>

#define SPORT_BAUD_RATE 57600
#define SPORT_POLL_HEADER 0x7E
#define SPORT_FRSKY_SENSOR_ID 0x10
#define SPORT_STUFFING_BYTE 0x7D
#define SPORT_STUFFING_XOR_MASK 0x20

enum
{
    WAIT_FOR_POLL_HEADER,
    WAIT_FOR_SENSOR_ID,
    WAIT_FOR_SENSOR_DATA,
    DATA_IN_FRAME,
    DATA_IN_FRAME_XOR
};

static void (*sport_write)(uint32_t);
static void (*sport_flush)(void);
static int (*sport_read)(void);
static int (*sport_available)(void);

static bool sport_check_packet_crc(const sport_t *sport)
{
    short crc = 0x00;
    for (uint8_t i = 0; i < SPORT_SENSOR_DATA_PACKET_SIZE; ++i)
    {
        crc += sport->packet[i];
        crc += crc >> 8; //0-100
        crc &= 0x00ff;
        crc += crc >> 8; //0-0FF
        crc &= 0x00ff;
    }
    return crc == 0x00FF;
}

void sport_init(sport_t *sport, const uint8_t uart_number)
{
    bool init_status = true;
    sport->packet_data_counter = 0;
    sport->read_packet_state = WAIT_FOR_POLL_HEADER;
    memset((uint8_t *)sport->packet, 0, SPORT_SENSOR_DATA_PACKET_SIZE);
    switch (uart_number)
    {
    case SPORT_UART1:
    {
        serial_begin(BAUD2DIV(SPORT_BAUD_RATE));
        serial_format(SERIAL_8N1_RXINV_TXINV);
        sport_available = serial_available;
        sport_read = serial_getchar;
        sport_write = serial_putchar;
        sport_flush = serial_flush;
        break;
    }
    case SPORT_UART2:
    {
        serial2_begin(BAUD2DIV(SPORT_BAUD_RATE));
        serial2_format(SERIAL_8N1_RXINV_TXINV);
        sport_available = serial2_available;
        sport_read = serial2_getchar;
        sport_write = serial2_putchar;
        sport_flush = serial2_flush;
    }
    case SPORT_UART4:
    {
        serial4_begin(BAUD2DIV3(SPORT_BAUD_RATE));
        serial4_format(SERIAL_8N1_RXINV_TXINV);
        sport_available = serial4_available;
        sport_read = serial4_getchar;
        sport_write = serial4_putchar;
        sport_flush = serial4_flush;
    }
    default:
    {
        init_status = false;
        break;
    }
    }
    delay(100);
}
bool sport_read_and_decode(sport_t *sport)
{
    bool status = false;
    if (sport_available() > 0)
    {
        const uint8_t data = sport_read();
        switch (sport->read_packet_state)
        {
        case WAIT_FOR_POLL_HEADER:
        {
            sport->read_packet_state = data == SPORT_POLL_HEADER ? WAIT_FOR_SENSOR_ID : sport->read_packet_state;
            break;
        }
        case WAIT_FOR_SENSOR_ID:
        {
            sport->current_polled_sensor_id = data;
            sport->read_packet_state = WAIT_FOR_SENSOR_DATA;
            break;
        }
        case WAIT_FOR_SENSOR_DATA:
        {
            if (data == SPORT_POLL_HEADER)
            {
                sport->read_packet_state = WAIT_FOR_SENSOR_ID;
            }
            else
            {
                sport->packet[sport->packet_data_counter++] = data;
                sport->read_packet_state = DATA_IN_FRAME;
            }
            break;
        }
        case DATA_IN_FRAME:
        {
            if (data == SPORT_STUFFING_BYTE)
            {
                sport->read_packet_state = DATA_IN_FRAME_XOR;
            }
            else
            {
                sport->packet[sport->packet_data_counter++] = data;
            }
            break;
        }
        case DATA_IN_FRAME_XOR:
        {
            sport->packet[sport->packet_data_counter++] = data ^ SPORT_STUFFING_XOR_MASK;
            sport->read_packet_state = DATA_IN_FRAME;
            break;
        }
        }
    }
    if (sport->packet_data_counter == SPORT_SENSOR_DATA_PACKET_SIZE)
    {
        sport->packet_data_counter = 0;
        sport->read_packet_state = WAIT_FOR_POLL_HEADER;
        if (sport_check_packet_crc(sport))
        {
            status = true;
        }
    }
    return status;
}