/**
 * @file switches_to_ppm.c
 * @author Jacek Szaltys
 * @brief 
 * @version 0.1
 * @date 2019-09-02
 * 
 * @copyright Copyright (c) 2019
 * 
 */
#include "groundstation/switch.h"
#include "groundstation/common.h"
#include "wiring.h"

static void two_state_switch_read(switch_t *sw);
static void tri_state_switch_read(switch_t *sw);

static const float ppm_time_tri_state_lut[3] = {1500.f, 1000.f, 2000.f};
static const float ppm_time_two_state_lut[2] = {1000.f, 2000.f};
static void (*switch_state_read[2])(switch_t *sw) = {two_state_switch_read, tri_state_switch_read};

static void two_state_switch_read(switch_t *sw)
{
    sw->ppm_time_us = ppm_time_two_state_lut[digitalReadFast(sw->settings.pin1)];
}
static void tri_state_switch_read(switch_t *sw)
{
    uint8_t sw_state = 0;
    bitWrite(sw_state, 0, digitalReadFast(sw->settings.pin1));
    bitWrite(sw_state, 1, digitalReadFast(sw->settings.pin2));
    sw->ppm_time_us = sw_state == 0x03 ? sw->ppm_time_us : ppm_time_tri_state_lut[sw_state]; // Check for switch malfunction. 
}
void switch_init(switch_t *sw, const switch_settings_t settings)
{
    memset((switch_t*)sw, 0, sizeof(switch_t));
    memcpy(&sw->settings, &settings, sizeof(switch_settings_t));

    sw->error = 0;
    sw->ppm_time_us = PPM_MIN_TIME;

    if (sw->settings.type == TWO_STATE_SWITCH)
    {
        pinMode(sw->settings.pin1, INPUT);
    }
    else if (sw->settings.type == TRI_STATE_SWITCH)
    {
        pinMode(sw->settings.pin1, INPUT_PULLDOWN);
        pinMode(sw->settings.pin2, INPUT_PULLDOWN);
    }
}
void switch_write_to_ppm(const switch_t *sw,  ppm_out_t *ppm)
{
    ppm_out_write(ppm, sw->settings.channel, sw->ppm_time_us);
}
void switch_read(switch_t *sw)
{
    switch_state_read[sw->settings.type](sw);
}
