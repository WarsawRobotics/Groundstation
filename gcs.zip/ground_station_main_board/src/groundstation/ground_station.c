#include "groundstation/ground_station.h"
#include "hid_link/hid_link_msg_ground_station.h"

#define CALIBRATION_SET 1
#define CALIBRATION_UNSET 0
#define EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR 0x01
#define EEPROM_JOYSTICK_CALIBRATION_FLAG_ADDR 0x00

static bool joy_3dx700039_data_ready = false;

static const hf27s10_settings_t hf27s10_settings =
    {
        .axis_x_channel = 2,
        .axis_y_channel = 3,
        .axis_x_pin = 23,
        .axis_y_pin = 22,
        .calibr_data_eeprom_adr = 0x01,
        .analog_scale = ANALOG_READ_SCALE};
static const hf45s10_settings_t hf45s10_settings =
    {
        .axis_x_channel = 4,
        .axis_y_channel = 1,
        .axis_z_channel = 15,
        .axis_x_pin = 39,
        .axis_y_pin = 38,
        .axis_z_pin = 37,
        .calibr_data_eeprom_adr = 0x09,
        .analog_scale = ANALOG_READ_SCALE};
static const joy_3dx700039_settings_t joy_3dx700039_settings =
    {
        .tx_channel = 13,
        .ty_channel = 14,
        .tz_channel = 9,
        .rx_channel = 10,
        .ry_channel = 11,
        .rz_channel = 12,
        .uart_id = JOY_3DX700039_UART5};
static const switch_settings_t kill_sw_settings =
    {
        .channel = 5,
        .pin1 = 25,
        .pin2 = 24,
        .type = TWO_STATE_SWITCH};
static const switch_settings_t mission_sw_settings =
    {
        .channel = 8,
        .pin1 = 27,
        .pin2 = 26,
        .type = TWO_STATE_SWITCH};
static const switch_settings_t flight_modes_sw_settings =
    {
        .channel = 6,
        .pin1 = 31,
        .pin2 = 30,
        .type = TRI_STATE_SWITCH};
static const switch_settings_t manipulator_sw_settings =
    {
        .channel = 7,
        .pin1 = 29,
        .pin2 = 28,
        .type = TWO_STATE_SWITCH};

void ground_station_init(groundstation_t *station)
{
    ppm_out_init(&(station->ppm_out), RISING);
    ppm_out_begin(&(station->ppm_out), 5, 255);

    for(uint8_t i = 0; i < PULSEPOSITION_MAXCHANNELS; ++i)
    {
        ppm_out_write(&(station->ppm_out), i + 1, PPM_HALF_TIME);
    }

    hf27s10_init(&(station->joy1), hf27s10_settings);
    hf45s10_init(&(station->joy2), hf45s10_settings);
    joy_3dx700039_init(&(station->mouse), joy_3dx700039_settings);

    switch_init(&station->kill, kill_sw_settings);
    switch_init(&station->mission, mission_sw_settings);
    switch_init(&station->flight_modes, flight_modes_sw_settings);
    switch_init(&station->manipulator, manipulator_sw_settings);
}
void ground_station_send_data(groundstation_t *station)
{
    hid_link_ground_station_msg_t ground_station_msg;
    ground_station_msg.timestamp = millis();

    ground_station_msg.throttle_ppm_time = station->joy2.axis_x_ppm_time_us;
    ground_station_msg.yaw_ppm_time = station->joy2.axis_y_ppm_time_us;
    ground_station_msg.pitch_ppm_time = station->joy1.axis_x_ppm_time_us;
    ground_station_msg.roll_ppm_time = station->joy1.axis_y_ppm_time_us;
    ground_station_msg.tx_ppm_time = station->mouse.tx_ppm_time_us;
    ground_station_msg.ty_ppm_time = station->mouse.ty_ppm_time_us;
    ground_station_msg.tz_ppm_time = station->mouse.tz_ppm_time_us;
    ground_station_msg.rx_ppm_time = station->mouse.rx_ppm_time_us;
    ground_station_msg.ry_ppm_time = station->mouse.ry_ppm_time_us;
    ground_station_msg.rz_ppm_time = station->mouse.rz_ppm_time_us;
    ground_station_msg.kill_sw_ppm_time = station->kill.ppm_time_us;
    ground_station_msg.mission_sw_ppm_time = station->mission.ppm_time_us;
    ground_station_msg.flight_modes_sw_ppm_time = station->flight_modes.ppm_time_us;
    ground_station_msg.manipulator_sw_ppm_time = station->manipulator.ppm_time_us;

    hid_link_ground_station_msg_encode(GCS_RC_TRANSMITER, &ground_station_msg);
    hid_link_send_msg(&(ground_station_msg.hid_msg), 0);
}
void ground_station_read_data(groundstation_t *station)
{
    hf45s10_read(&(station->joy2));
    hf27s10_read(&(station->joy1));
    switch_read(&station->kill);
    switch_read(&station->mission);
    switch_read(&station->flight_modes);
    switch_read(&station->manipulator);
    joy_3dx700039_data_ready = joy_3dx700039_read_auto_data(&(station->mouse));
}
void ground_station_write_data_to_ppm(groundstation_t *station)
{
    ppm_out_t *ppm_ptr = &(station->ppm_out);

    switch_write_to_ppm(&station->kill, ppm_ptr);
    hf45s10_write_ppm(&(station->joy2), ppm_ptr);
    hf27s10_write_ppm(&(station->joy1), ppm_ptr);
    switch_write_to_ppm(&station->mission, ppm_ptr);
    switch_write_to_ppm(&station->flight_modes, ppm_ptr);
    switch_write_to_ppm(&station->manipulator, ppm_ptr);
    // if (joy_3dx700039_data_ready)
    // {
    //     joy_3dx700039_write_ppm(&(station->mouse), ppm_ptr);
    // }
}
void ground_station_write_joy_calibration_data(const groundstation_t *station, hid_link_ground_station_calibr_msg_t *calibr_data)
{
    eeprom_write_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 0), calibr_data->pitch_min_max[0] >> 0x08);
    eeprom_write_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 1), calibr_data->pitch_min_max[0] & 0xFF);
    eeprom_write_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 2), calibr_data->pitch_min_max[1] >> 0x08);
    eeprom_write_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 3), calibr_data->pitch_min_max[1] & 0xFF);
    eeprom_write_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 4), calibr_data->roll_min_max[0] >> 0x08);
    eeprom_write_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 5), calibr_data->roll_min_max[0] & 0xFF);
    eeprom_write_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 6), calibr_data->roll_min_max[1] >> 0x08);
    eeprom_write_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 7), calibr_data->roll_min_max[1] & 0xFF);
    eeprom_write_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 8), calibr_data->throttle_min_max[0] >> 0x08);
    eeprom_write_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 9), calibr_data->throttle_min_max[0] & 0xFF);
    eeprom_write_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 10), calibr_data->throttle_min_max[1] >> 0x08);
    eeprom_write_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 11), calibr_data->throttle_min_max[1] & 0xFF);
    eeprom_write_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 12), calibr_data->yaw_min_max[0] >> 0x08);
    eeprom_write_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 13), calibr_data->yaw_min_max[0] & 0xFF);
    eeprom_write_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 14), calibr_data->yaw_min_max[1] >> 0x08);
    eeprom_write_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 15), calibr_data->yaw_min_max[1] & 0xFF);
    eeprom_write_byte((uint8_t *)EEPROM_JOYSTICK_CALIBRATION_FLAG_ADDR, CALIBRATION_SET);

    hf27s10_update_calibration_data(&station->joy1);
    hf45s10_update_calibration_data(&station->joy2);
}
void gorund_station_read_joy_calibration_data(const groundstation_t *station, hid_link_ground_station_calibr_msg_t *calibr_data)
{
    calibr_data->pitch_min_max[0] = eeprom_read_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 0)) << 0x08 | eeprom_read_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 1));
    calibr_data->pitch_min_max[1] = eeprom_read_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 2)) << 0x08 | eeprom_read_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 3));
    calibr_data->roll_min_max[0] = eeprom_read_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 4)) << 0x08 | eeprom_read_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 5));
    calibr_data->roll_min_max[1] = eeprom_read_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 6)) << 0x08 | eeprom_read_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 7));
    calibr_data->throttle_min_max[0] = eeprom_read_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 8)) << 0x08 | eeprom_read_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 9));
    calibr_data->throttle_min_max[1] = eeprom_read_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 10)) << 0x08 | eeprom_read_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 11));
    calibr_data->yaw_min_max[0] = eeprom_read_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 12)) << 0x08 | eeprom_read_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 13));
    calibr_data->yaw_min_max[1] = eeprom_read_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 14)) << 0x08 | eeprom_read_byte((uint8_t *)(EEPROM_JOYSTICK_CALIBRATION_DATA_STR_ADDR + 15));
}
void ground_station_clear_calibration(const groundstation_t *station)
{
    eeprom_write_byte((uint8_t *)EEPROM_JOYSTICK_CALIBRATION_FLAG_ADDR, CALIBRATION_UNSET);
    hf27s10_update_calibration_data(&station->joy1);
    hf45s10_update_calibration_data(&station->joy2);
}