#ifndef __SYS_MSG_HPP__
#define __SYS_MSG_HPP__

/* Std Libs */
#include <string>
#include <iostream>
#include <mutex>
#include <type_traits>
#include <sstream>
#include <iomanip>

/* Local Libs */
#include "time.hpp"
//#include "common.hpp"

template <typename E>
inline constexpr typename std::underlying_type<E>::type CastEnum(E e) noexcept
{
    return static_cast<typename std::underlying_type<E>::type>(e);
}


namespace system_msg
{
enum class SysMsgCode : uint8_t
{
    WARNING,
    ERROR,
    OK,
    INFO
};

enum class VerboseLevel
{
    NO_VERBOSE,
    ERR_WARN,
    ERR_WARN_INFO
};

struct NullClass
{
    void null_func() {}
};

template <typename Owner = NullClass, typename F = void (NullClass::*)()>
inline void ThrowSysMsg(const SysMsgCode sys_msg_code, const int &verbose_lvl, const std::string &msg = "", Owner *cleaner_owner = nullptr, F cleaner = &NullClass::null_func)
{
    std::stringstream stream;
    stream << std::fixed << std::setprecision(9) << Time::GetSystemTimeStamp();

    const std::string time_header = " [" + stream.str() + "]: ";

    if (verbose_lvl == CastEnum(VerboseLevel::ERR_WARN))
    {
        switch (sys_msg_code)
        {
        case SysMsgCode::ERROR:
            std::cout << "[\033[0;31mERROR\033[0m]" +  time_header << msg << std::endl;
            if (cleaner_owner)
            {
                (cleaner_owner->*cleaner)();
            }

            throw EXIT_FAILURE;
            break;
        case SysMsgCode::WARNING:
            std::cout << "[ \033[0;33mWARN\033[0m]" + time_header << msg << std::endl;
            break;
        }
    }
    else if (verbose_lvl == CastEnum(VerboseLevel::ERR_WARN_INFO))
    {
        switch (sys_msg_code)
        {
        case SysMsgCode::ERROR:
            std::cout << "[\033[0;31mERROR\033[0m]" + time_header << msg << std::endl;
            if (cleaner_owner)
            {
                (cleaner_owner->*cleaner)();
            }
            throw EXIT_FAILURE;
            break;

        case SysMsgCode::WARNING:
            std::cout << "[ \033[0;33mWARN\033[0m]" + time_header << msg << std::endl;
            break;

        case SysMsgCode::OK:
            std::cout << "[   \033[0;32mOK\033[0m]" + time_header << msg << std::endl;
            break;

        case SysMsgCode::INFO:
            std::cout << "[ \033[0;33mINFO\033[0m]" + time_header << msg << std::endl;
        }
    }
    else if (verbose_lvl == CastEnum(VerboseLevel::NO_VERBOSE))
    {
        switch (sys_msg_code)
        {
        case SysMsgCode::ERROR:
            if (cleaner_owner)
            {
                (cleaner_owner->*cleaner)();
            }
            throw EXIT_FAILURE;
        }
    }
    else
    {
        std::cout << "[\033[0;31mERROR\033[0m]" + time_header
                  << "No such verbose value available: " << std::to_string(verbose_lvl) << std::endl;
    }
}

template <typename Owner = NullClass, typename F = void (NullClass::*)()>
inline void ThrowSysMsg(const SysMsgCode sys_msg_code, const int &verbose_lvl, std::mutex &print_mut, const std::string &msg = "", Owner *owner = nullptr, F cleaner = &NullClass::null_func)
{
    std::lock_guard<std::mutex> lock(print_mut);
    ThrowSysMsg(sys_msg_code, verbose_lvl, msg, owner, cleaner);
}

} // namespace system_msg
#endif // __SYS_MSG_HPP__
