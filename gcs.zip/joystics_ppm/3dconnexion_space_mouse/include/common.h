#ifndef __COMMON_H__
#define __COMMON_H__

#include <math.h>
#include "ppm.h"

#define PPM_MAX_TIME 2000.0
#define PPM_HALF_TIME 1500.0
#define PPM_MIN_TIME 1000.0

#define ANALOG_REF_VOLTAGE 3.3
#define ANALOG_BIT_RESOLUTION 16.0

#define ANALOG_READ_MAX_VALUE pow(2.0, ANALOG_BIT_RESOLUTION)
#define ANALOG_READ_SCALE ANALOG_REF_VOLTAGE / ANALOG_READ_MAX_VALUE

#define PPM_SCALE_FACTOR(x_min, x_max) ((PPM_MAX_TIME - (PPM_MIN_TIME)) / (x_max - (x_min)))
#define PPM_SCALE_OFFSET(x_min, x_max) (PPM_MIN_TIME - (x_min) * ((PPM_MAX_TIME - (PPM_MIN_TIME)) / (x_max - (x_min))))

#define RAW_VALUE_TO_PPM(value, a, b) (a * value + b)

inline void analog_read_with_scale(uint8_t pin, float* ret)
{
    *ret = (float)analogRead(pin) * ANALOG_READ_SCALE;
}

#endif //__COMMON_H__