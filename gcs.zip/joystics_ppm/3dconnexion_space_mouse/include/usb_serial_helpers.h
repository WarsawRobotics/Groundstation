#ifndef __USB_SERIAL_HELPERS_H__
#define __USB_SERIAL_HELPERS_H__

#include <stdint.h>
#include <stddef.h>

size_t print_write(const uint8_t* buffer, size_t size);
size_t print_str(const char* str);
size_t print_number(unsigned long n, uint8_t base, uint8_t sign);
size_t print_long(long n, uint8_t base);
size_t print_int(int n, uint8_t base);
size_t println(void);
void print_float(double n, int digits);

#endif //__USB_SERIAL_HELPERS_H__