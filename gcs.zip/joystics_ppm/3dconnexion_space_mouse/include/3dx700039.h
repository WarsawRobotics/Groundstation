#ifndef __3DX700039_H__
#define __3DX700039_H__

#include "common.h"
#include <HardwareSerial.h>
#include <stdbool.h>
#include <stdint.h>

#define MSG_FRAME_BYTES_3DX700039 15

typedef struct serial
{
    void (*begin)(uint32_t);
    int (*read)(void);
    void (*write)(uint32_t);
    int (*available)(void);

} serial_t;

typedef struct joy_3dx700039
{
    uint8_t msg[MSG_FRAME_BYTES_3DX700039 + 1];

    int16_t trans[3];
    int16_t rot[3];
    uint8_t trans_channel[3];
    uint8_t rot_channel[3];

    bool data_ready;
    bool data_start;
    int data_counter;

    serial_t* serial;

    float pos_to_ppm_constant_a;
    float pos_to_ppm_constant_b;
    //const uint16_t checksum = (8 * 13);
} joy_3dx700039_t;

void joy_3dx700039_init(joy_3dx700039_t* mouse);
void joy_3dx700039_read_auto_data(joy_3dx700039_t* mouse);
void joy_3dx700039_parse_msg(joy_3dx700039_t* mouse);
void joy_3dx700039_write_ppm(joy_3dx700039_t* mouse, ppm_out_t* ppm);

#endif //__3DX700039_H__