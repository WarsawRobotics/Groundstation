#ifndef GCS_CONTROLS_TRANSMITER_HPP
#define GCS_CONTROLS_TRANSMITER_HPP

/* 3d Party Libs */
#include <sensor_msgs/Joy.h>
#include <ros/ros.h>
#include "mavlink.h"

/* Local Libs */
#include "udp_protocol.hpp"

namespace diagstar
{
    template <typename Protocol>
    class GroundStationControlsTransmiter
    {
    public:
        GroundStationControlsTransmiter(const Protocol &io_protocol, const std::string &data_topic, const size_t &buffer_size)
            : io_protocol_(io_protocol), data_topic_(data_topic), buffer_size_(buffer_size)
        {
        }
        void Initialize()
        {
            data_.resize(buffer_size_);
            io_protocol_.Initialize();
            data_sub_ = nh_.subscribe<const sensor_msgs::Joy &>(data_topic_, 1, &GroundStationControlsTransmiter::DataCallback, this);
        }
        inline void Run() { ros::spin(); }

    private:
        void DataCallback(const sensor_msgs::Joy &msg)
        {
            gcs_msg_.throttle_yaw[0] = msg.axes[0];
            gcs_msg_.throttle_yaw[1] = msg.axes[1];

            gcs_msg_.pitch_roll[0] = msg.axes[2];
            gcs_msg_.pitch_roll[1] = msg.axes[3];

            gcs_msg_.mouse[0] = msg.axes[4];
            gcs_msg_.mouse[1] = msg.axes[5];
            gcs_msg_.mouse[2] = msg.axes[6];
            gcs_msg_.mouse[3] = msg.axes[7];
            gcs_msg_.mouse[4] = msg.axes[8];
            gcs_msg_.mouse[5] = msg.axes[9];

            gcs_msg_.switches[0] = (msg.buttons[0]);
            gcs_msg_.switches[1] = (msg.buttons[1]);
            gcs_msg_.switches[2] = (msg.buttons[2]);
            gcs_msg_.switches[3] = (msg.buttons[3]);

            gcs_msg_.time_usec = msg.header.stamp.toNSec() / 1000;

            mavlink_message_t mav_msg;
            mavlink_msg_gcs_encode(1, 5, &mav_msg, &gcs_msg_);
                               
            const size_t len = mavlink_msg_to_send_buffer(data_.data(), &mav_msg);
            io_protocol_.SendData(data_.data(), len);
        }
        std::vector<uint8_t> data_;

        Protocol io_protocol_;
        ros::Subscriber data_sub_;
        ros::NodeHandle nh_;
        mavlink_gcs_t gcs_msg_;

        const std::string data_topic_;
        const size_t buffer_size_;
    };
} // namespace diagstar

#endif //GCS_CONTROLS_TRANSMITER_HPP