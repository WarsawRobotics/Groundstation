#ifndef UDP_PROTOCOL_HPP
#define UDP_PROTOCOL_HPP

/* Std Libs */
#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <vector>

namespace diagstar
{
    class UdpProtocol
    {
    public:
        UdpProtocol(const std::string &receiver_ip, const size_t &receiver_port)
            : recv_ip_(receiver_ip), recv_port_(receiver_port), socket_(0)
        {
        }
        void Initialize()
        {
            socket_ = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
            if (socket_ == -1)
            {
                throw std::runtime_error("Can't create socket.");
            }
            memset(&receiver_addr_, 0, sizeof(receiver_addr_));

            receiver_addr_.sin_family = AF_INET;
            receiver_addr_.sin_port = htons(recv_port_);

            if (inet_aton(recv_ip_.c_str() , &receiver_addr_.sin_addr) == 0)
            {
                throw std::runtime_error("inet_aton() failed\n");
            }
        }
        inline void SendData(const uint8_t *data, const size_t &length)
        {
            ssize_t bytes_sent = sendto(socket_, data, length, 0, (struct sockaddr *)&receiver_addr_, sizeof(receiver_addr_));
        }
        inline std::string GetConfigurationString() const
        {
            return "IP: " + recv_ip_ + "  Receiver port: " + std::to_string(recv_port_) + "  ";
        }

    private:
        int socket_;
        sockaddr_in receiver_addr_;
        std::string recv_ip_;
        size_t recv_port_;
    };
} // namespace diagstar

#endif //UDP_PROTOCOL_HPP