#pragma once
// MESSAGE DIAGSTAR_GCS PACKING

#define MAVLINK_MSG_ID_DIAGSTART_GCS 336

MAVPACKED(
    typedef struct __mavlink_gcs_t {
        uint64_t time_usec;
        float mouse[6];
        float throttle_yaw[3];
        float pitch_roll[2];
        float switches[4];
    })
mavlink_gcs_t;

#define MAVLINK_MSG_ID_DIAGSTAR_GCS_LEN 68
#define MAVLINK_MSG_ID_DIAGSTAR_GCS_MIN_LEN 68
#define MAVLINK_MSG_ID_336_LEN 68
#define MAVLINK_MSG_ID_336_MIN_LEN 68

#define MAVLINK_MSG_ID_DIAGSTAR_GCS_CRC 34
#define MAVLINK_MSG_ID_336_CRC 34

#define MAVLINK_MSG_ID_DIAGSTAR_GCS_FIELD_MOUSE_LEN 6
#define MAVLINK_MSG_ID_DIAGSTAR_GCS_FIELD_THROTTLE_YAW_LEN 3
#define MAVLINK_MSG_ID_DIAGSTAR_GCS_FIELD_PITCH_ROLL_LEN 2
#define MAVLINK_MSG_ID_DIAGSTAR_GCS_FIELD_SWITCHES_LEN 4

#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_DIAGSTAR_GCS                                                                \
    {                                                                                                     \
        336,                                                                                              \
            "DIAGSTAR_GCS",                                                                               \
            5,                                                                                            \
        {                                                                                                 \
            {"time_usec", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_gcs_t, time_usec)},         \
                {"mouse", NULL, MAVLINK_TYPE_FLOAT, 6, 8, offsetof(mavlink_gcs_t, mouse)},                \
                {"throttle_yaw", NULL, MAVLINK_TYPE_FLOAT, 3, 32, offsetof(mavlink_gcs_t, throttle_yaw)}, \
                {"pitch_roll", NULL, MAVLINK_TYPE_FLOAT, 2, 44, offsetof(mavlink_gcs_t, pitch_roll)},     \
                {"switches", NULL, MAVLINK_TYPE_FLOAT, 4, 52, offsetof(mavlink_gcs_t, switches)},         \
        }                                                                                                 \
    }
#else
#define MAVLINK_MESSAGE_INFO_DIAGSTAR_GCS                                                                 \
    {                                                                                                     \
        336,                                                                                              \
            "DIAGSTAR_GCS",                                                                               \
            5,                                                                                            \
        {                                                                                                 \
            {"time_usec", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_gcs_t, time_usec)},         \
                {"mouse", NULL, MAVLINK_TYPE_FLOAT, 6, 8, offsetof(mavlink_gcs_t, mouse)},                \
                {"throttle_yaw", NULL, MAVLINK_TYPE_FLOAT, 3, 32, offsetof(mavlink_gcs_t, throttle_yaw)}, \
                {"pitch_roll", NULL, MAVLINK_TYPE_FLOAT, 2, 44, offsetof(mavlink_gcs_t, pitch_roll)},     \
                {"switches", NULL, MAVLINK_TYPE_FLOAT, 4, 52, offsetof(mavlink_gcs_t, switches)},       \
        }                                                                                                 \
    }
#endif


static inline uint16_t mavlink_msg_gcs_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t *msg,
                                                      uint64_t time_usec, const float mouse[6], const float throttle_yaw[3], const float pitch_roll[2], const float switches[4])
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_DIAGSTART_GCS_LEN];
    _mav_put_uint64_t(buf, 0, time_usec);
    _mav_put_float_array(buf, 8, mouse, 6);
    _mav_put_float_array(buf, 32, throttle_yaw, 3);
    _mav_put_float_array(buf, 44, pitch_roll, 2);
    _mav_put_float_array(buf, 52, switches, 4);
    memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_DIAGSTART_GCS_LEN);
#else
    mavlink_gcs_t packet;
    packet.time_usec = time_usec;
    mav_array_memcpy(packet.mouse, mouse, sizeof(float) * 6);
    mav_array_memcpy(packet.throttle_yaw, throttle_yaw, sizeof(float) * 3);
    mav_array_memcpy(packet.pitch_roll, pitch_roll, sizeof(float) * 2);
    mav_array_memcpy(packet.switches, switches, sizeof(float) * 4);
    memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_DIAGSTAR_GCS_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_DIAGSTART_GCS;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_DIAGSTAR_GCS_MIN_LEN, MAVLINK_MSG_ID_DIAGSTAR_GCS_LEN, MAVLINK_MSG_ID_DIAGSTAR_GCS_CRC);
}
static inline uint16_t mavlink_msg_gcs_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                                                 mavlink_message_t *msg,
                                                 uint64_t time_usec, const float mouse[6], const float throttle_yaw[3], const float pitch_roll[2], const float switches[4])
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_DIAGSTART_GCS_LEN];
    _mav_put_uint64_t(buf, 0, time_usec);
    _mav_put_float_array(buf, 8, mouse, 6);
    _mav_put_float_array(buf, 32, throttle_yaw, 3);
    _mav_put_float_array(buf, 44, pitch_roll, 2);
    _mav_put_float_array(buf, 52, switches, 4);
    memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_DIAGSTART_GCS_LEN);
#else
    mavlink_gcs_t packet;
    packet.time_usec = time_usec;
    mav_array_memcpy(packet.mouse, mouse, sizeof(float) * 6);
    mav_array_memcpy(packet.throttle_yaw, throttle_yaw, sizeof(float) * 3);
    mav_array_memcpy(packet.pitch_roll, pitch_roll, sizeof(float) * 2);
    mav_array_memcpy(packet.switches, switches, sizeof(float) * 4);
    memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_DIAGSTAR_GCS_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_DIAGSTART_GCS;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_DIAGSTAR_GCS_MIN_LEN, MAVLINK_MSG_ID_DIAGSTAR_GCS_LEN, MAVLINK_MSG_ID_DIAGSTAR_GCS_CRC);
}
static inline uint16_t mavlink_msg_gcs_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t *msg, const mavlink_gcs_t *gcs_msg)
{
    return mavlink_msg_gcs_pack(system_id, component_id, msg, gcs_msg->time_usec, gcs_msg->mouse, gcs_msg->throttle_yaw, gcs_msg->pitch_roll, gcs_msg->switches);
}

static inline uint16_t mavlink_msg_gcs_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t *msg, const mavlink_gcs_t *gcs_msg)
{
    return mavlink_msg_gcs_pack_chan(system_id, component_id, chan, msg, gcs_msg->time_usec, gcs_msg->mouse, gcs_msg->throttle_yaw, gcs_msg->pitch_roll, gcs_msg->switches);
}
static inline uint64_t mavlink_msg_gcs_get_time_usec(const mavlink_message_t *msg)
{
    return _MAV_RETURN_uint64_t(msg, 0);
}
static inline uint16_t mavlink_msg_gcs_get_mouse(const mavlink_message_t *msg, float mouse[6])
{
    return _MAV_RETURN_float_array(msg, mouse, 6, 8);
}
static inline uint16_t mavlink_msg_gcs_get_throttle_yaw(const mavlink_message_t *msg, float throttle_yaw[3])
{
    return _MAV_RETURN_float_array(msg, throttle_yaw, 3, 32);
}
static inline uint16_t mavlink_msg_gcs_get_pitch_roll(const mavlink_message_t *msg, float pitch_roll[2])
{
    return _MAV_RETURN_float_array(msg, pitch_roll, 2, 44);
}
static inline uint16_t mavlink_msg_gcs_get_switches(const mavlink_message_t *msg, float switches[4])
{
    return _MAV_RETURN_float_array(msg, switches, 4, 52);
}
static inline void mavlink_msg_gcs_decode(const mavlink_message_t *msg, mavlink_gcs_t *gcs_msg)
{
    uint8_t len = msg->len < MAVLINK_MSG_ID_DIAGSTAR_GCS_LEN ? msg->len : MAVLINK_MSG_ID_DIAGSTAR_GCS_LEN;
    memset(gcs_msg, 0, MAVLINK_MSG_ID_DIAGSTAR_GCS_LEN);
    memcpy(gcs_msg, _MAV_PAYLOAD(msg), len);
}
