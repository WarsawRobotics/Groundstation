/**
 * @file io_hid.h
 * @author Jacek Szaltys
 * @brief 
 * @version 0.1
 * @date 2019-09-02
 * 
 * @copyright Copyright (c) 2019
 * 
 */
#ifndef IO_HID_H
#define IO_HID_H

#include <usb.h>

#ifdef __cplusplus
extern "C"
{
#endif
#define RAWHID_DATA_SIZE 64
    /**
     * @brief Close given hid device and releanse all memory.
     * 
     */
    void close_hid(int num);
    /**
     * @brief Open hid device with given vendor id and product id.
     * 
     * @param max
     * @param vid Device vendor id.
     * @param pid Device product id.
     * @param usage_page 
     * @param usage 
     * @return int 0 - cannot connect to device, 1 - connection established.
     */
    int open_hid(int max, int vid, int pid, int usage_page, int usage);
    /**
     * @brief Read data buffer from given hid device.
     * 
     * @param buf Data buffer. Must be size of 64 elements.
     * @param timeout Read timeout.
     * @return int -1 - error, 0 - hid device disconnected, 1 - data read success
     */
    int usb_rawhid_recv(int num, void *buf, int timeout);

    // Read data buffer to given hid device.
    /**
     * @brief Send data to hid device.
     * 
     * @param buf Data buffer. Must be size of 64 elements.
     * @param timeout Write timeout.
     * @return int -1 - error, 0 - hid device disconnected, 1 - data write success
     */
    int usb_rawhid_send(int num, void *buf, int timeout);

#ifdef __cplusplus
}
#endif

#endif // IO_HID_H