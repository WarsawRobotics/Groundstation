/**
 * @file io_hid.c
 * @author Jacek Szaltys
 * @brief 
 * @version 0.1
 * @date 2019-09-02
 * 
 * @copyright Copyright (c) 2019
 * 
 */

/* Local libs */
#include "io_hid.h"

/* Std libs */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct hid_struct
{
    usb_dev_handle *usb;
    int open;
    int iface;
    int ep_in;
    int ep_out;
    struct hid_struct *prev;
    struct hid_struct *next;
} hid_t;
static hid_t *first_hid = NULL;
static hid_t *last_hid = NULL;

static void add_hid(hid_t *h);
static hid_t *get_hid(int num);
static void free_all_hid(void);
static void hid_close(hid_t *hid);
static int hid_parse_item(uint32_t *val, uint8_t **data, const uint8_t *end);

//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
//                        PUBLIC FUNCTIONS                            //
//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

int usb_rawhid_recv(int num, void *buf, int timeout)
{
    hid_t *hid;
    int r;

    hid = get_hid(num);
    if (!hid || !hid->open)
    {
        return -1;
    }
    r = usb_interrupt_read(hid->usb, hid->ep_in, (char *)buf, RAWHID_DATA_SIZE, timeout);
    if (r >= 0)
    {
        return r;
    }
    if (r == -110)
    {
        return 0; // timeout
    }
    return -1;
}
int usb_rawhid_send(int num, void *buf, int timeout)
{
    hid_t *hid;
    hid = get_hid(num);
    if (!hid || !hid->open)
    {
        return -1;
    }
    if (hid->ep_out)
    {
        return usb_interrupt_write(hid->usb, hid->ep_out, (char *)buf, RAWHID_DATA_SIZE, timeout);
    }
    else
    {
        return usb_control_msg(hid->usb, 0x21, 9, 0, hid->iface, (char *)buf, RAWHID_DATA_SIZE, timeout);
    }
}
void close_hid(int num)
{
    hid_t *hid;
    hid = get_hid(num);
    if (!hid || !hid->open)
    {
        return;
    }
    hid_close(hid);
}
int open_hid(int max, int vid, int pid, int usage_page, int usage)
{
    struct usb_bus *bus = NULL;
    struct usb_device *dev = NULL;
    struct usb_interface *iface = NULL;
    struct usb_interface_descriptor *desc = NULL;
    struct usb_endpoint_descriptor *ep = NULL;
    usb_dev_handle *u = NULL;
    uint8_t buf[1024], *p = NULL;
    int i = 0, n = 0, len = 0, tag = 0, ep_in = 0, ep_out = 0, count = 0, claimed = 0;
    uint32_t val = 0, parsed_usage = 0, parsed_usage_page = 0;
    hid_t *hid;

    if (first_hid)
    {
        free_all_hid();
    }
    if (max < 1)
    {
        return 0;
    }

    usb_init();
    usb_find_busses();
    usb_find_devices();

    for (bus = usb_get_busses(); bus; bus = bus->next)
    {
        for (dev = bus->devices; dev; dev = dev->next)
        {
            if (vid > 0 && dev->descriptor.idVendor != vid)
            {
                continue;
            }
            if (pid > 0 && dev->descriptor.idProduct != pid)
            {
                continue;
            }
            if (!dev->config)
            {
                continue;
            }
            if (dev->config->bNumInterfaces < 1)
            {
                continue;
            }
            iface = dev->config->interface;
            u = NULL;
            claimed = 0;
            for (i = 0; i < dev->config->bNumInterfaces && iface; i++, iface++)
            {
                desc = iface->altsetting;
                if (!desc)
                {
                    continue;
                }
                if (desc->bInterfaceClass != 3)
                {
                    continue;
                }
                if (desc->bInterfaceSubClass != 0)
                {
                    continue;
                }
                if (desc->bInterfaceProtocol != 0)
                {
                    continue;
                }
                ep = desc->endpoint;
                ep_in = ep_out = 0;
                for (n = 0; n < desc->bNumEndpoints; n++, ep++)
                {
                    if (ep->bEndpointAddress & 0x80)
                    {
                        if (!ep_in)
                        {
                            ep_in = ep->bEndpointAddress & 0x7F;
                        }
                    }
                    else
                    {
                        if (!ep_out)
                        {
                            ep_out = ep->bEndpointAddress;
                        }
                    }
                }
                if (!ep_in)
                {
                    continue;
                }
                if (!u)
                {
                    u = usb_open(dev);
                    if (!u)
                    {
                        break;
                    }
                }
                if (usb_get_driver_np(u, i, (char *)buf, sizeof(buf)) >= 0)
                {
                    if (usb_detach_kernel_driver_np(u, i) < 0)
                    {
                        continue;
                    }
                }
                if (usb_claim_interface(u, i) < 0)
                {
                    continue;
                }
                len = usb_control_msg(u, 0x81, 6, 0x2200, i, (char *)buf, sizeof(buf), 250);
                if (len < 2)
                {
                    usb_release_interface(u, i);
                    continue;
                }
                p = buf;
                parsed_usage_page = parsed_usage = 0;
                while ((tag = hid_parse_item(&val, &p, buf + len)) >= 0)
                {
                    if (tag == 4)
                    {
                        parsed_usage_page = val;
                    }
                    if (tag == 8)
                    {
                        parsed_usage = val;
                    }
                    if (parsed_usage_page && parsed_usage)
                    {
                        break;
                    }
                }
                if ((!parsed_usage_page) || (!parsed_usage) ||
                    (usage_page > 0 && parsed_usage_page != usage_page) ||
                    (usage > 0 && parsed_usage != usage))
                {
                    usb_release_interface(u, i);
                    continue;
                }
                hid = (struct hid_struct *)malloc(sizeof(struct hid_struct));
                if (!hid)
                {
                    usb_release_interface(u, i);
                    continue;
                }
                hid->usb = u;
                hid->iface = i;
                hid->ep_in = ep_in;
                hid->ep_out = ep_out;
                hid->open = 1;
                add_hid(hid);
                claimed++;
                count++;
                if (count >= max)
                {
                    return count;
                }
            }
            if (u && !claimed)
            {
                usb_close(u);
            }
        }
    }
    return count;
}

//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
//                        PRIVATE FUNCTIONS                           //
//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

// http://people.freebsd.org/~chuckr/code/python/uhidParser-0.2.tbz
static int hid_parse_item(uint32_t *val, uint8_t **data, const uint8_t *end)
{
    const uint8_t *p = *data;
    uint8_t tag;
    int table[4] = {0, 1, 2, 4};
    int len;

    if (p >= end)
    {
        return -1;
    }
    if (p[0] == 0xFE)
    {
        // long item, HID 1.11, 6.2.2.3, page 27
        if (p + 5 >= end || p + p[1] >= end)
        {
            return -1;
        }
        tag = p[2];
        *val = 0;
        len = p[1] + 5;
    }
    else
    {
        // short item, HID 1.11, 6.2.2.2, page 26
        tag = p[0] & 0xFC;
        len = table[p[0] & 0x03];
        if (p + len + 1 >= end)
        {
            return -1;
        }
        switch (p[0] & 0x03)
        {
        case 3:
            *val = p[1] | (p[2] << 8) | (p[3] << 16) | (p[4] << 24);
            break;
        case 2:
            *val = p[1] | (p[2] << 8);
            break;
        case 1:
            *val = p[1];
            break;
        case 0:
            *val = 0;
            break;
        }
    }
    *data += len + 1;
    return tag;
}
static hid_t *get_hid(int num)
{
    hid_t *p;
    for (p = first_hid; p && num > 0; p = p->next, num--)
        ;
    return p;
}
static void add_hid(hid_t *h)
{
    if (!first_hid || !last_hid)
    {
        first_hid = last_hid = h;
        h->next = h->prev = NULL;
        return;
    }
    last_hid->next = h;
    h->prev = last_hid;
    h->next = NULL;
    last_hid = h;
}
static void free_all_hid(void)
{
    hid_t *p, *q;

    for (p = first_hid; p; p = p->next)
    {
        hid_close(p);
    }
    p = first_hid;
    while (p)
    {
        q = p;
        p = p->next;
        free(q);
    }
    first_hid = last_hid = NULL;
}
static void hid_close(hid_t *hid)
{
    hid_t *p;
    int others = 0;

    usb_release_interface(hid->usb, hid->iface);
    for (p = first_hid; p; p = p->next)
    {
        if (p->open && p->usb == hid->usb)
            others++;
    }
    if (!others)
        usb_close(hid->usb);
    hid->usb = NULL;
}
