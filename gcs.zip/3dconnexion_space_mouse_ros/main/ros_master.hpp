/**
 * @file ros_master.hpp
 * @author Jacek Szaltys
 * @brief 
 * @version 0.1
 * @date 2019-09-02
 * 
 * @copyright Copyright (c) 2019
 * 
 */
#ifndef ROS_MASTER_HPP
#define ROS_MASTER_HPP

/* Std Libs */
#include <chrono>
#include <string>
/* Ros Libs */
#include <ros/ros.h>
namespace diagstar
{
    class RosMaster
    {
    public:
        /**
         * @briefMake specified number of attempts to connect with the rosmaster. 
         * 
         * @param connection_attemp Number of connection attemps.
         * @param connection_attempt_timeout Connection timeout in seconds.
         * @param argc Number of console arguments.
         * @param argv Console arguments.
         */
        RosMaster(const size_t &connection_attemps, const std::chrono::seconds &connection_attempt_timeout, int argc, char *argv[]);
        /**
         * @brief Check if connection with rosmaster is established.
         * 
         * @return true 
         * @return false 
         */
        const bool &IsInitialized() const noexcept;
        void Stop();

    private:
        bool ros_initialized_;
        const std::string ksys_msg_header_ = "[RosMaster] ";
        const std::string kros_package_name_ = "dupa";
    };
} // namespace diagstar
#endif //ROS_MASTER_HPP