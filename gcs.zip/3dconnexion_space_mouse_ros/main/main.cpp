#include "hid_simple_protocol.h"
#include "time_translator.hpp"
#include "ros_master.hpp"
#include "time.hpp"
#include "sys_msg.hpp"
#include <iostream>
#include <chrono>
#include <thread>
#include <signal.h>
#include <geometry_msgs/TwistStamped.h>

volatile sig_atomic_t exit_ = 0;
double last_timestamp = 0.0;
struct space_mouse
{
    uint16_t transl[3] = {0, 0, 0};
    uint16_t rot[3] = {0, 0, 0};
    uint32_t timestamp = 0;
    uint32_t prv_timestamp = 0;
    uint8_t hid_id = 0x10;
    float transl_max_value = 350.0f;
    float rot_max_value = 350.0f;
    int pid = HID_PID;
    int vid = HID_VID;
};
space_mouse mouse;
diagstar::TimeTranslator time_translator;

int open_hid_dev()
{
    const std::chrono::seconds kconnection_attempt_timeout_ = std::chrono::seconds(5L);

    for (size_t i = 0; i < 4; ++i)
    {
        const int opened_hid_devs = open_hid(1, mouse.vid, mouse.pid, 0xFFAB, 0x0200);

        if (opened_hid_devs <= 0)
        {
            diagstar::SystemMsg::ThrowWarn("Cannot open usb device. Sleep for " + std::to_string(kconnection_attempt_timeout_.count()) + " s.");
            std::this_thread::sleep_for(kconnection_attempt_timeout_);
        }
        else if (opened_hid_devs == 1)
        {
            diagstar::SystemMsg::ThrowOk("Usb device opened.");
            return 1;
        }
        else
        {
            diagstar::SystemMsg::ThrowError("There are multiple hid devices connected with same PID number. Make sure that every hid device has unique PID.");
            return 0;
        }
    }
}
void parse_mouse_msg(uint8_t *data)
{
    mouse.timestamp = (data[0] << 0x18) |
                      (data[1] << 0x10) |
                      (data[2] << 0x08) |
                      data[3];

    mouse.transl[0] = data[4] << 0x08 | data[5] & 0xFF;
    mouse.transl[1] = data[6] << 0x08 | data[7] & 0xFF;
    mouse.transl[2] = data[8] << 0x08 | data[9] & 0xFF;

    mouse.rot[0] = data[10] << 0x08 | data[11] & 0xFF;
    mouse.rot[1] = data[12] << 0x08 | data[13] & 0xFF;
    mouse.rot[2] = data[14] << 0x08 | data[15] & 0xFF;
}
void listen_soft_start()
{
    uint8_t hid_dev_data[RAWHID_DATA_SIZE];

    const auto time_now = std::chrono::high_resolution_clock::now();
    const auto recv_msg_timeout = std::chrono::milliseconds(5000);

    exit_ = true;
    while (std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::high_resolution_clock::now() - time_now) <= recv_msg_timeout)
    {
        if (usb_rawhid_recv(0, hid_dev_data, 0) > 0)
        {
            exit_ = false;
            break;
        }
    }
    if (exit_)
    {
        diagstar::SystemMsg::ThrowError("Usb device disconnected. Check connection.");
    }
}
double translate_timestamp(const double &hw_stamp_ns)
{
    double translated_tstamp = 0;
    auto error_msg = time_translator.Update(hw_stamp_ns, diagstar::Time::Now().toSec(), translated_tstamp);
    if (time_translator.CheckError(error_msg))
    {
        diagstar::SystemMsg::ThrowError(time_translator.GetErrorMsg(error_msg));
        translated_tstamp = diagstar::Time::Now().toSec();
    }
    if (time_translator.ReadyToTranslate())
    {
        error_msg = time_translator.Translate(hw_stamp_ns, translated_tstamp);
        if (time_translator.CheckError(error_msg))
        {
            diagstar::SystemMsg::ThrowError(time_translator.GetErrorMsg(error_msg));
            translated_tstamp = diagstar::Time::Now().toSec();
        }
    }
    return translated_tstamp;
}
void listen_hid_dev(geometry_msgs::TwistStamped &ros_msg, ros::Publisher &pub)
{
    hid_simple_protocol_msg_t hid_msg;
    while (!exit_)
    {
        if (simple_protocol_receive_msg(&hid_msg, 5000) <= 0)
        {
            diagstar::SystemMsg::ThrowWarn("Usb device disconnected! Trying to reestablish connection.");
            if (!open_hid_dev())
            {
                break;
            }
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
        else
        {
            if (simple_protocol_decode_msg(&hid_msg))
            {
                if (hid_msg.msg_id == mouse.hid_id)
                {
                    parse_mouse_msg(hid_msg.data);

                    if(mouse.timestamp > mouse.prv_timestamp)
                    {
                        mouse.prv_timestamp = mouse.timestamp;

                        double stamp = translate_timestamp(diagstar::Time::MicrosToNanos(static_cast<double>(mouse.timestamp)));
                        // std::cout << std::to_string(stamp - last_timestamp) << std::endl;
                        // last_timestamp = stamp;

                        ros_msg.header.stamp = ros::Time(stamp);
                        // ros_msg.header.stamp = ros::Time::now();
                        ros_msg.header.seq++;

                        ros_msg.twist.linear.x = mouse.transl[0] / mouse.transl_max_value - 1.0f;
                        ros_msg.twist.linear.y = mouse.transl[1] / mouse.transl_max_value - 1.0f;
                        ros_msg.twist.linear.z = mouse.transl[2] / mouse.transl_max_value - 1.0f;

                        ros_msg.twist.angular.x = mouse.rot[0] / mouse.rot_max_value - 1.0f;
                        ros_msg.twist.angular.y = mouse.rot[1] / mouse.rot_max_value - 1.0f;
                        ros_msg.twist.angular.z = mouse.rot[2] / mouse.rot_max_value - 1.0f;

                        pub.publish(ros_msg);
                        ros::spinOnce();
                    }
                }
            }
            else
            {
                diagstar::SystemMsg::ThrowWarn("Checksum error. Dropping msg!");
            }
        }
    }
}
void space_mouse_process()
{
    ros::NodeHandle nh;
    geometry_msgs::TwistStamped space_mouse_ros_msg;
    space_mouse_ros_msg.header.frame_id = "space_mouse";
    ros::Publisher space_mouse_pub = nh.advertise<geometry_msgs::TwistStamped>("spacenav/twist", 1);
    hid_simple_protocol_msg_t hid_msg;
    if (open_hid_dev())
    {
        listen_soft_start();
        listen_hid_dev(space_mouse_ros_msg, space_mouse_pub);
        close_hid(0);
    }
}

void quit_handler(int sig)
{
    diagstar::SystemMsg::ThrowInfo("Interrupt. Closing...");
    exit_ = true;
}
int main(int argc, char *argv[])
{
    diagstar::RosMaster ros_master(3, std::chrono::seconds(5), argc, argv);
    if (ros_master.IsInitialized())
    {
        signal(SIGINT, quit_handler);
        space_mouse_process();
    }
    return 0;
}
