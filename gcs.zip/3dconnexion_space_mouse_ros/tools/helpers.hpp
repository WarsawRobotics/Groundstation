/**
 * @file helpers.hpp
 * @author Jacek Szaltys
 * @brief 
 * @version 0.1
 * @date 2019-08-30
 * 
 * @copyright Copyright (c) 2019
 * 
 */

#ifndef HELPERS_HPP
#define HELPERS_HPP

/* Std Libs */
#include <memory>
#include <type_traits>
#include <unistd.h>

namespace diagstar
{
    namespace common
    {
        template <typename Enum>
        inline constexpr typename std::underlying_type<Enum>::type CastEnum(Enum e) noexcept
        {
            return static_cast<typename std::underlying_type<Enum>::type>(e);
        }
    } // namespace common
} // namespace diagstar
#if __cplusplus == 201103L
namespace std
{
    template <typename T, typename... Ts>
    inline std::unique_ptr<T> make_unique(Ts &&... params)
    {
        return std::unique_ptr<T>(new T(std::forward<Ts>(params)...));
    }
} // namespace std
#endif
#endif //HELPERS_HPP