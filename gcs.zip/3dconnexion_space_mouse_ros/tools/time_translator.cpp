/**
 * @file time_translator.cpp
 * @author Jacek Szaltys
 * @brief 
 * @version 0.1
 * @date 2019-08-30
 * 
 * @copyright Copyright (c) 2019
 * 
 */

/* Std Libs */
#include <algorithm>

/* Local Libs */
#include "time_translator.hpp"

namespace diagstar
{
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    //                        PUBLIC FUNCTIONS                            //
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

    TimeTranslator::TimeTranslator() : mmid_point_id_(0) {}

    const TimeTranslator::ErrorMsgCodes TimeTranslator::Update(const double &device_time, const double &local_time, double &translated_time)
    {
        const TimePoint time_point(device_time, local_time);

        if (!mtime_points_vec_.empty())
        {
            if (device_time < mtime_points_vec_.back().x)
            {
                return ErrorMsgCodes::TIMEPOINT_FORWARD_ERROR;
            }
        }
        if (mtime_points_vec_.size() >= 2u && !IsAboveTopLine(time_point))
        {
            while (mtime_points_vec_.size() >= 2u && IsBelowTopLine(time_point))
            {
                mtime_points_vec_.pop_back();
            }
        }

        mtime_points_vec_.push_back(time_point);

        if (mtime_points_vec_.size() >= 3u)
        {
            const double midpoint = (mtime_points_vec_[0].x + device_time) / 2.0;
            auto lbit = std::lower_bound(mtime_points_vec_.begin(), mtime_points_vec_.end(), midpoint);
            mmid_point_id_ = lbit - mtime_points_vec_.begin() - 1;

            if (mmid_point_id_ > (mtime_points_vec_.size() - 1))
            {
                return ErrorMsgCodes::MIDPOINT_OUT_OF_BOUND_ERROR;
            } 
            if (midpoint >= mtime_points_vec_[mmid_point_id_ + 1].x)
            {
                return ErrorMsgCodes::MIDPOINT_OUT_OF_SEGMENT;
            }  
            if (midpoint <= mtime_points_vec_[mmid_point_id_].x)
            {
                return ErrorMsgCodes::MIDPOINT_OUT_OF_SEGMENT;
            }   
        }
        else
        {
            translated_time = local_time;
        }

        return ErrorMsgCodes::GOOD;
    }
    const TimeTranslator::ErrorMsgCodes TimeTranslator::Translate(const double &device_time, double &translated_time)
    {
        if (mtime_points_vec_.size() < 2)
        {
            return ErrorMsgCodes::CORRECTION_ERROR;
        }
        const TimePoint &l1 = mtime_points_vec_[mmid_point_id_];
        const TimePoint &l2 = mtime_points_vec_[mmid_point_id_ + 1];
        translated_time = l1.y + ((l2.y - l1.y) / (l2.x - l1.x)) * (device_time - l1.x);

        return ErrorMsgCodes::GOOD;
    }
    bool TimeTranslator::ReadyToTranslate() const noexcept
    {
        return mtime_points_vec_.size() >= 2;
    }
    bool TimeTranslator::CheckError(const ErrorMsgCodes error_msg) const noexcept
    {
        return error_msg != ErrorMsgCodes::GOOD ? true : false;
    }
    std::string TimeTranslator::GetErrorMsg(const ErrorMsgCodes error_msg) const noexcept
    {
        switch (error_msg)
        {
        case ErrorMsgCodes::CORRECTION_ERROR:
            return mksys_msg_header_  + "Algorithm translate time only if there are more then two points.";

        case ErrorMsgCodes::TIMEPOINT_FORWARD_ERROR:
            return mksys_msg_header_  + "Remote time is not monotonically increasing.";

        case ErrorMsgCodes::MIDPOINT_OUT_OF_BOUND_ERROR:
            return mksys_msg_header_ + "The computed midpoint segment is out of bounds.";

        case ErrorMsgCodes::MIDPOINT_OUT_OF_SEGMENT:
            return mksys_msg_header_ + ("The computed midpoint is not within the midpoint segment.");

        default:
            return mksys_msg_header_  + "Error code unrecognized.";
        }
    }
    void TimeTranslator::Reset()
    {
        mtime_points_vec_.clear();
        mmid_point_id_ = 0;
    }

    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    //                        PRIVATE FUNCTIONS                           //
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    
    bool TimeTranslator::IsAboveTopLine(const TimePoint &p) const
    {
        return IsAboveLine(mtime_points_vec_[mtime_points_vec_.size() - 2], mtime_points_vec_[mtime_points_vec_.size() - 1], p);
    }
    bool TimeTranslator::IsBelowTopLine(const TimePoint &p) const
    {
        return IsAboveLine(mtime_points_vec_[mtime_points_vec_.size() - 2], p, mtime_points_vec_[mtime_points_vec_.size() - 1]);
    }
    bool TimeTranslator::IsAboveLine(const TimePoint &l1, const TimePoint &l2, const TimePoint &p) const
    {
        return (((l2.x - l1.x) * (l1.y - p.y)) - ((l2.y - l1.y) * (l1.x- p.x))) >= 0.0;
    }
    TimeTranslator::TimePoint::TimePoint() : x(0), y(0) {}
    TimeTranslator::TimePoint::TimePoint(const double &x, const double &y) : x(x), y(y) {}

    bool TimeTranslator::TimePoint::operator<(const TimePoint &p) const noexcept
    {
        return x < p.x;
    }
    bool TimeTranslator::TimePoint::operator<(const double &t) const noexcept
    {
        return x < t;
    }
}