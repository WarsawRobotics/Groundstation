#ifndef GROUND_STATION
#define GROUND_STATION

#include "hid_link_msg_ground_station.h"
#include "hid_link_msg_ground_station_calibration.h"
#include "ground_station_ros.hpp"
#include "hid_link_wrapper.hpp"

namespace diagstar
{
    class GroundStation
    {
    public:
        GroundStation();
        bool Initialize();
        void CalibrateJoysticks();
        void Run();
        void QuitInterrupt(int sig);

    private:
        void SendJoystickCalibrationData(hid_link_ground_station_calibr_msg_t &calibration_data);
        void PrintAxisCalibrationData(const std::string &axis, const uint16_t *axis_calibrated);
        void CalibrateJoystickAxis(uint16_t *axis, const uint8_t &axis_str_idx, const std::string &axis_name);
        void HandleGroundstationMsg(const hid_link_msg_t &msg);
        void HandleGroundstationCalibrationMsg(const hid_link_msg_t &msg);
        void HandleHeartbeatMsg(const hid_link_msg_t &msg);
        void RequestCalibrationData();

        const std::string sys_msg_header_ = "[GroundStation] ";

        hid_link_ground_station_msg_t ground_station_msg;
        GroundStationRos ground_station_ros_node_;
        HidLinkWrapper hid_link_wrp_;
        volatile sig_atomic_t exit_;
    };
} // namespace diagstar
#endif // GROUND_STATION