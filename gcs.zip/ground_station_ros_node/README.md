Po sklonowaniu trzeba jeszcze wpisac nastepujace komendy:   
```bash
git submodule update --init --recursive
git submodule update --recursive --remote
```  
I dopiero potem:
```bash
mkdir build && cd build
cmake .. && make
```