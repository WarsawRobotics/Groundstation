## Opis repozytorium  
Repozytorium zawiera skrypt Arduino do generowania sygnału CPPM. Wygenerowany sygnał przesyłany jest do nadajnika RC.

