#ifndef COMMON_HPP
#define COMMON_HPP

/* Std Libs */
#include <memory>
#include <type_traits>
#include <unistd.h>

namespace diagstar
{
    namespace common
    {
        template <typename Enum>
        inline constexpr typename std::underlying_type<Enum>::type CastEnum(Enum e) noexcept
        {
            return static_cast<typename std::underlying_type<Enum>::type>(e);
        }
    } // namespace common
} // namespace diagstar
namespace std
{
#if __cplusplus == 201103L
    template <typename T, typename... Ts>
    inline std::unique_ptr<T> make_unique(Ts &&... params)
    {
        return std::unique_ptr<T>(new T(std::forward<Ts>(params)...));
    }
#endif
} // namespace std
#endif //COMMON_HPP
