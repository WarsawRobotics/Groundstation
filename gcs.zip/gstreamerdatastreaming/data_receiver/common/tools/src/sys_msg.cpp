#include "sys_msg.hpp"

using namespace diagstar;

int SystemMsg::mverbose_ = common::CastEnum(SystemMsg::VerboseLevel::ALL);
std::mutex SystemMsg::mprint_mut_;
std::array<int, 4> SystemMsg::msg_color_lut =
{
    common::CastEnum(MsgColor::YELLOW),
    common::CastEnum(MsgColor::RED),
    common::CastEnum(MsgColor::GREEN),
    common::CastEnum(MsgColor::YELLOW)
};
std::array<std::string, 4> SystemMsg::msg_type_lut =
{
    "[ WARN]",
    "[ERROR]",
    "[   OK]",
    "[ INFO]"
};
std::array<std::array<bool, 4>, 3> SystemMsg::verbose_truth_lut =
{{
    {false, false, false, false},
    {true, true, false, false},
    {true, true, true, true}
}};
