#ifndef MAPLAB_DIAGNOSTIC_DATA_HPP
#define MAPLAB_DIAGNOSTIC_DATA_HPP

/* Local Libs */
#include "diagnostic_data_base.hpp"

/* Ros Libs */
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/TransformStamped.h>

namespace diagstar
{
    class MaplabDiagnosticData : public DiagnosticDataBase
    {
    public:
        MaplabDiagnosticData(std::string &&topics, size_t &&port);

        void Init() override;
        void PublishData(const mavlink_message_t &data) override;
    private:
        void PublishPose(const mavlink_rovio_full_t &rovio_msg);
        void PublishTransform(const mavlink_rovio_full_t &rovio_msg);
        void Publish(const mavlink_rovio_full_t &rovio_msg);

        ros::Publisher pose_pub_;
        std::string pose_topic_;
    };
} // namespace diagstar

#endif //MAPLAB_DIAGNOSTIC_DATA_HPP