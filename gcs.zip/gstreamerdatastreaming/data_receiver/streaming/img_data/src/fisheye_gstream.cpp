#include "fisheye_gstream.hpp"

namespace diagstar
{
    FisheyeGStream::FisheyeGStream()
    {
        encoding_ = "GRAY8";
        sys_msg_header_ = "[FisheyeGStream] ";
        port_ = 5000;
        image_height_ = 480;
        image_width_ = 640;
        stream_type_ = ImgStreamType::FISHEYE;
        image_size_ = image_width_ * image_height_ * sizeof(uint8_t);
    }
    void FisheyeGStream::Initialize()
    {
        source_ = gst_element_factory_make("udpsrc", "fisheye_stream_source");
        payload_ = gst_element_factory_make("rtph264depay", "fisheye_stream_payload");
        parser_ = gst_element_factory_make("h264parse", "fisheye_stream_parser");
        decoder_ = gst_element_factory_make("decodebin", "fisheye_stream_decoder");
        converter_ = gst_element_factory_make("videoconvert", "fisheye_stream_convert");
        sink_ = gst_element_factory_make("appsink", "fisheye_stream_sink");
        pipeline_ = gst_pipeline_new("fisheye_pipeline");

        if (!pipeline_ || !source_ || !payload_ || !parser_ || !decoder_ || !converter_ || !sink_)
        {
            SystemMsg::ThrowError(sys_msg_header_ + "Not all elements could be created");
            status_ = Status::INITIALIZE_FAIL;
            return;
        }

        GstCaps *video_caps = gst_caps_new_simple("video/x-raw",
                                                "format", G_TYPE_STRING, encoding_.c_str(),
                                                "width", G_TYPE_INT, image_width_,
                                                "height", G_TYPE_INT, image_height_,
                                                "framerate", GST_TYPE_FRACTION, 35, 1, nullptr);

        GstCaps *rtp_caps = gst_caps_new_simple("application/x-rtp",
                                                "encoding-name", G_TYPE_STRING, "H264", nullptr);

        g_object_set(source_, "port", port_, "caps", rtp_caps, nullptr);
        g_object_set(sink_, "emit-signals", true, "caps", video_caps, "sync", false, nullptr);
        g_signal_connect(sink_, "new-sample", G_CALLBACK(NewDataCallback), this);
        gst_caps_unref(video_caps);
        gst_caps_unref(rtp_caps);

        gst_bin_add_many(GST_BIN(pipeline_), source_, payload_, parser_, decoder_, converter_, sink_, nullptr);

        if (gst_element_link_many(source_, payload_, parser_, nullptr) != true)
        {
            SystemMsg::ThrowError(sys_msg_header_ + "Not all elements could be linked");
            status_ = Status::INITIALIZE_FAIL;
            return;
        }
        if (gst_element_link(parser_, decoder_) != true)
        {
            SystemMsg::ThrowError(sys_msg_header_ + "Not all elements could be linked");
            status_ = Status::INITIALIZE_FAIL;
            return;
        }
        if (gst_element_link(converter_, sink_) != true)
        {
            SystemMsg::ThrowError(sys_msg_header_ + "Not all elements could be linked");
            status_ = Status::INITIALIZE_FAIL;
            return;
        }
        g_signal_connect(decoder_, "pad-added", G_CALLBACK(NewPadCallback), converter_);
        SystemMsg::ThrowOk(sys_msg_header_ + "Stream initialized.");
        status_ = Status::INITIALIZE_SUCCESS;
    }
}; // namespace diagstar