#ifndef STREAMS_COMMON_HPP
#define STREAMS_COMMON_HPP

/* Local Libs */
#include "helpers.hpp"

namespace diagstar
{
    enum class ImgStreamType : int
    {
        UNKNOWN = -1,
        DEPTH = 0,
        FISHEYE = 1,
        COLOR = 2
    };
}; // namespace diagstar

#endif //STREAMS_COMMON_HPP