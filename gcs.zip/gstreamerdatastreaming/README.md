TODO:  
- poprawa obslugi bledow - wycieki pamieci (do sprawdzenia) - do sprawdzenia okazyjnie pojawiajacy sie blad z biblioteki libpng   
- wysylanie danych diagnostycznych (lekko przerobić) -> brakuje watchdoga, do przetestowania     
- zmiany w odbiorniku  

Uwagi  
Data racing rozstał rozwiązany poprzez rozdzielenie nadajnika na dwa mniejsze programy obsłgujące streamy.  

Obecnie przy wysyłaniu mapy głębi trzeba dostroić kilka parametrów. Jeżeli stopień kompresji png jest zbyt mały to wysłanie danych nie jest zagwarantowane. Rozmiar wiadomości przekracza dopuszczalny zakres. Póki co nie wiem czy zakres jest zdefiniowany przez gstreamera czy może przez standard UDP. Więc wyjścia są dwa: albo zmniejszana jest rozdzielczość mapy głębi oraz stopień kompresji (460x240 testowane i działa dobrze przy najmniejszym stopniu kompresji), albo rozdzielczość zostaje i zwiększane jest zużycie procesora.  
