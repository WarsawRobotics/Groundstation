#ifndef WATCHDOG_HPP
#define WATCHDOG_HPP

/* Std Libs */
#include <vector>
#include <chrono>
#include <mutex>

/* Local Libs */
#include "helpers.hpp"
#include "sys_msg.hpp"

/* Ros Libs */
#include <ros/ros.h>
#include <std_msgs/Header.h>

namespace diagstar
{
    class WatchDog
    {
        using Keys = std::vector<bool>;
        using HeartBeat = std_msgs::Header;
        using HighResClockTimePoint = std::chrono::high_resolution_clock::time_point;

    public:
        static WatchDog &GetInstance()
        {
            static WatchDog watchdog;
            return watchdog;
        }
        void Init(const uint32_t &keys_number)
        {
            mkeys_numb_ = keys_number;
            mkeys_.resize(mkeys_numb_);
            mheartbeat_.frame_id = "heartbeat";
            mheartbeat_pub_ = mnode_handle_.advertise<HeartBeat>(mkheartbeat_topic_, 1);
        }
        void SignalHeartbeat(const uint32_t &key)
        {
            std::lock_guard<std::mutex> lock(msignal_rev_mutex_);

            if (mkeys_[key] != true)
            {
                ++mrecv_signal_counter_;
                mkeys_[key] = true;
            }
            else
            {
                if (mrecv_signal_counter_ == mkeys_numb_)
                {
                    CheckTimeTreshold();
                    EmitRosHeartbeat();
                    SetKeysDefaultValues();
                }
            }
        }
        void RegisterKey(uint32_t &key) noexcept
        {
            if (mkeys_numb_ == 0)
            {
                SystemMsg::ThrowError(mksys_header_msg_ + "Keys maximum number not specified.");
            }
            else
            {
                key = mkey_counter_++;
                if (mkeys_numb_ < mkey_counter_)
                {
                    SystemMsg::ThrowError(mksys_header_msg_ + "Key counter is greater than keys maximum number.");
                }
                else
                {
                    mkeys_[key] = false;
                }
            }
        }

    private:
        WatchDog() = default;
        ~WatchDog() = default;
        WatchDog(const WatchDog &) = delete;
        WatchDog &operator=(const WatchDog &) = delete;
        WatchDog(const WatchDog &&) = delete;
        WatchDog &operator=(const WatchDog &&) = delete;

        void EmitRosHeartbeat()
        {
            ++mheartbeat_.seq;
            mheartbeat_.stamp = ros::Time::now();
            mheartbeat_pub_.publish(mheartbeat_);
        }
        void CheckTimeTreshold()
        {
            const auto time_now = std::chrono::high_resolution_clock::now();
            const auto time_diff = std::chrono::duration_cast<std::chrono::milliseconds>(time_now - mlast_signal_time_);

            if (time_diff > mheartbeat_max_time_ && mlast_signal_time_.time_since_epoch().count() != 0)
            {
                SystemMsg::ThrowWarn(mksys_header_msg_ + "No heartbeat received from all sensors in given time.", true);
            }
            mlast_signal_time_ = time_now;
        }
        void SetKeysDefaultValues()
        {
            for (size_t i = 0; i < mkeys_numb_; ++i)
            {
                mkeys_[i] = false;
            }
            mrecv_signal_counter_ = 0;
        }

        ros::Publisher mheartbeat_pub_;
        ros::NodeHandle mnode_handle_;
        HeartBeat mheartbeat_;
        Keys mkeys_;
        std::mutex msignal_rev_mutex_;
        HighResClockTimePoint mlast_signal_time_;

        size_t mrecv_signal_counter_ = 0;
        uint32_t mkeys_numb_ = 0;
        uint32_t mkey_counter_ = 0;

        const std::chrono::milliseconds mheartbeat_max_time_ = std::chrono::milliseconds(1500U);
        const std::string mkheartbeat_topic_ = "/depth_transmiter/watch_dog";
        const std::string mksys_header_msg_ = "[Watchdog] ";
    };
} // namespace diagstar
#endif // WATCHDOG_HPP