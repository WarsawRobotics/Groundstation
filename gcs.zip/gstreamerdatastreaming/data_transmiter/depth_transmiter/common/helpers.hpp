#ifndef __COMMON_HPP__
#define __COMMON_HPP__

/* Std Libs */
#include <type_traits>
#include <memory>

namespace diagstar
{
    namespace common
    {
        template <typename Enum>
        inline constexpr typename std::underlying_type<Enum>::type CastEnum(Enum e) noexcept
        {
            return static_cast<typename std::underlying_type<Enum>::type>(e);
        }

        template<typename T, typename ...Ts>
        inline std::unique_ptr<T> MakeUnique(Ts &&...params)
        {
            return std::unique_ptr<T>(new T(std::forward<Ts>(params)...));
        }

    } // namespace common
} // namespace diagstar
#endif //__COMMON_HPP__
