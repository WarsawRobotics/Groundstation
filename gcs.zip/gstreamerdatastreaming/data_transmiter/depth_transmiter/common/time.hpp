#ifndef __TIME_HPP__
#define __TIME_HPP__

/* Std Libs */
#include <chrono>

namespace diagstar
{
    class Time
    {
        using HighResClock = std::chrono::system_clock;
        using NanoSeconds = std::chrono::nanoseconds;

    public:
        template <typename Uint32_t>
        Time(Uint32_t &&seconds, Uint32_t &&nanos) : sec(std::forward<Uint32_t>(seconds)), nsec(std::forward<Uint32_t>(nanos)) {}

        Time() : sec(0), nsec(0) {}

        static Time Now()
        {
            auto now = std::chrono::time_point_cast<NanoSeconds>(HighResClock::now());
            auto value = std::chrono::duration_cast<NanoSeconds>(now.time_since_epoch());
            return Time(value.count() / 1000000000, value.count() % 1000000000);
        }

        double toNSec() const noexcept
        {
            return static_cast<double>(sec) * 1000000000.0 + static_cast<double>(nsec);
        }

        double toSec() const noexcept
        {
            return static_cast<double>(sec) + static_cast<double>(nsec) / 1000000000.0;
        }

        static double MillisToNanos(const double &millis) noexcept
        {
            return millis * 1000000.0;
        }
        static double MicrosToNanos(const double &micros) noexcept
        {
            return micros * 1000.0;
        }
        static double SecondsToMicros(const double &seconds) noexcept
        {
            return seconds * 1000000.0;
        }
        static double MicrosToSeconds(const double &micros) noexcept
        {
            return micros * 0.000001;
        }

        uint32_t sec;
        uint32_t nsec;
    };
} // namespace diagstar
#endif //__TIME_HPP__