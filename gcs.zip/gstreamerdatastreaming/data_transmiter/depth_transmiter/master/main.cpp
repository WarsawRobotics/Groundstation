#include "transmiter.hpp"
#include "ros_master.hpp"
#include "watchdog.hpp"

using namespace diagstar;

Transmiter *transmiter_ptr = nullptr;
void quit_interrupt(int sig)
{
    transmiter_ptr->QuitInterrupt(sig);
}
int main(int argc, char *argv[])
{
    diagstar::RosMaster ros_master(argc, argv, "depth_streaming_node");
    if (ros_master.IsInitialized())
    {
        Transmiter transmiter;
        WatchDog::GetInstance().Init(1);

        transmiter.Initialize({"/camera/depth/image_rect_raw",
                               "192.168.26.105",
                               "GRAY16_BE",
                               5001,
                               240,
                               320,
                               10});

        transmiter_ptr = &transmiter;
        signal(SIGINT, quit_interrupt);
        transmiter.Run();
    }
    return 0;
}
