#ifndef ROVIO_DIAGNOSTIC_DATA_HPP
#define ROVIO_DIAGNOSTIC_DATA_HPP

/* Std Libs */
#include <mutex>

/* Local Libs */
#include "diagnostic_data_base.hpp"

/* Ros Libs */
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <geometry_msgs/TransformStamped.h>

namespace diagstar
{
    class RovioDiagnosticData : public DiagnosticData
    {
    public:
        RovioDiagnosticData(std::string &&topics, uint16_t &&port, Protocol *protocol);
        void Init() override;

    private:
        void ListenRovioTransform(const geometry_msgs::TransformStampedConstPtr &transform);
        void ListenRovioExtrinsics(const geometry_msgs::PoseWithCovarianceStampedConstPtr &extrinsics);
        void EncodeData() override;

        std::mutex data_encode_mutex_;
        bool data_ready_, extrinsics_ready_;
        ros::Subscriber data_sub_, extrinsics_sub_;
        std::string data_topic_, extrinsics_topic_;
        mavlink_rovio_full_t mrovio_full_msg_;
    };
} // namespace diagstar
#endif //ROVIO_DIAGNOSTIC_DATA_HPP