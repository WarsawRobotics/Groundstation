#ifndef MAPLAB_DIAGNOSTIC_DATA_HPP
#define MAPLAB_DIAGNOSTIC_DATA_HPP

/* Local Libs */
#include "diagnostic_data_base.hpp"

/* Ros Libs */
#include <geometry_msgs/PoseStamped.h>

namespace diagstar
{
    class MaplabDiagnosticsData : public DiagnosticData
    {
    public:
        MaplabDiagnosticsData(std::string &&topics, uint16_t &&port, Protocol *protocol);
        void Init() override;

    private:
        void ListenMaplabData(const geometry_msgs::PoseStampedConstPtr &pose);
        void EncodeData() override;

        ros::Subscriber data_sub_;
        mavlink_rovio_full_t mrovio_full_msg_;
        std::string data_topic_;
    };
} // namespace diagstar

#endif //MAPLAB_DIAGNOSTIC_DATA_HPP