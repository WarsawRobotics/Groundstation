#include "maplab_diagnostic_data.hpp"

namespace diagstar
{
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    //                        PUBLIC FUNCTIONS                            //
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

    MaplabDiagnosticsData::MaplabDiagnosticsData(std::string &&topics, uint16_t &&port, Protocol *protocol)
     : DiagnosticData(std::move(topics), std::move(port), protocol)
    {
        sys_msg_header_ = "[MaplabDiagnosticData] ";
        const auto topic_list = GetTopics(std::move(topics_));
        if (topic_list.size() > 2 || topic_list.size() == 0)
        {
            SystemMsg::ThrowError(sys_msg_header_ + "Too many or too few topics defined.");
            throw EXIT_FAILURE;
        }
        data_topic_ = topic_list[0];
    }
    void MaplabDiagnosticsData::Init()
    {
        try
        {
            data_sub_ = nh_.subscribe(data_topic_, 1, &MaplabDiagnosticsData::ListenMaplabData, this);
            receiver_id_ = protocol_->AddReceiver(port_);
            status_ = DiagnosticDataStatus::INITIALIZE_SUCCESS;
        }
        catch(const std::runtime_error& e)
        {
            SystemMsg::ThrowError(sys_msg_header_ + e.what());
            status_ = DiagnosticDataStatus::INITIALIZE_FAIL;
        }
        catch(...)
        {
            SystemMsg::ThrowError(sys_msg_header_ + "Unknown error. Aborting.");
            status_ = DiagnosticDataStatus::INITIALIZE_FAIL;
        }
        SystemMsg::ThrowInfo(sys_msg_header_ + protocol_->GetConfigurationString(receiver_id_) + "Topics: " + topics_);
    }

    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    //                        PRIVATE FUNCTIONS                           //
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

    void MaplabDiagnosticsData::ListenMaplabData(const geometry_msgs::PoseStampedConstPtr &pose)
    {
        mrovio_full_msg_.transform_x = pose->pose.position.x;
        mrovio_full_msg_.transform_y = pose->pose.position.y;
        mrovio_full_msg_.transform_z = pose->pose.position.z;
        mrovio_full_msg_.transform_q[0] = static_cast<float>(pose->pose.orientation.w);
        mrovio_full_msg_.transform_q[1] = static_cast<float>(pose->pose.orientation.x);
        mrovio_full_msg_.transform_q[2] = static_cast<float>(pose->pose.orientation.y);
        mrovio_full_msg_.transform_q[3] = static_cast<float>(pose->pose.orientation.z);

        mrovio_full_msg_.extr_x = 0.042160158612407815f;
        mrovio_full_msg_.extr_y = 0.02195143405160522f;
        mrovio_full_msg_.extr_z = -0.003180489112275975f;
        mrovio_full_msg_.extr_q[0] = 0.489278734609f;
        mrovio_full_msg_.extr_q[1] = 0.500226339172f;
        mrovio_full_msg_.extr_q[2] = -0.49950570815f;
        mrovio_full_msg_.extr_q[3] = 0.510758237313f;

        mrovio_full_msg_.time_usec = pose->header.stamp.toNSec() /1000;
        EncodeData();
    }
    void MaplabDiagnosticsData::EncodeData()
    {
        mavlink_message_t msg;
        mavlink_msg_rovio_full_encode(1, 200, &msg, &mrovio_full_msg_);
        protocol_->SendData(msg, receiver_id_);
    }
}