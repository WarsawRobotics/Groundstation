#include "rovio_diagnostic_data.hpp"

namespace diagstar
{
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    //                        PUBLIC FUNCTIONS                            //
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

    RovioDiagnosticData::RovioDiagnosticData(std::string &&topics, uint16_t &&port, Protocol *protocol) : DiagnosticData(std::move(topics), std::move(port), protocol),
                                                                                                          data_ready_(false),
                                                                                                          extrinsics_ready_(false)
    {
        sys_msg_header_ = "[RovioDiagnosticData] ";

        const auto topic_list = GetTopics(std::move(topics_));
        if (topic_list.size() > 2 || topic_list.size() <= 1)
        {
            SystemMsg::ThrowError(sys_msg_header_ + "Too many or too few topics defined.");
            throw EXIT_FAILURE;
        }
        data_topic_ = topic_list[0];
        extrinsics_topic_ = topic_list[1];
    }
    void RovioDiagnosticData::Init()
    {
        try
        {
            data_sub_ = nh_.subscribe(data_topic_, 1, &RovioDiagnosticData::ListenRovioTransform, this);
            extrinsics_sub_ = nh_.subscribe(extrinsics_topic_, 1, &RovioDiagnosticData::ListenRovioExtrinsics, this);
            receiver_id_ = protocol_->AddReceiver(port_);
            status_ = DiagnosticDataStatus::INITIALIZE_SUCCESS;
        }
        catch (const std::runtime_error &e)
        {
            SystemMsg::ThrowError(sys_msg_header_ + e.what());
            status_ = DiagnosticDataStatus::INITIALIZE_FAIL;
        }
        catch (...)
        {
            SystemMsg::ThrowError(sys_msg_header_ + "Unknown error. Aborting.");
            status_ = DiagnosticDataStatus::INITIALIZE_FAIL;
        }
        SystemMsg::ThrowInfo(sys_msg_header_ + protocol_->GetConfigurationString(receiver_id_) + "Topics: " + topics_);
    }

    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    //                        PRIVATE FUNCTIONS                           //
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

    void RovioDiagnosticData::ListenRovioTransform(const geometry_msgs::TransformStampedConstPtr &transform)
    {
        mrovio_full_msg_.transform_x = static_cast<float>(transform->transform.translation.x);
        mrovio_full_msg_.transform_y = static_cast<float>(transform->transform.translation.y);
        mrovio_full_msg_.transform_z = static_cast<float>(transform->transform.translation.z);
        mrovio_full_msg_.transform_q[0] = static_cast<float>(transform->transform.rotation.w);
        mrovio_full_msg_.transform_q[1] = static_cast<float>(transform->transform.rotation.x);
        mrovio_full_msg_.transform_q[2] = static_cast<float>(transform->transform.rotation.y);
        mrovio_full_msg_.transform_q[3] = static_cast<float>(transform->transform.rotation.z);

        data_ready_ = true;
        EncodeData();
    }
    void RovioDiagnosticData::ListenRovioExtrinsics(const geometry_msgs::PoseWithCovarianceStampedConstPtr &extrinsics)
    {
        mrovio_full_msg_.extr_x = static_cast<float>(extrinsics->pose.pose.position.x);
        mrovio_full_msg_.extr_y = static_cast<float>(extrinsics->pose.pose.position.y);
        mrovio_full_msg_.extr_z = static_cast<float>(extrinsics->pose.pose.position.z);
        mrovio_full_msg_.extr_q[0] = static_cast<float>(extrinsics->pose.pose.orientation.w);
        mrovio_full_msg_.extr_q[1] = static_cast<float>(extrinsics->pose.pose.orientation.x);
        mrovio_full_msg_.extr_q[2] = static_cast<float>(extrinsics->pose.pose.orientation.y);
        mrovio_full_msg_.extr_q[3] = static_cast<float>(extrinsics->pose.pose.orientation.z);

        extrinsics_ready_ = true;
        EncodeData();
    }
    void RovioDiagnosticData::EncodeData()
    {
        std::unique_lock<std::mutex> lock(data_encode_mutex_);
        if (data_ready_ && extrinsics_ready_)
        {
            mavlink_message_t msg;
            mrovio_full_msg_.time_usec = ros::Time::now().toNSec() / 1000;
            mavlink_msg_rovio_full_encode(1, 200, &msg, &mrovio_full_msg_);
            protocol_->SendData(msg, receiver_id_);
            data_ready_ = false;
            extrinsics_ready_ = false;
        }
    }
} // namespace diagstar