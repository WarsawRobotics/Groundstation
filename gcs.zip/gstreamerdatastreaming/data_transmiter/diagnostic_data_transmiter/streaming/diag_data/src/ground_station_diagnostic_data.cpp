#include "ground_station_diagnostic_data.hpp"

namespace diagstar
{
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    //                        PUBLIC FUNCTIONS                            //
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

    GroundStationData::GroundStationData(std::string &&topics, uint16_t &&port, Protocol *protocol)
        : DiagnosticData(std::move(topics), std::move(port), protocol)
    {
        sys_msg_header_ = "[GCSDiagnosticData] ";
        const auto topic_list = GetTopics(std::move(topics_));
        if (topic_list.size() > 2 || topic_list.size() == 0)
        {
            SystemMsg::ThrowError(sys_msg_header_ + "Too many or too few topics defined.");
            throw EXIT_FAILURE;
        }
        data_topic_ = topic_list[0];
        gcs_expected_joy_data_numb = ARRAY_SIZE(gcs_msg_.mouse) +
                                     ARRAY_SIZE(gcs_msg_.throttle_yaw) +
                                     ARRAY_SIZE(gcs_msg_.pitch_roll);
    }
    void GroundStationData::Init()
    {
        try
        {
            data_sub_ = nh_.subscribe(data_topic_, 1, &GroundStationData::ListenGroundStationData, this);
            receiver_id_ = protocol_->AddReceiver(port_);
            status_ = DiagnosticDataStatus::INITIALIZE_SUCCESS;
        }
        catch (const std::runtime_error &e)
        {
            SystemMsg::ThrowError(sys_msg_header_ + e.what());
            status_ = DiagnosticDataStatus::INITIALIZE_FAIL;
        }
        catch (...)
        {
            SystemMsg::ThrowError(sys_msg_header_ + "Unknown error. Aborting.");
            status_ = DiagnosticDataStatus::INITIALIZE_FAIL;
        }
        SystemMsg::ThrowInfo(sys_msg_header_ + protocol_->GetConfigurationString(receiver_id_) + "Topics: " + topics_);
    }

    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    //                        PRIVATE FUNCTIONS                           //
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

    void GroundStationData::ListenGroundStationData(const sensor_msgs::JoyConstPtr &gcs_data)
    {
        if (gcs_data->axes.size() == gcs_expected_joy_data_numb &&
            gcs_data->buttons.size() == common::ArraySize(gcs_msg_.switches))
        {
            gcs_msg_.throttle_yaw[0] = gcs_data->axes[0];
            gcs_msg_.throttle_yaw[1] = gcs_data->axes[1];
            gcs_msg_.throttle_yaw[2] = gcs_data->axes[2];

            gcs_msg_.pitch_roll[3] = gcs_data->axes[3];
            gcs_msg_.pitch_roll[4] = gcs_data->axes[4];
            gcs_msg_.pitch_roll[5] = gcs_data->axes[5];

            gcs_msg_.mouse[0] = gcs_data->axes[5];
            gcs_msg_.mouse[1] = gcs_data->axes[6];
            gcs_msg_.mouse[2] = gcs_data->axes[7];
            gcs_msg_.mouse[3] = gcs_data->axes[8];
            gcs_msg_.mouse[4] = gcs_data->axes[9];
            gcs_msg_.mouse[5] = gcs_data->axes[10];

            gcs_msg_.switches[0] = static_cast<uint8_t>(gcs_data->buttons[0]);
            gcs_msg_.switches[1] = static_cast<uint8_t>(gcs_data->buttons[1]);
            gcs_msg_.switches[2] = static_cast<uint8_t>(gcs_data->buttons[2]);
            gcs_msg_.switches[3] = static_cast<uint8_t>(gcs_data->buttons[3]);

            gcs_msg_.time_usec = gcs_data->header.stamp.toNSec() / 1000;
            EncodeData();
        }
        else
        {
            SystemMsg::ThrowError(sys_msg_header_ + "Mavlink and ROS ground station data number dont match.");
        }
    }
    void GroundStationData::EncodeData()
    {
        mavlink_message_t msg;
        mavlink_msg_gcs_encode(1, 5, &msg, &gcs_msg_);
        protocol_->SendData(msg, receiver_id_);
    }
} // namespace diagstar