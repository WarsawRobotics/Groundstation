#ifndef THREAD_RAII_HPP
#define THREAD_RAII_HPP

#include <thread>

namespace diagstar
{
    class ThreadRAII
    {
    public:
        enum class Action
        {
            JOIN,
            DETACH
        };
        ThreadRAII() {}

        ThreadRAII(std::thread &&worker, Action action)
            : maction_(action), mworker_(std::move(worker)) {}

        ~ThreadRAII()
        {
            Join();
        }

        ThreadRAII(ThreadRAII &&) = default;
        ThreadRAII &operator=(ThreadRAII &&) = default;


        void Join()
        {
            if (mworker_.joinable())
            {
                if (maction_ == Action::JOIN)
                {
                    mworker_.join();
                }
                else
                {
                    mworker_.detach();
                }
            }
        }
        std::thread &Get()        
        {
            return mworker_;
        }

    private:
        Action maction_;
        std::thread mworker_;
    };
} // namespace diagstar

#endif //THREAD_RAII_HPP
