#ifndef HELPERS_HPP
#define HELPERS_HPP

/* Std Libs */
#include <memory>
#include <type_traits>

#define ARRAY_SIZE(a) (sizeof(a) / sizeof(a[0]))

namespace diagstar
{
    namespace common
    {
        template <typename Enum>
        inline constexpr typename std::underlying_type<Enum>::type CastEnum(Enum e) noexcept
        {
            return static_cast<typename std::underlying_type<Enum>::type>(e);
        }

        template <typename T, typename... Ts>
        inline std::unique_ptr<T> MakeUnique(Ts &&... params)
        {
            return std::unique_ptr<T>(new T(std::forward<Ts>(params)...));
        }

        template <typename T, std::size_t N>
        constexpr std::size_t ArraySize(T (&)[N]) noexcept 
        {
            return N;
        }
    } // namespace common
} // namespace diagstar
#endif //HELPERS_HPP
