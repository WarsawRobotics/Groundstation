#include "diagnostic_data_manager.hpp"
#include "maplab_diagnostic_data.hpp"
#include "ground_station_diagnostic_data.hpp"
#include "ros_master.hpp"
#include "threadRAII.hpp"
#include "udp_protocol.hpp"
#include <csignal>

using namespace diagstar;

void quit_interrupt(int sig)
{
    ros::shutdown();
}
int main(int argc, char *argv[])
{
    //DiagnosticDataManager<UdpProtocol> diag_data_man(std::atoi(argv[2]), argv[1]);
    DiagnosticDataManager<UdpProtocol> diag_data_man("192.168.1.1");
    RosMaster ros_master(argc, argv);
    if (ros_master.IsInitialized())
    {
        signal(SIGINT, quit_interrupt);
        
        diag_data_man.AddDiagnosticData<MaplabDiagnosticsData>("/maplab_rovio/T_G_I", 5000);
        diag_data_man.AddDiagnosticData<GroundStationData>("/groundstation/state", 5001);
        diag_data_man.Init();
        diag_data_man.Run();
    }
    return 0;
}
