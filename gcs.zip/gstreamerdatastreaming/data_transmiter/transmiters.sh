#!/bin/bash

echo "==========================================================="
echo "          WIRELESS DATA TRANSMISSION MODULE "
echo "==========================================================="
echo

# Configuration
receiver_ip=192.168.26.105
receiver_udp_port[0]=5000
receiver_udp_port[1]=5001
receiver_udp_port[2]=14550

# Variables
process_list[0]=fisheye_transmiter/build/fisheye_transmiter
process_list[1]=depth_transmiter/build/depth_transmiter
process_list[2]=diagnostic_data_transmiter/build/diagnostic_data_transmiter
process_pid_list=(0 0 0)
process_activation_flags=(1 1 1)

# Start all proceses
for index in ${!process_list[*]}
do
    if { [ ${process_activation_flags[$index]} = 1 ]; }; then
        echo "Starting process: "${process_list[$index]}
        echo "-----------------------------------------"
        ./${process_list[$index]} $receiver_ip ${receiver_udp_port[$index]} &
        process_pid_list[$index]=$!
        sleep 1
        echo ""
    fi
done
wait

# Send ^C signal to all proceses.
for index in ${!process_list[*]}
do
    if { [ ${process_activation_flags[$index]} = 1 ]; }; then
        kill -INT ${process_pid_list[$index]}
    fi
done