#include "hid_simple_protocol.h"
#include <string.h>

#define START_BYTE 0xFF
#define DATA_POS 3

void simple_protocol_send_msg(hid_simple_protocol_msg_t* hid_msg, int timeout)
{
    usb_rawhid_send(1, hid_msg->msg, timeout);
}
int simple_protocol_receive_msg(hid_simple_protocol_msg_t* hid_msg, int timeout)
{
    memset(hid_msg->msg, 0, sizeof(uint8_t) * RAWHID_DATA_SIZE);
    return usb_rawhid_recv(0, hid_msg->msg, timeout);
}
void simple_protocol_encode_msg(hid_simple_protocol_msg_t* hid_msg)
{
    uint16_t checksum = 0;
    memset(hid_msg->msg, 0, sizeof(uint8_t) * RAWHID_DATA_SIZE);
    hid_msg->msg[0] = START_BYTE;
    hid_msg->msg[1] = hid_msg->dev_id;
    hid_msg->msg[2] = hid_msg->msg_id;

    for (uint8_t i = 0; i < DATA_LEN; i++)
    {
        hid_msg->msg[i + 3] = hid_msg->data[i];
        checksum += hid_msg->data[i];
    }
    hid_msg->msg[DATA_LEN + DATA_POS] = checksum >> 0x08;
    hid_msg->msg[DATA_LEN + DATA_POS + 1] = checksum;
}
int simple_protocol_decode_msg(hid_simple_protocol_msg_t* hid_msg)
{
    int state = 0;
    memset(hid_msg->data, 0, sizeof(uint8_t) * DATA_LEN);
    if (hid_msg->msg[0] == START_BYTE)
    {
        hid_msg->dev_id = hid_msg->msg[1];
        hid_msg->msg_id = hid_msg->msg[2];

        uint16_t calc_checksum = hid_msg->dev_id + hid_msg->msg_id;

        for (uint8_t i = 0; i < DATA_LEN; i++)
        {
            hid_msg->data[i] = hid_msg->msg[i + DATA_POS];
            calc_checksum += hid_msg->data[i];
        }
        uint16_t checksum = hid_msg->msg[DATA_LEN + DATA_POS] << 0x08 | hid_msg->msg[DATA_LEN + DATA_POS + 1];
        state = calc_checksum == checksum ? 1 : -1;
    }
    else
    {
        state = -1;
    }
    return state;
}