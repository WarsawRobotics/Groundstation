/**
 * @file hid_simple_protocol.h
 * @author Jacek Szaltys
 * @brief 
 * @version 0.1
 * @date 2019-09-25
 * 
 * @copyright Copyright (c) 2019
 * 
 */
#ifndef HID_SIMPLE_PROTOCOL
#define HID_SIMPLE_PROTOCOL

#define DATA_LEN 59
#define SELF_ID 0x61

#include <stdint.h>
#include "io_hid.h"

#ifdef __cplusplus
extern "C"
{
#endif
    typedef struct 
    {
        uint8_t data[DATA_LEN];
        uint8_t msg[RAWHID_DATA_SIZE];
        uint8_t dev_id, msg_id;
    } hid_simple_protocol_msg_t;

    int simple_protocol_receive_msg(hid_simple_protocol_msg_t* hid_msg, int timeout);
    void simple_protocol_send_msg(hid_simple_protocol_msg_t* hid_msg, int timeout);
    int simple_protocol_decode_msg(hid_simple_protocol_msg_t* hid_msg);
    void simple_protocol_encode_msg(hid_simple_protocol_msg_t* hid_msg);
#ifdef __cplusplus
}
#endif
#endif //HID_SIMPLE_PROTOCOL