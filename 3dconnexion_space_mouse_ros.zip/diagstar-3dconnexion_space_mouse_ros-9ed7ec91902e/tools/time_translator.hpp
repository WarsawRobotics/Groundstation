/**
 * @file time_translator.hpp
 * @author Jacek Szaltys
 * @brief An implementation of the convex hull algorithm for one-way
 * timestamp synchronization from:
 * L. Zhang, Z. Liu, and C. Honghui Xia,
 * “Clock synchronization algorithms for network measurements”,
 * in INFOCOM 2002. Twenty-First Annual Joint Conference of the
 * IEEE Computer and Communications Societies., vol. 1. IEEE,
 * 2002, pp. 160–169 vol.1.
 * @version 0.1
 * @date 2019-08-30
 * 
 * @copyright Copyright (c) 2019
 * 
 */

#ifndef TIME_TRANSLATOR_HPP
#define TIME_TRANSLATOR_HPP

/* Std Libs */
#include <string>
#include <vector>

namespace diagstar
{
    class TimeTranslator
    {
        struct TimePoint
        {
            TimePoint();
            TimePoint(const double &x, const double &y);

            bool operator<(const TimePoint &p) const noexcept;
            bool operator<(const double &t) const noexcept;

            double x, y;
        };

    public:
        enum class ErrorMsgCodes
        {
            GOOD,
            CORRECTION_ERROR,
            TIMEPOINT_FORWARD_ERROR,
            MIDPOINT_OUT_OF_BOUND_ERROR,
            MIDPOINT_OUT_OF_SEGMENT
        };

        TimeTranslator();

        /**
         * @brief Get an estimate of the local time of a given measurement
         * from the remote timestamp, the local timestamp, and the
         * previous history of timings.
         * NOTE: this function must be called with monotonically increasing
         *       remote timestamps. If this is not followed, an exception will
         *       be thrown.
         * 
         * @param device_time The time of an event on the device clock
         * @param local_time The timestamp that the event was received locally
         * @param translated_time The estimated actual local time of the event
         * @return const ErrorMsgCodes 
         */
        const ErrorMsgCodes Update(const double &device_time, const double &local_time, double &translated_time);
        /**
         * @brief Using the current best estimate of the relationship between
         * device and local clocks, get the local time of a device timestamp.
         * 
         * @param device_time The time of an event on the device clock
         * @param translated_time The estimated actual local time of the event
         * @return const ErrorMsgCodes Error code.
         */
        const ErrorMsgCodes Translate(const double &device_time, double &translated_time);
        /**
         * @brief Check if there are at least 2 time points in translator list.
         * 
         * @return true Translator ready to operate.
         * @return false Translator not ready.
         */
        bool ReadyToTranslate() const noexcept;
        /**
         * @brief Check if any error occured during update or translate.
         * 
         * @param error_msg Error code.
         * @return true Error.
         * @return false No error. 
         */
        bool CheckError(const ErrorMsgCodes error_msg) const noexcept;
        /**
         * @brief Get error description.
         * 
         * @param error_msg Error code.
         * @return std::string Error description
         */
        std::string GetErrorMsg(const ErrorMsgCodes error_msg) const noexcept;
        /**
         * @brief Set translator internal state to default value.
         * 
         */
        void Reset();

    private:
        /**
         * @brief Is the point above the line defined by the top two points of
         * the convex hull.
         * 
         * @param p Timepoint ti check.
         * @return true 
         * @return false 
         */
        bool IsAboveTopLine(const TimePoint &p) const;
        /**
         * @brief Is the point below the line defined by the top two points of
         * the convex hull.
         * 
         * @param p Timepoint ti check.
         * @return true 
         * @return false 
         */
        bool IsBelowTopLine(const TimePoint &p) const;
        /**
         * @brief Is the point above the line defined by the point l1 and l2.
         * 
         * @param l1 First time point.
         * @param l2 Second time point. 
         * @param p Timepoint ti check.
         * @return true 
         * @return false 
         */
        bool IsAboveLine(const TimePoint &l1, const TimePoint &l2, const TimePoint &p) const;

        std::vector<TimePoint> mtime_points_vec_;
        size_t mmid_point_id_;
        const std::string mksys_msg_header_ = "[TimeTranslator] ";
    };
} // namespace diagstar
#endif // TIME_TRANSLATOR_HPP