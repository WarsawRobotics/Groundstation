/**
 * @file sys_msg.cpp
 * @author Jacek Szaltys
 * @brief 
 * @version 0.1
 * @date 2019-08-30
 * 
 * @copyright Copyright (c) 2019
 * 
 */

#include "sys_msg.hpp"

namespace diagstar
{
    SystemMsg::VerboseLevel SystemMsg::mverbose_ = SystemMsg::VerboseLevel::ALL;
    std::mutex SystemMsg::mprint_mut_;
    std::array<int, 4> SystemMsg::msg_color_lut =
    {
        common::CastEnum(MsgColor::YELLOW),
        common::CastEnum(MsgColor::RED),
        common::CastEnum(MsgColor::GREEN),
        common::CastEnum(MsgColor::YELLOW)
    };
    std::array<std::string, 4> SystemMsg::msg_type_lut =
    {
        "[ WARN]",
        "[ERROR]",
        "[   OK]",
        "[ INFO]"
    };
    std::array<std::array<bool, 4>, 3> SystemMsg::verbose_truth_lut =
    {{
        {false, false, false, false},
        {true, true, false, false},
        {true, true, true, true}
    }};

} // namespace diagstar