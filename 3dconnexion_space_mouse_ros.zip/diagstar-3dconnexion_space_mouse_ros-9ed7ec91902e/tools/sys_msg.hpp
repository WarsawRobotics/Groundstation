/**
 * @file sys_msg.hpp
 * @author Jacek Szaltys
 * @brief 
 * @version 0.1
 * @date 2019-08-30
 * 
 * @copyright Copyright (c) 2019
 * 
 */
#ifndef SYSTEM_MSG_HPP
#define SYSTEM_MSG_HPP

/* Std Libs */
#include <array>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <sstream>
#include <string>

/* Local Libs */
#include "helpers.hpp"
#include "time.hpp"

namespace diagstar
{
    class SystemMsg
    {
        enum class SysMsgCode : int
        {
            WARN,
            ERR,
            OK,
            INFO
        };
        enum class MsgColor : int
        {
            RED = 31,
            GREEN = 32,
            YELLOW = 33,
        };

    public:
        enum class VerboseLevel : int
        {
            NO_VERBOSE,
            ERR_WARN,
            ALL
        };

        SystemMsg() = delete;
        SystemMsg(const SystemMsg &) = delete;
        SystemMsg(SystemMsg &&) = delete;
        SystemMsg &operator=(const SystemMsg &) = delete;
        SystemMsg &operator=(SystemMsg &&) = delete;
        ~SystemMsg() = delete;

        /**
         * @brief Define verbosity level. There are three levels: 
         * All messages visable, error and warning messages visasble, no messages visable.
         * 
         * @param level Verbosity level.
         */
        static void SetVerboseLevel(VerboseLevel level) noexcept
        {
            if (level == VerboseLevel::NO_VERBOSE)
            {
                mverbose_ = VerboseLevel::NO_VERBOSE;
            }
            else if (level == VerboseLevel::ERR_WARN)
            {
                mverbose_ = VerboseLevel::ERR_WARN;
            }
            else if (level >= VerboseLevel::ALL)
            {
                mverbose_ = VerboseLevel::ALL;
            }
            else
            {
                ThrowError("No such verbosity level available: " + std::to_string(common::CastEnum(level)));
            }
        }
        /**
         * @brief Print error message: [red color(ERROR)][current system time][Message]
         * 
         * @tparam String 
         * @param msg User message. 
         * @param multithread_safe True if call simultaneously in many threads.
         */
        template <typename String>
        static void ThrowError(String &&msg, const bool &multithread_safe = false)
        {
            if (multithread_safe)
            {
                std::lock_guard<std::mutex> lock_guard(mprint_mut_);
                ThrowSysMsg(std::forward<String>(msg), common::CastEnum(SysMsgCode::ERR));
            }
            else
            {
                ThrowSysMsg(std::forward<String>(msg), common::CastEnum(SysMsgCode::ERR));
            }
        }
        /**
         * @brief Print info message: [yellow color(INFO)][current system time][Message]
         * 
         * @tparam String 
         * @param msg User message. 
         * @param multithread_safe True if call simultaneously in many threads.
         */
        template <typename String>
        static void ThrowInfo(String &&msg, const bool &multithread_safe = false)
        {
            if (multithread_safe)
            {
                std::lock_guard<std::mutex> lock_guard(mprint_mut_);
                ThrowSysMsg(std::forward<String>(msg), common::CastEnum(SysMsgCode::INFO));
            }
            else
            {
                ThrowSysMsg(std::forward<String>(msg), common::CastEnum(SysMsgCode::INFO));
            }
        }
        /**
         * @brief Print warning message: [yellow color(WARN)][current system time][Message]
         * 
         * @tparam String 
         * @param msg User message. 
         * @param multithread_safe True if call simultaneously in many threads.
         */
        template <typename String>
        static void ThrowWarn(String &&msg, const bool &multithread_safe = false)
        {
            if (multithread_safe)
            {
                std::lock_guard<std::mutex> lock_guard(mprint_mut_);
                ThrowSysMsg(std::forward<String>(msg), common::CastEnum(SysMsgCode::WARN));
            }
            else
            {
                ThrowSysMsg(std::forward<String>(msg), common::CastEnum(SysMsgCode::WARN));
            }
        }
        /**
         * @brief Print ok message: [green color(OK)][current system time][Message]
         * 
         * @tparam String 
         * @param msg User message. 
         * @param multithread_safe True if call simultaneously in many threads.
         */
        template <typename String>
        static void ThrowOk(String &&msg, const bool &multithread_safe = false)
        {
            if (multithread_safe)
            {
                std::lock_guard<std::mutex> lock_guard(mprint_mut_);
                ThrowSysMsg(std::forward<String>(msg), common::CastEnum(SysMsgCode::OK));
            }
            else
            {
                ThrowSysMsg(std::forward<String>(msg), common::CastEnum(SysMsgCode::OK));
            }
        }
    private:
        /**
       * @brief Throw system message based on system message code.
	   * Format of thrown message: ["System code"] [Time in seconds]: "Message". Function is threadsafe if pointer to mutex is passed.
       * 
       * @tparam String 
       * @param msg String message.
       * @param code One of the avaiable codes: WARN, ERROR, INFO, OK.
       */
        template <typename String>
        static void ThrowSysMsg(String &&msg, const int &code)
        {
            if (verbose_truth_lut[common::CastEnum(mverbose_)][code])
            {
                std::stringstream stream;
                stream << std::fixed << std::setprecision(9) << Time::Now().toSec();
                std::cout << "\033[0;" + std::to_string(msg_color_lut[code]) + "m"
                          << msg_type_lut[code]
                          << "\033[0m"
                          << " [" + stream.str() + "]: " + msg << std::endl;
            }
        }
        static VerboseLevel mverbose_;
        static std::mutex mprint_mut_;
        static std::array<int, 4> msg_color_lut;
        static std::array<std::string, 4> msg_type_lut;
        static std::array<std::array<bool, 4>, 3> verbose_truth_lut;
    };
} // namespace diagstar
#endif //SYSTEM_MSG_HPP