/**
 * @file ros_master.cpp
 * @author Jacek Szaltys
 * @brief 
 * @version 0.1
 * @date 2019-09-02
 * 
 * @copyright Copyright (c) 2019
 * 
 */

/* Local libs */
#include "ros_master.hpp"
#include "sys_msg.hpp"

/* Std Libs */
#include <thread>

namespace diagstar
{
    RosMaster::RosMaster(const size_t &connection_attemps, const std::chrono::seconds &connection_attempt_timeout, int argc, char *argv[]) : ros_initialized_(false)
    {
        ros::init(argc, argv, kros_package_name_, ros::init_options::NoSigintHandler);
        for (size_t i = 0; i < connection_attemps; ++i)
        {
            if (ros::master::check())
            {
                SystemMsg::ThrowOk(ksys_msg_header_ + "Connected to ros master.");
                ros_initialized_ = true;
                break;
            }
            else
            {
                SystemMsg::ThrowWarn(ksys_msg_header_ + "Cannot connect ros master. Sleep for " + std::to_string(connection_attempt_timeout.count()) + " [s].");
                std::this_thread::sleep_for(connection_attempt_timeout);
            }
        }
        if (!ros_initialized_)
        {
            SystemMsg::ThrowError(ksys_msg_header_ + "Cannot connect to ros master. Connection attempts exceeded threshold.");
        }
    }
    void RosMaster::Stop()
    {
        ros::shutdown();
    }
    const bool &RosMaster::IsInitialized() const noexcept
    {
        return ros_initialized_;
    }
} // namespace diagstar