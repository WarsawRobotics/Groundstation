/* Local libs */
#include "ros_master.hpp"
#include "sys_msg.hpp"

/* Std Libs */
#include <chrono>
#include <thread>

/* Ros Libs */
#include <ros/ros.h>

namespace diagstar
{
    RosMaster::RosMaster(int argc, char *argv[]) : mros_initialized_(false)
    {
        ros::init(argc, argv, mkros_package_name_);
        for (size_t i = 0; i < mkconnection_attempts_numb_; ++i)
        {
            if (ros::master::check())
            {
                SystemMsg::ThrowOk(mksys_msg_header_ + "Connected to ros master.");
                mros_initialized_ = true;
                break;
            }
            else
            {
                SystemMsg::ThrowWarn(mksys_msg_header_ + "Cannot connect ros master. Sleep for " + std::to_string(mkconnection_attempt_timeout_) + " [s].");
                std::this_thread::sleep_for(std::chrono::seconds(mkconnection_attempt_timeout_));
            }
        }
        if (!mros_initialized_)
        {
            SystemMsg::ThrowError(mksys_msg_header_ + "Cannot connect to ros master. Connection attempts exceeded threshold.");
        }
    }
    const bool &RosMaster::IsInitialized() const noexcept
    {
        return mros_initialized_;
    }
} // namespace diagstar