#ifndef MASTER_HPP
#define MASTER_HPP

/* Local Libs */
#include "depth_gstream.hpp"
#include "diagnostic_data_manager.hpp"
#include "fisheye_gstream.hpp"
#include "maplab_diagnostic_data.hpp"
#include "ground_station_diagnostic_data.hpp"

namespace diagstar
{
    class Master
    {
    public:
        Master();
        void Run();
        void QuitInterrupt(int sig);
        void InititalizeReceivers();

    private:
        void StartGStreamerLoop();

        DepthGStream depth_stream_;
        FisheyeGStream fisheye_stream_;
        GMainLoop *gstreamer_loop_;
        ThreadRAII gstreamer_thread_;
        DataDiagManager<UdpProtocol> data_diag_man_;

        bool receivers_initialized_;
        const uint32_t kverbose_level_ = 2;
        const std::string ksys_msg_header_ = "[Master] ";
    };
} // namespace diagstar
#endif // MASTER_HPP