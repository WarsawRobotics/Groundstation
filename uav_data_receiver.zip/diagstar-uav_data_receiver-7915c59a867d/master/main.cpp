#include "master.hpp"
#include "ros_master.hpp"

int main(int argc, char *argv[])
{
    diagstar::RosMaster ros_master(argc, argv);
    if (ros_master.IsInitialized())
    {
        diagstar::Master master;
        master.InititalizeReceivers();
        master.Run();
        ros::shutdown();
    }
    return 0;
}