#ifndef GSTREAM_ROS_HPP
#define GSTREAM_ROS_HPP

/* Ros Libs */
#include <ros/ros.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/CameraInfo.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>

/* OpenCV Libs */
#include <opencv2/core.hpp>

/* Local Libs */
#include "streams_common.hpp"

namespace diagstar
{
    class GStreamRos final
    {
        using CamInfo = sensor_msgs::CameraInfo;
        using CamInfoPub = ros::Publisher;
        using CamPub = ros::Publisher;

    public:
        GStreamRos() : img_sequence_(0), img_cv_encoding_(0), img_pub_queue_size(1)
        {
        }
        void Init(const ImgStreamType &stream_type)
        {
            if (stream_type == ImgStreamType::COLOR)
            {
                img_topic = "/uav_data_receiver/camera/color/image_raw";
                img_info_topic_ = "/uav_data_receiver/camera/color/camera_info";
                img_ros_encoding_ = "rgb8";
                img_cv_encoding_ = CV_8UC3;
            }
            else if (stream_type == ImgStreamType::DEPTH)
            {
                img_topic = "/uav_data_receiver/camera/depth/image_rect_raw";
                img_info_topic_ = "/uav_data_receiver/camera/depth/camera_info";
                img_ros_encoding_ = "mono16";
                img_cv_encoding_ = CV_16UC1;
            }
            else if (stream_type == ImgStreamType::FISHEYE)
            {
                img_topic = "/uav_data_receiver/camera/fisheye/image_raw";
                img_info_topic_ = "/uav_data_receiver/camera/fisheye/camera_info";
                img_ros_encoding_ = "mono8";
                img_cv_encoding_ = CV_8UC1;
            }
            SystemMsg::ThrowInfo(ksys_msg_header_ + "Topic: " + img_topic);

            img_pub_ = ros_handle_.advertise<sensor_msgs::Image>(img_topic, img_pub_queue_size);
            img_info_pub_ = ros_handle_.advertise<sensor_msgs::CameraInfo>(img_info_topic_, img_pub_queue_size);
        }
        void Publish(unsigned char *data, const size_t &height, const size_t &width)
        {
            cv::Mat cv_data(height, width, img_cv_encoding_);
            cv_data.data = data;

            auto &&img = cv_bridge::CvImage(std_msgs::Header(), img_ros_encoding_, cv_data).toImageMsg();

            img->header.stamp = ros::Time::now();
            img->width = cv_data.cols;
            img->height = cv_data.rows;
            img->header.seq = ++img_sequence_;

            img_info_.header.stamp = img->header.stamp;
            img_info_.header.seq = img->header.seq;

            img_pub_.publish(img);
            img_info_pub_.publish(img_info_);
            ros::spinOnce();
        }

    private:
        CamInfo img_info_;
        CamInfoPub img_info_pub_;
        CamPub img_pub_;
        std::string img_topic;
        std::string img_info_topic_;
        std::string img_ros_encoding_;

        int img_cv_encoding_;
        size_t img_sequence_;
        size_t img_pub_queue_size;

        ros::NodeHandle ros_handle_;
        const std::string ksys_msg_header_ = "[RosStreamReceiver] ";
    };
} // namespace diagstar
#endif //GSTREAM_ROS_HPP
