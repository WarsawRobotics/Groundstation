#ifndef DIAGNOSTIC_DATA_BASE_HPP
#define DIAGNOSTIC_DATA_BASE_HPP

/* Std Libs */
#include <algorithm>
#include <sstream>
#include <vector>

/* Local Libs */
#include "helpers.hpp"
#include "sys_msg.hpp"

/* 3d Party Libs */
#include "mavlink.h"
#include <ros/ros.h>

namespace diagstar
{
    class DiagnosticDataBase
    {
    public:
        DiagnosticDataBase(std::string &&topics, size_t &&port)
            : topics_(std::move(topics)), port_(std::move(port))
        {
        }
        virtual void PublishData(const mavlink_message_t &data) = 0;
        virtual void Init() = 0;
        virtual const size_t &GetPort() const noexcept { return port_; }
        virtual ~DiagnosticDataBase() = default;
        DiagnosticDataBase() = delete;

    protected:
        std::vector<std::string> GetTopics(std::string &&topics)
        {
            topics.erase(std::remove(topics.begin(), topics.end(), ' '), topics.end());
            std::istringstream string_stream(std::move(topics));
            std::vector<std::string> topic_list;
            std::string topic;
            while (std::getline(string_stream, topic, ','))
            {
                topic_list.push_back(topic);
            }
            return topic_list;
        }
        std::string sys_msg_header_;
        ros::NodeHandle nh_;
        std::string topics_;
        size_t port_;
    };
} // namespace diagstar
#endif //DIAGNOSTICS_DATA_BASE_HPP