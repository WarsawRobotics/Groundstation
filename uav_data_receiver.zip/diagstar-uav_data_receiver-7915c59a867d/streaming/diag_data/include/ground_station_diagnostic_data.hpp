#ifndef GROUND_STATION_DIAGNOSTIC_DATA_HPP
#define GROUND_STATION_DIAGNOSTIC_DATA_HPP

/* Local Libs */
#include "diagnostic_data_base.hpp"

/* Ros Libs */
#include <sensor_msgs/Joy.h>

namespace diagstar
{
    class GroundStationData : public DiagnosticDataBase
    {
    public:
        GroundStationData(std::string &&topics, size_t &&port);
        void Init() override;
        void PublishData(const mavlink_message_t &data) override;

    private:
        std::string data_topic_;
        size_t gcs_expected_joy_data_numb;
    };
} // namespace diagstar

#endif //GROUND_STATION_DIAGNOSTIC_DATA_HPP