#include "ground_station_diagnostic_data.hpp"

namespace diagstar
{
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    //                        PUBLIC FUNCTIONS                            //
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

    GroundStationData::GroundStationData(std::string &&topics, size_t &&port)
        : DiagnosticDataBase(std::move(topics), std::move(port))
    {
        sys_msg_header_ = "[GCSDiagnosticData] ";
        const auto topic_list = GetTopics(std::move(topics_));
        if (topic_list.size() > 2 || topic_list.size() == 0)
        {
            SystemMsg::ThrowError(sys_msg_header_ + "Too many or too few topics defined.");
            throw EXIT_FAILURE;
        }
        data_topic_ = topic_list[0];
        SystemMsg::ThrowInfo(sys_msg_header_ + "Topics: " + data_topic_);
        // gcs_expected_joy_data_numb = ARRAY_SIZE(gcs_msg_.mouse) +
        //                              ARRAY_SIZE(gcs_msg_.throttle_yaw) +
        //                              ARRAY_SIZE(gcs_msg_.pitch_roll);
    }
    void GroundStationData::Init()
    {
    }
    void GroundStationData::PublishData(const mavlink_message_t &data)
    {

    }
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    //                        PRIVATE FUNCTIONS                           //
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

    
} // namespace diagstar