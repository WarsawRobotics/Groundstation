#include "maplab_diagnostic_data.hpp"
#include <geometry_msgs/PoseWithCovarianceStamped.h>

namespace diagstar
{
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    //                        PUBLIC FUNCTIONS                            //
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    MaplabDiagnosticData::MaplabDiagnosticData(std::string &&topics, size_t &&port) 
    : DiagnosticDataBase(std::move(topics), std::move(port))                                                             
    {
        sys_msg_header_ = "[MaplabDiagnosticData] ";
        const auto topic_list = GetTopics(std::move(topics_));
        if (topic_list.size() > 2 || topic_list.size() == 0)
        {
            SystemMsg::ThrowError(sys_msg_header_ + "Too many or too few topics defined.");
            throw EXIT_FAILURE;
        }
        pose_topic_ = topic_list[0];
        SystemMsg::ThrowInfo(sys_msg_header_ + "Topics: " + pose_topic_);
    }
    void MaplabDiagnosticData::Init()
    {
        pose_pub_ = nh_.advertise<geometry_msgs::PoseStamped>(pose_topic_, 1);
    }
    void MaplabDiagnosticData::PublishData(const mavlink_message_t &data)
    {
        mavlink_rovio_full_t rovio_msg;
        mavlink_msg_rovio_full_decode(&data, &rovio_msg);
        Publish(rovio_msg);
    }
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    //                        PRIVATE FUNCTIONS                           //
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

    void MaplabDiagnosticData::PublishPose(const mavlink_rovio_full_t &rovio_msg)
    {
        geometry_msgs::PoseStamped pose;
        pose.header.frame_id = "/world";
        pose.pose.position.x = rovio_msg.transform_x;
        pose.pose.position.y = rovio_msg.transform_y;
        pose.pose.position.z = rovio_msg.transform_z;
        pose.pose.orientation.w = rovio_msg.transform_q[0];
        pose.pose.orientation.x = rovio_msg.transform_q[1];
        pose.pose.orientation.y = rovio_msg.transform_q[2];
        pose.pose.orientation.z = rovio_msg.transform_q[3];
        pose.header.stamp = ros::Time::now();
        pose_pub_.publish(pose);
    }
    void MaplabDiagnosticData::PublishTransform(const mavlink_rovio_full_t &rovio_msg)
    {
        // geometry_msgs::PoseWithCovarianceStamped transform;
        // transform.header.frame_id = "/imu";
        // transform.pose.pose.position.x = rovio_msg.extr_x;
        // transform.pose.pose.position.y = rovio_msg.extr_y;
        // transform.pose.pose.position.z = rovio_msg.extr_z;
        // transform.pose.pose.orientation.w = rovio_msg.extr_q[0];
        // transform.pose.pose.orientation.x = rovio_msg.extr_q[1];
        // transform.pose.pose.orientation.y = rovio_msg.extr_q[2];
        // transform.pose.pose.orientation.z = rovio_msg.extr_q[3];
        // transform.header.stamp = ros::Time::now();
        // extrinsics_pub_.publish(transform);
    }
    void MaplabDiagnosticData::Publish(const mavlink_rovio_full_t &rovio_msg)
    {
        PublishPose(rovio_msg);
        //PublishTransform(rovio_msg);
    }
} // namespace diagstar