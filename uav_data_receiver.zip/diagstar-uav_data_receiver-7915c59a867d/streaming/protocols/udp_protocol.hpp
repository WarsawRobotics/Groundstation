#ifndef UDP_PROTOCOL_HPP
#define UDP_PROTOCOL_HPP

/* Std Libs */
#include <arpa/inet.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <vector>

/* Local Libs */
#include "helpers.hpp"
#include "sys_msg.hpp"
#include "threadRAII.hpp"

/* 3d Party Libs */
#include "mavlink.h"

namespace diagstar
{
    class UdpProtocol
    {
        struct Receiver
        {
            struct sockaddr_in addr_;
            mavlink_status_t last_mavlink_status_, mavlink_status_;
            int socket_;
            uint8_t id_;
            uint8_t *buffer_;
            ThreadRAII worker_;
        };

    public:
        UdpProtocol(const size_t &buffer_size) : receivers_buffer_size_(buffer_size)
        {
        }
        ~UdpProtocol()
        {
            for (uint8_t i = 0; i < receivers_.size(); ++i)
            {
                delete[] receivers_[i].buffer_;
            }
        }
        void AddReceiver(const size_t &port)
        {
            receivers_.push_back(Receiver());

            receivers_.back().socket_ = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
            if (receivers_.back().socket_ == -1)
            {
                throw std::runtime_error("Can't create socket.");
            }

            memset(&receivers_.back().addr_, 0, sizeof(receivers_.back().addr_));
            receivers_.back().addr_.sin_family = AF_INET;
            receivers_.back().addr_.sin_addr.s_addr = INADDR_ANY;
            receivers_.back().addr_.sin_port = htons(port);

            if (bind(receivers_.back().socket_, (struct sockaddr *)&receivers_.back().addr_, sizeof(struct sockaddr)) == -1)
            {
                close(receivers_.back().socket_);
                throw std::runtime_error("Can't bind port to socket.");
            }
            if (fcntl(receivers_.back().socket_, F_SETFL, O_NONBLOCK | O_ASYNC) < 0)
            {
                close(receivers_.back().socket_);
                throw std::runtime_error("Can't configure file descriptor.");
            }

            memset(&receivers_.back().last_mavlink_status_, 0, sizeof(receivers_.back().last_mavlink_status_));
            memset(&receivers_.back().mavlink_status_, 0, sizeof(receivers_.back().mavlink_status_));
            receivers_.back().buffer_ = new uint8_t[receivers_buffer_size_];
            receivers_.back().id_ = receivers_.size();
        }
        template <typename Func, typename NotifyOwner>
        void Listen(Func &&notify_func, NotifyOwner &&owner)
        {
            for (uint8_t i = 0; i < receivers_.size(); ++i)
            {
                receivers_[i].worker_ = ThreadRAII(
                    std::thread([&] {
                        this->ListenHelper(std::forward<Func>(notify_func), std::forward<NotifyOwner>(owner), receivers_[i].id_);
                    }),
                    ThreadRAII::Action::JOIN);
            }
        }
        void QuitInterrupt(int sig)
        {
            exit_ = true;
        }

    private:
        template <typename Func, typename NotifyOwner>
        void ListenHelper(Func &&notify_func, NotifyOwner &&owner, const uint8_t &id)
        {
            Receiver &receiver = receivers_[id];
            socklen_t len = sizeof(receiver.addr_);
            ssize_t recsize = 0;
            mavlink_message_t msg;

            while (!exit_)
            {
                recsize = recvfrom(receiver.socket_, (void *)receiver.buffer_, receivers_buffer_size_, 0, (struct sockaddr *)&(receiver.addr_), &len);
                if (recsize > 0)
                {
                    for (size_t i = 0; i < recsize; ++i)
                    {
                        uint8_t mavlink_raw_data = mavlink_parse_char(MAVLINK_COMM_1, receiver.buffer_[i], &msg, &(receiver.mavlink_status_));
                        if (receiver.last_mavlink_status_.packet_rx_drop_count != receiver.mavlink_status_.packet_rx_drop_count)
                        {
                            SystemMsg::ThrowWarn(sys_msg_header_ + "Mavlink data drop.", true);
                        }
                        receiver.last_mavlink_status_ = receiver.mavlink_status_;

                        if (mavlink_raw_data)
                        {
                            (owner.*notify_func)(msg, id);
                            break;
                        }
                    }
                }
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
            }
            close(receiver.socket_);
        }

        std::vector<Receiver> receivers_;
        const size_t receivers_buffer_size_;
        volatile bool exit_;
        const std::string sys_msg_header_ = "[UdpProtocol] ";
    };
} // namespace diagstar

#endif //UDP_PROTOCOL_HPP