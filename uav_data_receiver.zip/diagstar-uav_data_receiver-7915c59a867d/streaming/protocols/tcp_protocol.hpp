#ifndef TCP_PROTOCOL_HPP
#define TCP_PROTOCOL_HPP

#include "send_protocol_base.hpp"

namespace diagstar
{
    class TcpProtocol : public Protocol
    {
        template <typename... Args>
        TcpProtocol(Args &&... args) : Protocol(std::forward<Args>(args)...)
        {
        }
        void Init() override
        {
            //SystemMsg::ThrowOk("TcpProtocol initialized.");
        }
        // void SendData(const mavlink_message_t &mav_msg) override
        // {
        //     //SystemMsg::ThrowInfo("New data to send arrived");
        // }
        // std::string GetConfigurationString() const override
        // {
        //     return "protocol_tcp  ";
        // }
    };
} // namespace diagstar

#endif //TCP_PROTOCOL_HPP