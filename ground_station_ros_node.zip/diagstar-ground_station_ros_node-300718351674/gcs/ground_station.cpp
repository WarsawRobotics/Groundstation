#include "ground_station.hpp"
#include "hid_link_dummy_msg.h"
#include "hid_link_msg_ground_station_calibration.h"
#include <thread>
#include <csignal>

namespace diagstar
{
    GroundStation *gcs_ptr = nullptr;
    static void quit_handler(int sig)
    {
        ROS_INFO_STREAM("Interrupt. Closing...");
        gcs_ptr->QuitInterrupt(sig);
    }

    GroundStation::GroundStation() : exit_(0), hid_link_wrp_(HID_PID, HID_VID, 1)
    { 
    }
    void GroundStation::QuitInterrupt(int sig)
    {
        exit_ = true;
        hid_link_wrp_.Stop();
    }
    bool GroundStation::Initialize()
    {
        gcs_ptr = this;
        signal(SIGINT, quit_handler);
        hid_link_wrp_.AddSubscriber(*this, &GroundStation::HandleGroundstationMsg, GROUND_STATION_MSG_ID);
        hid_link_wrp_.AddSubscriber(*this, &GroundStation::HandleHeartbeatMsg, HEARTBEAT_MSG_ID);

        bool success = hid_link_wrp_.OpenConnection(4ul, std::chrono::seconds(5ul));
        success = success && ground_station_ros_node_.Init();

        RequestCalibrationData();
        return success;
    }
    void GroundStation::Run()
    {
        hid_link_wrp_.Listen();
    }
    void GroundStation::HandleGroundstationMsg(const hid_link_msg_t &msg)
    {
        static uint32_t gcs_prv_timestamp = 0;
        static hid_link_ground_station_msg_t gcs_msg;
        hid_link_ground_station_msg_decode(&gcs_msg, &msg);
        if (gcs_msg.timestamp > gcs_prv_timestamp)
        {
            gcs_prv_timestamp = gcs_msg.timestamp;
         //   ROS_INFO_STREAM(sys_msg_header_ + "Hearbeat " + std::string(hid_link_get_error_dsc(heartbeat_msg.error_code)));
            ground_station_ros_node_.PublishFullData(ros::Time::now().toSec(), gcs_msg);
        }
    }
    void GroundStation::HandleHeartbeatMsg(const hid_link_msg_t &msg)
    {
        static uint32_t heartbeat_prv_timestamp = 0;
        static hid_link_dummy_msg_t heartbeat_msg;
        hid_link_dummy_msg_decode(&heartbeat_msg, &msg);

        if (heartbeat_msg.timestamp > heartbeat_prv_timestamp)
        {
          //  ROS_INFO_STREAM(sys_msg_header_ + "Hearbeat " + std::string(hid_link_get_error_dsc(heartbeat_msg.error_code)));
            heartbeat_prv_timestamp = heartbeat_msg.timestamp;
            ground_station_ros_node_.PublishHeartbeat();
        }
    }
    void GroundStation::HandleGroundstationCalibrationMsg(const hid_link_msg_t &msg)
    {
        static hid_link_ground_station_calibr_msg_t calibr_msg;
        hid_link_ground_station_calibr_msg_decode(&calibr_msg, &msg);
        const std::string pitch = common::PrintInBrackets(calibr_msg.pitch_min_max[0], calibr_msg.pitch_min_max[1]) + ", ";
        const std::string roll = common::PrintInBrackets(calibr_msg.roll_min_max[0], calibr_msg.roll_min_max[1]) + ", ";
        const std::string throttle = common::PrintInBrackets(calibr_msg.throttle_min_max[0], calibr_msg.throttle_min_max[1]) + ", ";
        const std::string yaw = common::PrintInBrackets(calibr_msg.yaw_min_max[0], calibr_msg.yaw_min_max[1]) + " ";
        ROS_INFO_STREAM(sys_msg_header_ + "Calibration data (pitch, roll, throttle, yaw): " + pitch + roll + throttle + yaw);
    }
    void GroundStation::PrintAxisCalibrationData(const std::string &axis, const uint16_t *axis_calibrated)
    {
        const std::string max_pos_msg = axis + " maximum mean position: " + std::to_string(axis_calibrated[0]);
        const std::string min_pos_msg = axis + " minimum mean position: " + std::to_string(axis_calibrated[1]);
        ROS_INFO_STREAM(sys_msg_header_ + max_pos_msg + ", " + min_pos_msg + "\n");
    }
    void GroundStation::CalibrateJoystickAxis(uint16_t *axis, const uint8_t &axis_str_idx, const std::string &axis_name)
    {
        enum CalibrationType
        {
            AXIS_MINIMUM_POS = 0,
            AXIS_MAXIMUM_POS
        };
        auto rejection_condidtion = [&](uint16_t axis_pos, uint16_t axis_pos_threshold, CalibrationType calibr_type) {
            return calibr_type ? (axis_pos >= axis_pos_threshold ? true : false) : (axis_pos <= axis_pos_threshold ? true : false);
        };

        hid_link_msg_t hid_msg;

        uint16_t axis_max_pos_threshold = 29600;
        uint16_t axis_min_pos_threshold = 210;
        const uint8_t rejected_data_treshold = 20;
        const auto data_aqusition_duration = std::chrono::seconds(5);

        uint16_t *axis_pos_threshold = &axis_max_pos_threshold;
        uint32_t axis_pos_mean = 0;

        bool start_data_aqusistion = false;
        CalibrationType calibration_type = CalibrationType::AXIS_MAXIMUM_POS;
        uint32_t axis_pos_samples = 0;
        uint8_t rejected_data_counter = 0;
        std::chrono::high_resolution_clock::time_point data_aqusition_start_time;
        ROS_INFO_STREAM(sys_msg_header_ + "Move " + axis_name + " to maximum position and hold.");
        while (!exit_)
        {
            if (hid_link_receive_msg(&hid_msg, 5000) > 0)
            {
                int state = hid_link_decode_msg(&hid_msg);
                if (state == 1)
                {
                    if (hid_msg.msg_id == GROUND_STATION_MSG_ID)
                    {
                        const uint32_t axis_pos = static_cast<uint16_t>(hid_msg.data[axis_str_idx] << 0x08 | hid_msg.data[axis_str_idx + 1] & 0xFF);
                        if (rejection_condidtion(axis_pos, *axis_pos_threshold, calibration_type) && !start_data_aqusistion)
                        {
                            rejected_data_counter++;
                            if (rejected_data_counter >= rejected_data_treshold) // Reject remaining data in usb buffer
                            {
                                ROS_INFO_STREAM(sys_msg_header_ + "Hold joystick position.");
                                start_data_aqusistion = true;
                                rejected_data_counter = 0;
                                data_aqusition_start_time = std::chrono::high_resolution_clock::now();
                            }
                        }
                        if (start_data_aqusistion)
                        {
                            axis_pos_mean += axis_pos;
                            axis_pos_samples++;

                            const auto dt = std::chrono::duration_cast<std::chrono::seconds>(std::chrono::high_resolution_clock::now() - data_aqusition_start_time);
                            if (dt >= data_aqusition_duration)
                            {
                                axis_pos_mean /= axis_pos_samples;
                                if (calibration_type == CalibrationType::AXIS_MINIMUM_POS)
                                {
                                    axis[1] = axis_pos_mean;
                                    break;
                                }
                                else
                                {
                                    *axis_pos_threshold = axis_min_pos_threshold;
                                    axis[0] = axis_pos_mean;
                                    axis_pos_mean = 0.0f;
                                    axis_pos_samples = 0;
                                    start_data_aqusistion = false;
                                    ROS_INFO_STREAM(sys_msg_header_ + "Move " + axis_name + " to minimum position and hold.");
                                    calibration_type = CalibrationType::AXIS_MINIMUM_POS;
                                }
                            }
                        }
                    }
                }
                else if (state == 0)
                {
                    ROS_WARN_STREAM(sys_msg_header_ + "Checksum error. Dropping msg!");
                }
                else if (state == -1)
                {
                    ROS_INFO_STREAM(sys_msg_header_ + "No simple hid protocol msg found!");
                }
            }
        }
        PrintAxisCalibrationData(axis_name, axis);
    }
    void GroundStation::CalibrateJoysticks()
    {
        hid_link_dummy_msg_t request_msg;
        hid_link_dummy_msg_encode(GCS_RC_TRANSMITER_HOST, GROUND_STATION_CLEAR_CALIBRATION_MSG_ID, &request_msg);
        hid_link_send_msg(&(request_msg.hid_msg), 1);

        hid_link_ground_station_calibr_msg_t calibration_data;
        ROS_INFO_STREAM(sys_msg_header_ + "Starting joystic axis calibration process.");

        CalibrateJoystickAxis(calibration_data.throttle_min_max, hid_link_ground_station_elem_idx(THROTTLE), "throttle");
        CalibrateJoystickAxis(calibration_data.yaw_min_max, hid_link_ground_station_elem_idx(YAW), "yaw");
        CalibrateJoystickAxis(calibration_data.pitch_min_max, hid_link_ground_station_elem_idx(PITCH), "pitch");
        CalibrateJoystickAxis(calibration_data.roll_min_max, hid_link_ground_station_elem_idx(ROLL), "roll");

        ROS_INFO_STREAM(sys_msg_header_ + "Updating calibration data.");
        SendJoystickCalibrationData(calibration_data);
    }
    void GroundStation::SendJoystickCalibrationData(hid_link_ground_station_calibr_msg_t &calibration_data)
    {
        calibration_data.timestamp = static_cast<uint32_t>(ros::Time::now().toNSec());
        hid_link_ground_station_calibr_msg_encode(GCS_RC_TRANSMITER_HOST, &calibration_data);
        hid_link_send_msg(&(calibration_data.hid_msg), 1);
    }
    void GroundStation::RequestCalibrationData()
    {
        hid_link_dummy_msg_t request_msg;
        hid_link_dummy_msg_encode(GCS_RC_TRANSMITER_HOST, GROUND_STATION_CALIBRATION_DATA_REQUEST, &request_msg);
        const auto requested_data = hid_link_wrp_.RequestData(request_msg.hid_msg, GROUND_STATION_CALIBRATION_MSG_ID);
        if (requested_data)
        {
            HandleGroundstationCalibrationMsg(*requested_data);
        }
    }
} // namespace diagstar
