#ifndef GROUND_STATION_ROS
#define GROUND_STATION_ROS

#include "hid_link_msg_ground_station.h"
#include "hid_link_msg_ground_station_calibration.h"
#include "helpers.hpp"
#include <ros/ros.h>
#include <sensor_msgs/Joy.h>
#include <std_msgs/Header.h>


namespace diagstar
{
    class GroundStationRos
    {
    public:
        GroundStationRos() {}
        bool Init()
        {
            hid_link_ground_station_msg_t gcs_data;

            full_data_msg_.axes.resize(10);
            full_data_msg_.buttons.resize(4);

            full_data_msg_.header.frame_id = "ground_station";
            full_data_msg_pub_ = nh_.advertise<sensor_msgs::Joy>(full_data_msg_topic_, 1);
	    heartbeat_msg_pub_ = nh_.advertise<std_msgs::Header>("groundstation/heartbeat", 1);

            return true;
        }
        void PublishFullData(const double &timestamp, const hid_link_ground_station_msg_t &calibration_data)
        {
            full_data_msg_.header.stamp = ros::Time(timestamp);
            full_data_msg_.header.seq++;

            full_data_msg_.buttons[0] = static_cast<int>(calibration_data.kill_sw_ppm_time);
            full_data_msg_.buttons[1] = static_cast<int>(calibration_data.mission_sw_ppm_time);
            full_data_msg_.buttons[2] = static_cast<int>(calibration_data.flight_modes_sw_ppm_time);
            full_data_msg_.buttons[3] = static_cast<int>(calibration_data.manipulator_sw_ppm_time);

            full_data_msg_.axes[0] = static_cast<float>(calibration_data.throttle_ppm_time);
            full_data_msg_.axes[1] = static_cast<float>(calibration_data.yaw_ppm_time);
            full_data_msg_.axes[2] = static_cast<float>(calibration_data.pitch_ppm_time);
            full_data_msg_.axes[3] = static_cast<float>(calibration_data.roll_ppm_time);
            full_data_msg_.axes[4] = static_cast<float>(calibration_data.tx_ppm_time);
            full_data_msg_.axes[5] = static_cast<float>(calibration_data.ty_ppm_time);
            full_data_msg_.axes[6] = static_cast<float>(calibration_data.tz_ppm_time);
            full_data_msg_.axes[7] = static_cast<float>(calibration_data.rx_ppm_time);
            full_data_msg_.axes[8] = static_cast<float>(calibration_data.ry_ppm_time);
            full_data_msg_.axes[9] = static_cast<float>(calibration_data.rz_ppm_time);

            full_data_msg_pub_.publish(full_data_msg_);
            ros::spinOnce();
        }
	void PublishHeartbeat()
	{
		
                std_msgs::Header h;
                h.stamp = ros::Time::now();

		heartbeat_msg_pub_.publish(h);
		
	}

    private:
        ros::NodeHandle nh_;
        sensor_msgs::Joy full_data_msg_;
        ros::Publisher full_data_msg_pub_;
	ros::Publisher heartbeat_msg_pub_;
        const std::string full_data_msg_topic_ = "groundstation/state";
    };
} // namespace diagstar
#endif //GROUND_STATION_ROS
