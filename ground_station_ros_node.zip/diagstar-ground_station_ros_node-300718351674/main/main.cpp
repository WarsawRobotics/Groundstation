#include "ground_station.hpp"
#include "ros_master.hpp"

int main(int argc, char *argv[])
{
    ros::console::set_logger_level(ROSCONSOLE_DEFAULT_NAME, ros::console::levels::Debug);
    diagstar::RosMaster::Options ros_master_options =
        {
            "rc_receiver",
            3,
            std::chrono::seconds(5),
            ros::init_options::NoSigintHandler,
            argc,
            argv};
    diagstar::RosMaster ros_master(ros_master_options);
    if (ros_master.IsConnected())
    {
        diagstar::GroundStation gcs;
        if (gcs.Initialize())
        {
            gcs.Run();
            //gcs.CalibrateJoysticks();
        }
    }
    return 0;
}
