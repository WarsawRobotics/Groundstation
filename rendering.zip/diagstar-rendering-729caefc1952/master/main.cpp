// Programmer: Mihalis Tsoukalos
// Date: Wednesday 04 June 2014
//
// A simple OpenGL program that draws a colorful cube
// that rotates as you move the arrow keys!
//
// g++ cube.cc -lm -lglut -lGL -lGLU -o cube

#define GL_GLEXT_PROTOTYPES
#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif
#include <math.h>
#include <chrono>
#include <iostream>
    double rX=0;
// Rotate Y
double rY=0;
    std::chrono::high_resolution_clock::time_point start;
    std::chrono::duration<double> time_span;
// The coordinates for the vertices of the cube
double x1 = 0.06;

void drawOne(float x, float y, float z)
{
    glBegin(GL_TRIANGLE_STRIP);
    glColor3f(0.4, 0.3, 0.5);
    glVertex3f(-x1+x, -x1+y, -x1+z); //1
                glVertex3f(x1+x, -x1+y, -x1+z); //2
                glVertex3f(-x1+x, -x1+y, x1+z); //3
                glVertex3f(x1+x, -x1+y, x1+z); //4
                glVertex3f(x1+x, x1+y, x1+z);  //5
                glVertex3f(x1+x, -x1+y, -x1+z); //6
                glVertex3f(x1+x, x1+y, -x1+z); //7
                glVertex3f(-x1+x, -x1+y, -x1+z); //8
                glVertex3f(-x1+x, x1+y, -x1+z); //9
                glVertex3f(-x1+x, -x1+y, x1+z); //10
                glVertex3f(-x1+x, x1+y, x1+z); //11
                glVertex3f(x1+x, x1+y, x1+z); //12
                glVertex3f(-x1+x, x1+y, -x1+z); //13
                glVertex3f(x1+x, x1+y, -x1+z); //14
                 glEnd();
}

void drawCube()
{

    start = std::chrono::high_resolution_clock::now();
        // Set Background Color
    glClearColor(0.4, 0.4, 0.4, 1.0);
        // Clear screen
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glMatrixMode( GL_MODELVIEW );
    // Reset transformations
    glLoadIdentity();
    // Rotate when user changes rX and rY
    glRotatef( rX, 1.0, 0.0, 0.0 );
    glRotatef( rY, 0.0, 1.0, 0.0 );
    // BACK
    for(float i = -2.0; i<2.0; i+=0.001){
drawOne(i,i,i);
}      
    glFlush();
    glutSwapBuffers();
        time_span = std::chrono::duration_cast<std::chrono::duration<double>>(std::chrono::high_resolution_clock::now() - start);
    std::cout<<time_span.count()<<std::endl;

}



void keyboard(int key, int x, int y)
{
    if (key == GLUT_KEY_RIGHT)
        {
                rY += 15;
        }
    else if (key == GLUT_KEY_LEFT)
        {
                rY -= 15;
        }
    else if (key == GLUT_KEY_DOWN)
        {
                rX -= 15;
        }
    else if (key == GLUT_KEY_UP)
        {
                rX += 15;
        }

    // Request display update
    glutPostRedisplay();
}


int main(int argc, char **argv)
{
       // Initialize GLUT and process user parameters
        glutInit(&argc, argv);

        // Request double buffered true color window with Z-buffer
        glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

        glutInitWindowSize(500,700);
        glutInitWindowPosition(100, 100);
        // Create window
        glutCreateWindow("Linux Journal OpenGL Cube");
        glEnable(GL_DEPTH_TEST);

        // Callback functions
        glutDisplayFunc(drawCube);
        glutSpecialFunc(keyboard);
        glViewport( 0, 0, 500, 700 );
            glMatrixMode( GL_PROJECTION );
    // macierz rzutowania = macierz jednostkowa
    glLoadIdentity();
        // Pass control to GLUT for events
             glFrustum( - 2.0, 2.0, - 2.0 * 700 / 500, 2.0 * 700 / 500, 1.0, 5.0 );
            std::cout<<"LOS"<<std::endl;

        glutMainLoop();

        return 0;
}
