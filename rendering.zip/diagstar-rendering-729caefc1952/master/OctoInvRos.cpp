/****************************************************************************
**
** Copyright (C) 2017 The Qt Company Ltd.
** Contact: https://www.qt.io/licensing/
**
** This file is part of the examples of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** BSD License Usage
** Alternatively, you may use this file under the terms of the BSD license
** as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include "octoInvRos.h"
#include <unistd.h>

OctoInvencoRos::OctoInvencoRos(const std::string& filename, int depthLevel, bool emptyBox, std::mutex *locker)
    : m_filename(filename),
      _mdepthLevel(depthLevel),
      rosLocked(locker)
{
    _needEmpty=emptyBox;
}
OctoInvencoRos::~OctoInvencoRos()
{
    for (std::map<int, OctoMapData>::iterator it = m_octrees.begin(); it != m_octrees.end(); ++it)
    {
        delete (it->second.octree);
    }
    m_octrees.clear();
}
void OctoInvencoRos::openFile()
{
    sub =n.subscribe(nTopic, 1, &OctoInvencoRos::openTree, this);
}

void OctoInvencoRos::openTree(const octomap_msgs::Octomap& msg)
{
    auto tree = std::unique_ptr<octomap::OcTree>((OcTree*)octomap_msgs::binaryMsgToMap(msg));
    if(_needEmpty)
    {
        gowOcTree(tree.get());
    }
    else
    {
        gowEOcTree(tree.get());
    }
}
int OctoInvencoRos::changeDepth(int depth)
{
    _mdepthLevel=depth;
    return _mdepthLevel;
}
void OctoInvencoRos::gowOcTree(OcTree* tree)
{
    std::lock_guard<std::mutex> guard(*rosLocked);
    pD.clear();
    pC.clear();
    fC.clear();
    for(OcTree::tree_iterator it = tree->begin_tree(_mdepthLevel), end=tree->end_tree(); it!=end; ++it) {
        if (it.isLeaf()) { // voxels for leaf nodes
            if (tree->isNodeOccupied(*it)){ // occupied voxels
                pC.push_back(it.getCoordinate());
                pD.push_back(it.getDepth());
                //                }
            }
            else
            {
                fC.push_back(it.getCoordinate());
            }
        }
    }
}
void OctoInvencoRos::gowEOcTree(OcTree* tree)
{
    std::lock_guard<std::mutex> guard(*rosLocked);
    pD.clear();
    pC.clear();
    for(OcTree::tree_iterator it = tree->begin_tree(_mdepthLevel), end=tree->end_tree(); it!=end; ++it)
    {
        if (it.isLeaf())
        { // voxels for leaf nodes
            if (tree->isNodeOccupied(*it))
            { // occupied voxels
                pC.push_back(it.getCoordinate());
                pD.push_back(it.getDepth());
                //                }
            }
        }
    }
}

