#ifndef OCTOMAPDATA
#define OCTOMAPDATA
#include <octomap/octomap.h>


class OctoMapData {
public:

    octomap::AbstractOcTree*  octree;
    unsigned int     id;
    octomap::pose6d           position;
};

#endif
