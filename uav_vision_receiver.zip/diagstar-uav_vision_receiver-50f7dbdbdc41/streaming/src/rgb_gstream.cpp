#include "rgb_gstream.hpp"

namespace diagstar
{
    RgbGStream::RgbGStream()
    {
        encoding_ = "RGB";
        sys_msg_header_ = "[RgbGStream] ";
        port_ = 5002;
        image_height_ = 720;
        image_width_ = 1280;
        stream_type_ = ImgStreamType::COLOR;
        image_size_ = image_width_ * image_height_ * 3*sizeof(uint8_t);
    }
    bool RgbGStream::Initialize()
    {
       return CreatePipelineElements() && ConfigurePipelineElements() && LinkElementsInPipeline();
    }
    bool RgbGStream::CreatePipelineElements()
    {
        source_ = gst_element_factory_make("udpsrc", "rgb_stream_source");
        payload_ = gst_element_factory_make("rtph264depay", "rgb_stream_payload");
        parser_ = gst_element_factory_make("h264parse", "rgb_stream_parser");
        decoder_ = gst_element_factory_make("decodebin", "rgb_stream_decoder");
        converter_ = gst_element_factory_make("videoconvert", "rgb_stream_convert");
        sink_ = gst_element_factory_make("appsink", "rgb_stream_sink");
        pipeline_ = gst_pipeline_new("rgb_pipeline");

        if (!pipeline_ || !source_ || !payload_ || !parser_ || !decoder_ || !converter_ || !sink_)
        {
            ROS_ERROR_STREAM(sys_msg_header_ + "Not all elements could be created");
            return false;
        }
        else
        {
            return true;
        }
    }
    bool RgbGStream::ConfigurePipelineElements()
    {
        GstCaps *video_caps = gst_caps_new_simple("video/x-raw",
                                                "format", G_TYPE_STRING, encoding_.c_str(),
                                                "width", G_TYPE_INT, image_width_,
                                                "height", G_TYPE_INT, image_height_,
                                                "framerate", GST_TYPE_FRACTION, 35, 1, nullptr);

        GstCaps *rtp_caps = gst_caps_new_simple("application/x-rtp",
                                                "encoding-name", G_TYPE_STRING, "H264", nullptr);

        g_object_set(source_, "port", port_, "caps", rtp_caps, nullptr);
        g_object_set(sink_, "emit-signals", true, "caps", video_caps, "sync", false, nullptr);
        g_signal_connect(sink_, "new-sample", G_CALLBACK(NewDataCallback), this);
        gst_caps_unref(video_caps);
        gst_caps_unref(rtp_caps);
        return true;
    }
    bool RgbGStream::LinkElementsInPipeline()
    {
        gst_bin_add_many(GST_BIN(pipeline_), source_, payload_, parser_, decoder_, converter_, sink_, nullptr);

        if (gst_element_link_many(source_, payload_, parser_, nullptr) != true)
        {
            ROS_ERROR_STREAM(sys_msg_header_ + "Not all elements could be linked");
            return false;
        }
        if (gst_element_link(parser_, decoder_) != true)
        {
            ROS_ERROR_STREAM(sys_msg_header_ + "Not all elements could be linked");
            return false;
        }
        if (gst_element_link(converter_, sink_) != true)
        {
            ROS_ERROR_STREAM(sys_msg_header_ + "Not all elements could be linked");
            return false;
        }
        g_signal_connect(decoder_, "pad-added", G_CALLBACK(NewPadCallback), converter_);
        ROS_INFO_STREAM(sys_msg_header_ + "Stream initialized.");
        return true;
    }
}; // namespace diagstar