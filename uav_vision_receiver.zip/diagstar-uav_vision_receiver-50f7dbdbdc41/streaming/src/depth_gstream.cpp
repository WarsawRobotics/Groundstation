#include "depth_gstream.hpp"

namespace diagstar
{
    DepthGStream::DepthGStream()
    {
        encoding_ = "GRAY16_BE";
        sys_msg_header_ = "[DepthGStream] ";
        port_ = 5001;
        image_height_ = 240;
        image_width_ = 320;
        stream_type_ = ImgStreamType::DEPTH;
        image_size_ = image_width_ * image_height_ * sizeof(uint16_t);
    }
    bool DepthGStream::Initialize()
    {
        return CreatePipelineElements() && ConfigurePipelineElements() && LinkElementsInPipeline();
    }
    bool DepthGStream::CreatePipelineElements()
    {
        source_ = gst_element_factory_make("udpsrc", "depth_stream_source");
        payload_ = gst_element_factory_make("rtpgstdepay", "depth_stream_payload");
        parser_ = gst_element_factory_make("pngparse", "depth_stream_parser");
        decoder_ = gst_element_factory_make("decodebin", "depth_stream_decoder");
        converter_ = gst_element_factory_make("videoconvert", "depth_stream_convert");
        sink_ = gst_element_factory_make("appsink", "depth_stream_sink");
        pipeline_ = gst_pipeline_new("depth_pipeline");

        if (!pipeline_ || !source_ || !payload_ || !parser_ || !decoder_ || !converter_ || !sink_)
        {
            ROS_ERROR_STREAM(sys_msg_header_ + "Not all elements could be created.");
            return false;
        }
        else
        {
            return true;
        }
    }
    bool DepthGStream::ConfigurePipelineElements()
    {
        GstCaps *video_caps = gst_caps_new_simple("video/x-raw",
                                                "format", G_TYPE_STRING, encoding_.c_str(),
                                                "width", G_TYPE_INT, image_width_,
                                                "height", G_TYPE_INT, image_height_,
                                                "framerate", GST_TYPE_FRACTION, 10, 1, nullptr);

        GstCaps *rtp_caps = gst_caps_new_simple("application/x-rtp",
                                                "encoding-name", G_TYPE_STRING, "X-GST", nullptr);

        g_object_set(source_, "port", port_, "caps", rtp_caps, nullptr);
        g_object_set(sink_, "emit-signals", true, "caps", video_caps, nullptr);
        g_signal_connect(sink_, "new-sample", G_CALLBACK(NewDataCallback), this);
        gst_caps_unref(video_caps);
        gst_caps_unref(rtp_caps);
        return true;
    }
    bool DepthGStream::LinkElementsInPipeline()
    {
        gst_bin_add_many(GST_BIN(pipeline_), source_, payload_, parser_, decoder_, converter_, sink_, nullptr);

        if (gst_element_link_many(source_, payload_, parser_, nullptr) != true)
        {
            ROS_ERROR_STREAM(sys_msg_header_ + "Not all elements could be linked.");
            return false;
        }
        if (gst_element_link(parser_, decoder_) != true)
        {
            ROS_ERROR_STREAM(sys_msg_header_ + "Not all elements could be linked.");
            return false;
        }
        if (gst_element_link(converter_, sink_) != true)
        {
            ROS_ERROR_STREAM(sys_msg_header_ + "Not all elements could be linked.");
            return false;
        }
        g_signal_connect(decoder_, "pad-added", G_CALLBACK(NewPadCallback), converter_);
        ROS_INFO_STREAM(sys_msg_header_ + "Stream initialized.");
        return true;
    }
}; // namespace diagstar