#ifndef RGB_GSTREAM_HPP
#define RGB_GSTREAM_HPP

#include "gstream_base.hpp"

namespace diagstar
{
    class RgbGStream : public GStreamBase<RgbGStream>
    {
    public:
        RgbGStream();

    private:
        bool Initialize();
        bool CreatePipelineElements();
        bool ConfigurePipelineElements();
        bool LinkElementsInPipeline();

        friend class GStreamBase<RgbGStream>;
    };
} // namespace diagstar

#endif //RGB_GSTREAM_HPP