#ifndef GSTREAM_BASE_HPP
#define GSTREAM_BASE_HPP

/* GStreamer Libs */
#include <gst/app/gstappsrc.h>
#include <gst/gst.h>
#include <gst/video/video.h>

/* Local Libs */
#include "gstream_ros.hpp"

namespace diagstar
{

    template <typename GStream>
    class GStreamBase
    {
    public:
        GStreamBase() : source_(nullptr), converter_(nullptr), sink_(nullptr),
                        decoder_(nullptr), parser_(nullptr), payload_(nullptr),
                        pipeline_(nullptr), image_height_(0), image_width_(0),
                        image_size_(0), port_(0), gstream_(static_cast<GStream *>(this))
        {
        }
        void QuitRequest(int sig)
        {
            try
            {
                gst_element_set_state(pipeline_, GST_STATE_NULL);
                ROS_INFO_STREAM(sys_msg_header_ + "Process succefully stopped.");
            }
            catch (int error)
            {
                ROS_ERROR_STREAM("Can't stop process. Force exit." + sys_msg_header_);
                throw EXIT_FAILURE;
            }
        }
        bool Init()
        {
            gst_init(nullptr, nullptr);
            if (gstream_->Initialize())
            {
                gstream_ros_.Init(stream_type_);
                gst_element_set_state(pipeline_, GST_STATE_PLAYING);
                PrintConfig();
                return true;
            }
            else
            {
                return false;
            }
        }

    protected:
        static void NewPadCallback(GstElement *element, GstPad *pad, gpointer data)
        {
            gst_element_link(element, (GstElement *)data);
        }
        static GstFlowReturn NewDataCallback(GstElement *sink, GStreamBase *gstream_base_ptr)
        {
            return gstream_base_ptr->NewDataHelper(sink);
        }

        size_t image_width_, image_height_, image_size_;
        std::string encoding_, sys_msg_header_;
        int port_;
        GstElement *source_, *converter_, *sink_;
        GstElement *decoder_, *parser_, *payload_;
        GstElement *pipeline_;
        ImgStreamType stream_type_;
        GStreamRos gstream_ros_;

    private:
        GstFlowReturn NewDataHelper(GstElement *sink)
        {
            GstSample *sample = nullptr;
            g_signal_emit_by_name(sink, "pull-sample", &sample);
            if (sample)
            {
                GstBuffer *buffer = gst_sample_get_buffer(sample);
                if (buffer != nullptr)
                {
                    GstMapInfo map;
                    gst_buffer_map(buffer, &map, (GstMapFlags)GST_MAP_READ);
                    gstream_ros_.Publish(map.data, image_height_, image_width_);
                    gst_buffer_unmap(buffer, &map);
                }
                gst_sample_unref(sample);
                return GST_FLOW_OK;
            }
            return GST_FLOW_ERROR;
        }
        void PrintConfig() const
        {
            ROS_INFO_STREAM(sys_msg_header_ + "Image size: (" + std::to_string(image_width_) + ", " + std::to_string(image_height_) + ")");
            ROS_INFO_STREAM(sys_msg_header_ + "Transmiter port: " + std::to_string(port_));
            ROS_INFO_STREAM(sys_msg_header_ + "Encoding: " + encoding_);
        }

        GStream *gstream_;
    };
} // namespace diagstar
#endif //GSTREAM_BASE_HPP