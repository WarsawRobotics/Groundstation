#include "vision_receiver.hpp"
#include "ros_master.hpp"

int main(int argc, char *argv[])
{
	diagstar::RosMaster::Options ros_master_options =
    {
        "uav_vision_receiver",
        3,
        std::chrono::seconds(5),
        ros::init_options::NoSigintHandler,
        argc,
        argv
    };
    diagstar::RosMaster ros_master(ros_master_options);

    if (ros_master.IsConnected())
    {
        diagstar::VisionReceiver vis_receiver;
        vis_receiver.Inititalize();
        vis_receiver.Run();
        
    }
    return 0;
}