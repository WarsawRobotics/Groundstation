/**
 * @file ros_master.hpp
 * @author Jacek Szaltys
 * @brief 
 * @version 0.1
 * @date 2019-09-02
 * 
 * @copyright Copyright (c) 2019
 * 
 */
#ifndef ROS_MASTER_HPP
#define ROS_MASTER_HPP

/* Std Libs */
#include <chrono>
#include <string>

#include <ros/ros.h>

namespace diagstar
{
    class RosMaster
    {
    public:
        struct Options
        {
            std::string package_name;
            size_t connection_attempts;
            std::chrono::seconds connection_attempt_timeout;
            uint32_t options;
            int argc;
            char **argv;
        };

        RosMaster(RosMaster::Options &options);
        const bool &IsConnected() const noexcept;

    private:
        bool ros_master_connected_;
        const std::string ksys_msg_header_ = "[RosMaster] ";
    };
} // namespace diagstar
#endif //ROS_MASTER_HPP