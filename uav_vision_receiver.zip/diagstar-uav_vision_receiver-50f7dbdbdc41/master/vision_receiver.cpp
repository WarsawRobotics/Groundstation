/* Std Libs */
#include <csignal>

/* Local Libs */
#include "vision_receiver.hpp"

namespace diagstar
{
    VisionReceiver *receiver_ptr = nullptr;

    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    //                        PUBLIC FUNCTIONS                            //
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

    VisionReceiver::VisionReceiver()
        : receivers_initialized_(false), gstreamer_loop_(nullptr)//, data_diag_man_(512)
    {
        receiver_ptr = this;
        signal(SIGINT, [](int sig) { receiver_ptr->QuitRequest(sig); });
    }
    void VisionReceiver::Run()
    {
        if (receivers_initialized_)
        {
            StartGStreamerLoop();
            gstreamer_thread_.Get().join();
        }
    }
    void VisionReceiver::Inititalize()
    {

        const bool rgb_is_ready = rgb_stream_.Init();
        const bool depth_is_ready = depth_stream_.Init();
        const bool modules_ready = depth_is_ready && rgb_is_ready;// && diag_data_man_is_ready;

        if (!modules_ready)
        {
            if(!rgb_is_ready)
            {
                ROS_ERROR_STREAM(ksys_msg_header_ + "Rgb stream intitialization failed.");
            }
            else if (!depth_is_ready)
            {
                ROS_ERROR_STREAM(ksys_msg_header_ + "Depth stream intitialization failed.");
            }
        }
        else
        {
            ROS_INFO_STREAM(ksys_msg_header_ + "Receivers intitialized.");
            receivers_initialized_ = true;
        }
    }
    void VisionReceiver::QuitRequest(int sig)
    {
        try
        {
            g_main_loop_quit(gstreamer_loop_);
            rgb_stream_.QuitRequest(sig);
            depth_stream_.QuitRequest(sig);
            ros::shutdown();
            ROS_INFO_STREAM(ksys_msg_header_ + "Process succefully stopped.");
        }
        catch (int error)
        {
            ROS_ERROR_STREAM(ksys_msg_header_ + "Cannot stop process. Force exit.");
            throw EXIT_FAILURE;
        }
    }

    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/
    //                        PRIVATE FUNCTIONS                           //
    //\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/

    void VisionReceiver::StartGStreamerLoop()
    {
        ROS_INFO_STREAM(ksys_msg_header_ + "Starting gstreamer loop.");
        gstreamer_loop_ = g_main_loop_new(nullptr, false);
        gstreamer_thread_ = ThreadRAII(std::thread([this]() { g_main_loop_run(gstreamer_loop_); }), ThreadRAII::Action::JOIN);
    }

} // namespace diagstar