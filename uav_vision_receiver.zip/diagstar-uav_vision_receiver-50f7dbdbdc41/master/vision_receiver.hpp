#ifndef VISION_RECEIVER_HPP
#define VISION_RECEIVER_HPP

/* Local Libs */
#include "depth_gstream.hpp"
#include "rgb_gstream.hpp"
#include "threadRAII.hpp"

namespace diagstar
{
    class VisionReceiver
    {
    public:
        VisionReceiver();
        void Run();
        void QuitRequest(int sig);
        void Inititalize();

    private:
        void StartGStreamerLoop();

        DepthGStream depth_stream_;
        RgbGStream rgb_stream_;
        GMainLoop *gstreamer_loop_;
        ThreadRAII gstreamer_thread_;

        bool receivers_initialized_;
        const std::string ksys_msg_header_ = "[VisionReceiver] ";
    };
} // namespace diagstar
#endif // VISION_RECEIVER_HPP